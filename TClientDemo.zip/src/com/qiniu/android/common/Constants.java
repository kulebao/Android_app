package com.qiniu.android.common;


public final class Constants {
    public static final String VERSION = "7.0.7.2";

    public static final String UTF_8 = "utf-8";
}
