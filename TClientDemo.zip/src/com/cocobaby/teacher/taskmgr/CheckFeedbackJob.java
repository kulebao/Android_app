package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.FeedBackMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class CheckFeedbackJob extends MyJob {

	private Handler hander;
	private int newsid;

	public CheckFeedbackJob(Handler handler, int newsid) {
		this.hander = handler;
		this.newsid = newsid;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.CHECK_FEEDBACK_FAILED);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = FeedBackMethod.getMethod().checkFeedBack(newsid);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			hander.sendMessage(msg);
		}
	}
}
