package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.FeedBackMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class FeedbackJob extends MyJob {

	private Handler hander;
	private String content;

	public FeedbackJob(Handler handler, String content) {
		this.hander = handler;
		this.content = content;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.FEEDBACK_FAILED);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = FeedBackMethod.getMethod().feedBack(content);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			hander.sendMessage(msg);
		}
	}
}
