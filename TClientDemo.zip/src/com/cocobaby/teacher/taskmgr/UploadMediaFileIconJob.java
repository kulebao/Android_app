package com.cocobaby.teacher.taskmgr;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.method.ChatMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.UploadTokenMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.upload.UploadFactory;
import com.cocobaby.teacher.utils.Utils;

public class UploadMediaFileIconJob extends MyJob {
	private Handler handler;
	private long lastid;
	List<ChatInfo> list = new ArrayList<ChatInfo>();
	private String childid;
	private String mediaPath = "";
	private String mediaType = "";

	public UploadMediaFileIconJob(Handler handler, String mediaPath,
			String mediaType, long lastid, String childid) {
		this.handler = handler;
		this.lastid = lastid;
		this.mediaPath = mediaPath;
		this.mediaType = mediaType;
		this.childid = childid;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.SEND_CHAT_FAIL);
		try {
			String url = uploadFileToServer();
			// 上传到云服务器后，生成的外部链接
			String media = UploadFactory.getUploadHost() + url;
			final String content = InfoHelper.formatChatContent("", media,
					childid, mediaType);

			MyProxy proxy = new MyProxy();
			MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
				@Override
				public MethodResult handle() throws Exception {
					MethodResult result = ChatMethod.getMethod().sendChat(
							content, lastid, childid);
					return result;
				}
			});

			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			handler.sendMessage(msg);
		}

	}

	private String uploadFileToServer() throws Exception {
		String url = mediaPath.replace(Utils.getSDCardMediaRootPath(mediaType)
				+ File.separator, "");
		String uploadToken = UploadTokenMethod.getMethod().getUploadToken("");
		if (TextUtils.isEmpty(uploadToken)) {
			throw new RuntimeException("getUploadToken failed ");
		}
		Log.d("DDD", "uploadFileToServer voice url=" + url);
		UploadFactory.createUploadMgr().uploadFile(mediaPath, url, uploadToken);
		return url;
	}
}
