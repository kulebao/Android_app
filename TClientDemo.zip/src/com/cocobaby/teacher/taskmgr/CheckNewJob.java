package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.ChechUpdateMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class CheckNewJob extends MyJob {

	private Handler hander;
	private int versionCode;

	public CheckNewJob(Handler handler, int versionCode) {
		this.hander = handler;
		this.versionCode = versionCode;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.SERVER_BUSY);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = ChechUpdateMethod.getChechUpdateMethod()
						.chechUpdate(versionCode);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			hander.sendMessage(msg);
		}
	}
}
