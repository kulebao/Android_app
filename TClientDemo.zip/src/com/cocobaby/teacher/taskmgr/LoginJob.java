package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.LoginMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.utils.IMUtils;

public class LoginJob extends MyJob {

	private Handler hander;
	private String pwd;
	private String username;

	public LoginJob(Handler handler, String username, String pwd) {
		this.hander = handler;
		this.pwd = pwd;
		this.username = username;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.PWD_INCORRECT);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = LoginMethod.getLoginMethod().login(pwd, username);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();
			if (!TextUtils.isEmpty(IMUtils.getToken())) {
				IMUtils.connect(IMUtils.getToken());
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			hander.sendMessage(msg);
		}
	}
}
