package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.IMForbidMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class GetForbidUsersJob extends MyJob{

    private Handler hander;
    private String  classid;

    public GetForbidUsersJob(Handler handler, String classid){
        this.hander = handler;
        this.classid = classid;
    }

    @Override
    public void run(){
        MethodResult bret = new MethodResult(EventType.GROUP_UNFORBID_FAIL);

        MyProxy proxy = new MyProxy();
        MyProxyImpl bind = (MyProxyImpl)proxy.bind(new MyProxyImpl(){
            @Override
            public MethodResult handle() throws Exception{
                MethodResult result = IMForbidMethod.getMethod().getForbidUsers(classid);
                return result;
            }
        });
        try{
            bret = (MethodResult)bind.handle();
        } catch(Exception e){
            e.printStackTrace();
        }
        finally{
            Message msg = Message.obtain();
            msg.obj = bret.getResultObj();
            msg.what = bret.getResultType();
            hander.sendMessage(msg);
        }
    }
}
