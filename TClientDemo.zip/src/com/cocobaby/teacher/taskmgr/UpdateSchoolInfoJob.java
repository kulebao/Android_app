package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.SchoolMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class UpdateSchoolInfoJob extends MyJob{

    private Handler hander;

    public UpdateSchoolInfoJob(Handler handler){
        this.hander = handler;
    }

    @Override
    public void run(){
        MethodResult bret = new MethodResult(EventType.SCHOOL_INFO_IS_LATEST);

        MyProxy proxy = new MyProxy();
        MyProxyImpl bind = (MyProxyImpl)proxy.bind(new MyProxyImpl(){
            @Override
            public MethodResult handle() throws Exception{
                int event = SchoolMethod.getMethod().checkSchoolInfo();
                MethodResult result = new MethodResult(event);
                return result;
            }
        });
        try{
            bret = (MethodResult)bind.handle();
        } catch(Exception e){
            e.printStackTrace();
        }
        finally{
            Message msg = Message.obtain();
            msg.what = bret.getResultType();
            hander.sendMessage(msg);
        }
    }
}
