package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.ChangePWDMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class ChangePWDJob extends MyJob {

	private Handler hander;
	private String newPwd;
	private String oldPwd;

	public ChangePWDJob(Handler handler, String newPwd, String oldPwd) {
		this.hander = handler;
		this.oldPwd = oldPwd;
		this.newPwd = newPwd;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);

		Log.w("djc", "ResetPWDJob! doInBackground");
		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {

			@Override
			public Object handle() throws Exception {
				MethodResult result = ChangePWDMethod.getMethod().changePwd(newPwd, oldPwd);
				return result;
			}
		});
		try {
			Log.w("djc", "ResetPWDTask!");
			bret = (MethodResult) bind.handle();
			Log.w("djc", "ResetPWDTask! result=" + bret);
		} catch (Exception e) {
			Log.w("djc", "Exception e=" + e.toString());
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			hander.sendMessage(msg);
		}
	}

}
