package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.TeacherMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class GetTeacherListJob extends MyJob{
    private Handler handler;
    private String  classid;

    public GetTeacherListJob(Handler handler, String classid){
        this.handler = handler;
        this.classid = classid;
    }

    @Override
    public void run(){
        MethodResult bret = new MethodResult(EventType.GET_TEACHER_FAIL);
        MyProxy proxy = new MyProxy();
        MyProxyImpl bind = (MyProxyImpl)proxy.bind(new MyProxyImpl(){
            @Override
            public MethodResult handle() throws Exception{
                MethodResult result = TeacherMethod.getMethod().getTeacherListByClassID(classid);
                return result;
            }
        });

        try{
            bret = (MethodResult)bind.handle();
        } catch(Exception e){
            e.printStackTrace();
        }
        finally{
            Message msg = Message.obtain();
            msg.what = bret.getResultType();
            msg.obj = bret.getResultObj();
            handler.sendMessage(msg);
        }
    }

}
