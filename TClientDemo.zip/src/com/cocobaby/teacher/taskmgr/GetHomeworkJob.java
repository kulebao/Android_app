package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.HomeworkMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class GetHomeworkJob extends MyJob {
	// 最少等2s
	private static final int LIMIT_TIME = 2000;
	private Handler handler;
	private int most;
	private long from;
	private long to;
	private int addType;

	public GetHomeworkJob(Handler handler, int most, long from, long to,
			int addType) {
		this.handler = handler;
		this.most = most;
		this.from = from;
		this.to = to;
		this.addType = addType;
	}

	@Override
	public void run() {
		long current = System.currentTimeMillis();
		MethodResult bret = new MethodResult(EventType.GET_NEWS_FAIL);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = HomeworkMethod.getMethod()
						.getGetHomework(most, from, to);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();

			long now = System.currentTimeMillis();
			long ellapse = now - current;
			if (ellapse < LIMIT_TIME) {
				try {
					Thread.sleep(LIMIT_TIME - ellapse);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			msg.arg1 = addType;
			handler.sendMessage(msg);
		}
	}
}
