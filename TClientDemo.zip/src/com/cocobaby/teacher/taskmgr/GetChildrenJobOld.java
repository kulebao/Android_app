package com.cocobaby.teacher.taskmgr;

import java.util.List;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.RelationshipMap;
import com.cocobaby.teacher.im.IMHelper;
import com.cocobaby.teacher.method.ChildMethod;
import com.cocobaby.teacher.method.ClassesMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.RelationshipMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class GetChildrenJobOld extends MyJob{

    private Handler hander;

    public GetChildrenJobOld(Handler handler){
        this.hander = handler;
    }

    @Override
    public void run(){
        MethodResult bret = new MethodResult(EventType.GET_CHILDREN_FAIL);

        MyProxy proxy = new MyProxy();
        MyProxyImpl bind = (MyProxyImpl)proxy.bind(new MyProxyImpl(){
            @Override
            public MethodResult handle() throws Exception{
                MethodResult result = ChildMethod.getMethod().getChildren();
                return result;
            }
        });

        try{
            // 获取学生信息之前，先获取全部班级信息
            ClassesMethod.getMethod().getInfo();
            bret = (MethodResult)bind.handle();

            // 这里还需要获取小孩家长的原始信息
            if(bret.getResultType() == EventType.GET_CHILDREN_SUCCESS){
                getParentOriginalInfo();
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        finally{
        	IMHelper.updateParentsInfoCache();
            Message msg = Message.obtain();
            msg.what = bret.getResultType();
            hander.sendMessage(msg);
        }
    }

    private void getParentOriginalInfo(){
        List<ChildInfo> allChild = DataMgr.getInstance().getAllChild();

        for(ChildInfo childInfo : allChild){
            try{
                String childid = childInfo.getServerID();

                RelationshipMap relationship = DataMgr.getInstance().getRelationship(childid);

                // 如果家长信息为空，则获取一次
                if(DataMgr.getInstance().getParentIDsByChildId(childid).isEmpty() || relationship == null
                        || TextUtils.isEmpty(relationship.getRelationship())){
                    RelationshipMethod.getMethod().getRelationship(childid);
                }
            } catch(Exception e){
                e.printStackTrace();
            }
        }

    }

}
