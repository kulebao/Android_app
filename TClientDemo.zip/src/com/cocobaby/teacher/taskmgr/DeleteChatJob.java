package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.method.ChatMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class DeleteChatJob extends MyJob {
	private Handler handler;
	private long chatid;
	private String childid;

	public DeleteChatJob(Handler handler, long chatid, String childid) {
		this.handler = handler;
		this.chatid = chatid;
		this.childid = childid;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.DELETE_CHAT_FAIL);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = ChatMethod.getMethod().deleteChat(chatid,
						childid);
				return result;
			}
		});

		try {
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			handler.sendMessage(msg);
		}

	}

}
