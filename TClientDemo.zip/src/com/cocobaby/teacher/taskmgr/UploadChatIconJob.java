package com.cocobaby.teacher.taskmgr;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.method.ChatMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.UploadTokenMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.upload.UploadFactory;
import com.cocobaby.teacher.utils.Utils;

public class UploadChatIconJob extends MyJob {
	private Handler handler;
	private Bitmap bitmap = null;
	private long lastid;
	List<ChatInfo> list = new ArrayList<ChatInfo>();
	private String childid;

	public UploadChatIconJob(Handler handler, Bitmap bitmap, long lastid,
			String childid) {
		this.handler = handler;
		this.lastid = lastid;
		this.bitmap = bitmap;
		this.childid = childid;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.SEND_CHAT_FAIL);
		try {
			String url = uploadBmpToServer();
			// 上传到云服务器后，生成的外部链接
			String image = UploadFactory.getUploadHost() + url;
			final String content = InfoHelper.formatChatContent("", image,
					childid, JSONConstant.IMAGE_TYPE);

			MyProxy proxy = new MyProxy();
			MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
				@Override
				public MethodResult handle() throws Exception {
					MethodResult result = ChatMethod.getMethod().sendChat(
							content, lastid, childid);
					return result;
				}
			});

			saveBmpToSDCard(url);
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			handler.sendMessage(msg);
		}

	}

	private void saveBmpToSDCard(String url) throws Exception {
		String path = Utils.getSDCardPicRootPath() + File.separator + url;
		String dir = Utils.getDir(path);
		Utils.makeDirs(dir);
		Log.d("DDD", "saveBmpToSDCard url=" + url);
		Log.d("DDD", "saveBmpToSDCard dir=" + dir);
		Log.d("DDD", "saveBmpToSDCard path=" + path);
		Utils.saveBitmapToSDCard(bitmap, path);
	}

	private String uploadBmpToServer() throws Exception {
		String url = Utils.getChatIconUrl(System.currentTimeMillis());
		String uploadToken = UploadTokenMethod.getMethod().getUploadToken("");
		if (TextUtils.isEmpty(uploadToken)) {
			throw new RuntimeException("getUploadToken failed ");
		}
		UploadFactory.createUploadMgr().uploadPhoto(bitmap, url, uploadToken);
		return url;
	}

}
