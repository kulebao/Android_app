package com.cocobaby.teacher.taskmgr;

import java.util.concurrent.TimeUnit;

import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.method.LoginMethod;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.utils.IMUtils;
import com.cocobaby.teacher.utils.Utils;

public class LoadingJob extends MyJob {

	private Handler hander;
	private static final long LIMIT_TIME = 2000;

	public LoadingJob(Handler handler) {
		this.hander = handler;
	}

	// 检查是否有数据库正在升级，如果有，需要等到升级完毕再执行下一步操作
	private void checkDbUpdate() {
		try {
			// 先等300ms，以免sqliteHelper 的 upgrade还没有触发
			Thread.sleep(300);
			while (MyApplication.getInstance().isDbUpdating()) {
				// 每次等300ms
				Thread.sleep(300);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void run() {
		int resultEvent = EventType.LOADING_TO_MAIN;
		try {
			long current = System.currentTimeMillis();
			TeacherInfo teacherInfo = DataMgr.getInstance().getTeacherInfo();
			if (teacherInfo == null) {
				resultEvent = EventType.LOADING_TO_LOGIN;
			} else {
				checkDbUpdate();

				resultEvent = EventType.LOADING_TO_MAIN;
				// 如果是已经登录过的，每次启动都登录一次，刷新cookie
				if (Utils.isNetworkConnected(MyApplication.getInstance())) {
					LoginMethod.getLoginMethod().login(Utils.getProp(JSONConstant.SELF_PWD),
							teacherInfo.getLogin_name());

					// 已经重新获取了本人的信息
					TeacherInfo newteacherInfo = DataMgr.getInstance().getTeacherInfo();
					if (newteacherInfo.getTimestamp() > teacherInfo.getTimestamp()) {
						resultEvent = EventType.LOADING_TO_MAIN_AND_UPDATE;
					}
				}

				if (!TextUtils.isEmpty(IMUtils.getToken())) {
					IMUtils.connect(IMUtils.getToken());
					// IMUtils.connect(
					// "goRD6aEizPwyMroHrDiNy0mKqBR0xzzHiUbhLnyx3yBK3kaUFLWcHXyretl2aBcdo5RjLCLkI6BGlT5sEFtMyDgGdR7yGDOY0c6/gCy2bR4=");
				}
				Utils.renamePicDir();
			}
			long now = System.currentTimeMillis();
			long ellapse = now - current;
			if (ellapse < LIMIT_TIME) {
				TimeUnit.MILLISECONDS.sleep(LIMIT_TIME - ellapse);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = resultEvent;
			hander.sendMessage(msg);
		}
	}
}
