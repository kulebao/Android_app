package com.cocobaby.teacher.taskmgr;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.info.Homework;
import com.cocobaby.teacher.method.HomeworkMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.UploadTokenMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.upload.UploadFactory;
import com.cocobaby.teacher.utils.Utils;

public class SendHomeworkJob extends MyJob {

	private Handler hander;
	private Homework info;
	private Bitmap bitmap;

	public SendHomeworkJob(Handler handler, Homework info, Bitmap bitmap) {
		this.hander = handler;
		this.info = info;
		this.bitmap = bitmap;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.SEND_HOMEWORK_FAIL);
		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = HomeworkMethod.getMethod().sendHomework(
						info.getTitle(), info.getContent(), info.getClass_id(),
						info.getIcon_url());
				return result;
			}
		});

		try {
			if (bitmap != null) {
				String url = uploadBmpToServer();
				// 上传到云服务器后，生成的外部链接
				String image = UploadFactory.getUploadHost() + url;
				info.setIcon_url(image);
			}

			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			// 成功暂时不要取消对话框，先要保存图片到sd卡
			if (msg.what == EventType.SEND_HOMEWORK_SUCCESS) {
				msg.arg2 = ConstantValue.DO_NOT_CANCEL_DIALOG;
			}
			hander.sendMessage(msg);
		}
	}

	private String uploadBmpToServer() throws Exception {
		String url = Utils.getHomeworkIconUrl(System.currentTimeMillis());
		String uploadToken = UploadTokenMethod.getMethod().getUploadToken("");
		if (TextUtils.isEmpty(uploadToken)) {
			throw new RuntimeException("getUploadToken failed ");
		}
		UploadFactory.createUploadMgr().uploadPhoto(bitmap, url, uploadToken);
		return url;
	}
}
