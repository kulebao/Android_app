package com.cocobaby.teacher.taskmgr;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.utils.Utils;

public class SimpleDownloadImgJob extends MyJob {

	private Handler hander;
	private String url;
	private String filedir;
	private int limitWidth;
	private int limitHeight;

	public SimpleDownloadImgJob(Handler handler, String url, String filedir,
			int limitWidth, int limitHeight) {
		this.hander = handler;
		this.url = url;
		this.filedir = filedir;
		this.limitWidth = limitWidth;
		this.limitHeight = limitHeight;
	}

	@Override
	public void run() {
		int result = EventType.DOWNLOAD_FILE_FAILED;
		try {
			Log.d("DDD", "DownLoadImgAndSaveTask downloadImgImpl url=" + url);
			// Bitmap bmp = Utils.downloadImgImpl(url);
			Bitmap bmp = Utils.downloadImgWithJudgement(url, limitWidth,
					limitHeight);
			if (bmp != null) {
				try {
					Log.d("DDD", "downloadImgImpl saveBitmapToSDCard");
					Utils.saveBitmapToSDCard(bmp, filedir);
					result = EventType.DOWNLOAD_FILE_SUCCESS;
				} catch (Exception e) {
					e.printStackTrace();
				}
			} else {
				Log.d("DDD", "downloadImgImpl failed url=" + url);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = result;
			hander.sendMessage(msg);
		}
	}
}
