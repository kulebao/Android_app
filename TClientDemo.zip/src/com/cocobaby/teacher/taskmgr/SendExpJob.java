package com.cocobaby.teacher.taskmgr;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.method.ExpMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.UploadTokenMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.upload.QiniuMgr;
import com.cocobaby.teacher.upload.UploadFactory;
import com.cocobaby.teacher.utils.Utils;

public class SendExpJob extends MyJob {
	private static final int STANDARD_PIC = 1080 * 1080;
	private Handler handler;
	private String childids;
	private String text;
	private List<String> mediums;
	private String mediumType;
	private Map<String, String> map = new HashMap<String, String>();

	public SendExpJob(Handler handler, String text, String childids, List<String> mediums, String mediumType) {
		this.handler = handler;
		this.text = text;
		this.childids = childids;
		this.mediums = mediums;
		this.mediumType = mediumType;
		Log.d("", "SendExpJob childids=" + childids);
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.POST_EXP_FAIL);
		try {
			uploadFileToServer();

			final String content = getContent();
			MyProxy proxy = new MyProxy();
			MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
				@Override
				public MethodResult handle() throws Exception {
					MethodResult result = ExpMethod.getMethod().sendExp(content, childids, map);
					return result;
				}
			});

			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bret.getResultObj();
			handler.sendMessage(msg);
			map.clear();
		}

	}

	private String getContent() throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(JSONConstant.TOPIC, childids);
		jsonObject.put(ExpInfo.CONTENT, text);

		JSONObject senderObj = new JSONObject();

		String server_id = DataMgr.getInstance().getTeacherInfo().getServer_id();
		senderObj.put(JSONConstant.ID, server_id);
		senderObj.put(JSONConstant.TYPE, ExpInfo.TEACHER_TYPE);

		jsonObject.put(JSONConstant.SENDER, senderObj);

		if (!mediums.isEmpty()) {
			JSONArray array = new JSONArray();
			for (String url : mediums) {
				JSONObject object = new JSONObject();
				String serverUrl = UploadFactory.getUploadHost() + Utils.getExpRelativePath(url);
				object.put(JSONConstant.URL, serverUrl);
				object.put(JSONConstant.TYPE, mediumType);
				array.put(object);
				Log.d("", "AAA send exp serverUrl="+serverUrl);
				Log.d("", "AAA send exp url="+url);
				map.put(serverUrl, url);
			}

			jsonObject.put(ExpInfo.MEDIUM, array);
		}

		return jsonObject.toString();
	}

	private void uploadFileToServer() throws Exception {
		String uploadToken = UploadTokenMethod.getMethod().getUploadToken("");
		if (TextUtils.isEmpty(uploadToken)) {
			throw new RuntimeException("getUploadToken failed ");
		}

		for (int i = 0; i < mediums.size(); i++) {
			String sdCardPath = mediums.get(i);
			String name = Utils.getExpRelativePath(sdCardPath);
			uploadImpl(uploadToken, sdCardPath, name);
			sendProgressEvent(i + 2);
		}

	}

	private void sendProgressEvent(int progress) {
		Message obtain = Message.obtain();
		obtain.what = EventType.UPLOAD_ICON_SUCCESS;
		obtain.arg1 = progress;
		obtain.arg2 = ConstantValue.DO_NOT_CANCEL_DIALOG;
		handler.sendMessage(obtain);
	}

	private void uploadImpl(String uploadToken, String url, String name) throws Exception {
		if (JSONConstant.IMAGE_TYPE.equals(mediumType)) {
			uploadPhoto(uploadToken, url, name);
		} else {
			uploadFile(uploadToken, url, name);
		}
	}

	private void uploadFile(String uploadToken, String url, String name) throws Exception {
		try {
			uploadFileImpl(uploadToken, url, name);
		} catch (Exception e) {
			e.printStackTrace();
			Thread.sleep(500);
			uploadFileImpl(uploadToken, url, name);
		}
	}

	private void uploadFileImpl(String uploadToken, String url, String name) throws Exception {
		QiniuMgr uploadMgr = UploadFactory.createUploadMgr();
		uploadMgr.uploadFile(url, name, uploadToken);
	}

	// 图片需要先压缩，控制最大值
	private void uploadPhoto(String uploadToken, String url, String name) throws Exception {
		Bitmap bitmap = Utils.getLoacalBitmap(url, STANDARD_PIC);
		Log.d("DJC", "Size =" + bitmap.getRowBytes() * bitmap.getHeight());

		try {
			// uploadMgr.uploadPhoto(url, name, uploadToken);
			uploadPhotoImpl(uploadToken, name, bitmap);
		} catch (Exception e) {
			e.printStackTrace();
			Thread.sleep(500);
			uploadPhotoImpl(uploadToken, name, bitmap);
		}
	}

	private void uploadPhotoImpl(String uploadToken, String name, Bitmap bitmap) throws Exception {
		QiniuMgr uploadMgr = UploadFactory.createUploadMgr();
		uploadMgr.uploadPhoto(bitmap, name, uploadToken);
	}
}
