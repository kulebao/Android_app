package com.cocobaby.teacher.taskmgr;

import java.util.concurrent.TimeUnit;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.threadpool.MyJob;

public class AuthCodeCountDownJob extends MyJob {

	private Handler hander;
	// 倒计时时长，秒为单位
	private int timeLimit;

	public AuthCodeCountDownJob(Handler handler, int timeLimit) {
		this.hander = handler;
		this.timeLimit = timeLimit;
	}

	@Override
	public void run() {
		try {
			for (int i = timeLimit; i >= 0; i--) {
				TimeUnit.SECONDS.sleep(1);
				Message msg = Message.obtain();
				msg.what = EventType.AUTHCODE_COUNTDOWN_GO;
				msg.arg2 = ConstantValue.DO_NOT_CANCEL_DIALOG;
				msg.arg1 = i;
				hander.sendMessage(msg);
			}
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = EventType.AUTHCODE_COUNTDOWN_OVER;
			msg.arg2 = ConstantValue.DO_NOT_CANCEL_DIALOG;
			hander.sendMessage(msg);
		}
	}

}
