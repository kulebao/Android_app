package com.cocobaby.teacher.taskmgr;

import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.method.TeacherMethod;
import com.cocobaby.teacher.method.UploadTokenMethod;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;
import com.cocobaby.teacher.upload.UploadFactory;
import com.cocobaby.teacher.utils.Utils;

public class PostTeacherJob extends MyJob {

	private Handler hander;
	private TeacherInfo info;
	private Bitmap bitmap = null;

	public PostTeacherJob(Handler handler, TeacherInfo info) {
		this.hander = handler;
		this.info = info;
	}

	public void setBitmap(Bitmap bitmap) {
		this.bitmap = bitmap;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.POST_TEACHER_FAIL);
		String outUrl = null;
		try {
			outUrl = uploadHeadIcon();

			if (outUrl != null) {
				info.setPortrait(outUrl);
			}

			MyProxy proxy = new MyProxy();
			MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
				@Override
				public MethodResult handle() throws Exception {
					MethodResult result = TeacherMethod.getMethod().postInfo(info);
					return result;
				}
			});

			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			msg.obj = bitmap;
			hander.sendMessage(msg);
		}
	}

	private String uploadHeadIcon() throws Exception {
		String outUrl = null;
		if (bitmap != null) {
			// url 是保存在云存储的相对路径
			String internalUrl = Utils.getUploadTeacherIconUrl();
			// 公网地址
			outUrl = UploadFactory.getUploadHost() + internalUrl;

			String uploadToken = UploadTokenMethod.getMethod().getUploadToken(internalUrl);
			if (TextUtils.isEmpty(uploadToken)) {
				throw new Exception("get uploadtoken failed");
			}
			// OSSMgr.UploadPhoto(bitmap,url);
			UploadFactory.createUploadMgr().uploadPhoto(bitmap, internalUrl, uploadToken);
		}
		return outUrl;
	}
}
