package com.cocobaby.teacher.taskmgr;

import android.os.Handler;
import android.os.Message;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.method.EstimateMethod;
import com.cocobaby.teacher.method.MethodResult;
import com.cocobaby.teacher.proxy.MyProxy;
import com.cocobaby.teacher.proxy.MyProxyImpl;
import com.cocobaby.teacher.threadpool.MyJob;

public class PostEstimateJob extends MyJob {

	private Handler hander;
	private EstimateInfo info;
	private String childid;

	public PostEstimateJob(Handler handler, EstimateInfo info) {
		this.hander = handler;
		this.info = info;
	}

	@Override
	public void run() {
		MethodResult bret = new MethodResult(EventType.POST_ESTIMATE_FAIL);

		MyProxy proxy = new MyProxy();
		MyProxyImpl bind = (MyProxyImpl) proxy.bind(new MyProxyImpl() {
			@Override
			public MethodResult handle() throws Exception {
				MethodResult result = EstimateMethod.getMethod().postInfo(childid, info);
				return result;
			}
		});
		try {
			bret = (MethodResult) bind.handle();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			Message msg = Message.obtain();
			msg.what = bret.getResultType();
			hander.sendMessage(msg);
		}
	}
}
