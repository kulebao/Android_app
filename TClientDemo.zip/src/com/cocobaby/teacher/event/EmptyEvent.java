package com.cocobaby.teacher.event;

public class EmptyEvent {

}
