package com.cocobaby.teacher.listdata;

import java.util.Comparator;

import net.sourceforge.pinyin4j.PinyinHelper;

import com.cocobaby.teacher.dbmgr.info.ChildStatus;

public class ChildComparator implements Comparator<ChildSummary> {

	@Override
	public int compare(ChildSummary o1, ChildSummary o2) {
		int ret = compareStatus(o1, o2);
		if (ret != 0) {
			return ret;
		}

		ret = compareNoticeType(o1, o2);
		if (ret != 0) {
			return ret;
		}

		ret = compareName(o1.getInfo().getName(), o2.getInfo().getName());
		return ret;
	}

	int compareStatus(ChildSummary o1, ChildSummary o2) {
		if (o1.getStatus().isEmptyStatus() == o2.getStatus().isEmptyStatus()) {
			return 0;
		}
		// 没刷卡的排最前面
		return o1.getStatus().isEmptyStatus() ? -1 : 1;
	}

	int compareNoticeType(ChildSummary o1, ChildSummary o2) {
		if (o1.getStatus().getNotice_type() == o2.getStatus().getNotice_type()) {
			return 0;
		}
		// 离园的排在在园的前面
		return o1.getStatus().getNotice_type() == ChildStatus.SWIPE_OUT ? -1
				: 1;
	}

	public int compareName(String name1, String name2) {
		if (name1.equals(name2)) {
			return 0;
		}

		// 只比较了第一个字，也就是姓，简单点，够用了
		char c1 = name1.charAt(0);
		char c2 = name2.charAt(0);
		return concatPinyinStringArray(
				PinyinHelper.toHanyuPinyinStringArray(c1)).compareTo(
				concatPinyinStringArray(PinyinHelper
						.toHanyuPinyinStringArray(c2)));
	}

	private String concatPinyinStringArray(String[] pinyinArray) {
		StringBuffer pinyinSbf = new StringBuffer();
		if ((pinyinArray != null) && (pinyinArray.length > 0)) {
			for (int i = 0; i < pinyinArray.length; i++) {
				pinyinSbf.append(pinyinArray[i]);
			}
		}
		return pinyinSbf.toString();
	}
}