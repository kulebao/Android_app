package com.cocobaby.teacher.listdata;

import java.util.Comparator;

import net.sourceforge.pinyin4j.PinyinHelper;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;

public class ChildFeedbackComparator implements Comparator<ChildInfo> {

	@Override
	public int compare(ChildInfo o1, ChildInfo o2) {
		int ret = compareStatus(o1, o2);
		if (ret != 0) {
			return ret;
		}

		ret = compareName(o1.getName(), o2.getName());
		return ret;
	}

	int compareStatus(ChildInfo o1, ChildInfo o2) {
		if (o1.isFeedback() == o2.isFeedback()) {
			return 0;
		}
		// 没刷卡的排最前面
		return o1.isFeedback() ? 1 : -1;
	}

	public int compareName(String name1, String name2) {
		if (name1.equals(name2)) {
			return 0;
		}

		// 只比较了第一个字，也就是姓，简单点，够用了
		char c1 = name1.charAt(0);
		char c2 = name2.charAt(0);
		return concatPinyinStringArray(
				PinyinHelper.toHanyuPinyinStringArray(c1)).compareTo(
				concatPinyinStringArray(PinyinHelper
						.toHanyuPinyinStringArray(c2)));
	}

	private String concatPinyinStringArray(String[] pinyinArray) {
		StringBuffer pinyinSbf = new StringBuffer();
		if ((pinyinArray != null) && (pinyinArray.length > 0)) {
			for (int i = 0; i < pinyinArray.length; i++) {
				pinyinSbf.append(pinyinArray[i]);
			}
		}
		return pinyinSbf.toString();
	}
}