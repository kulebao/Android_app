package com.cocobaby.teacher.listdata;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ClassInfo;

public class MultiSelectedInfo {
	private boolean isClassSelected = false;

	private ClassInfo info;
	private List<SimpleChildInfo> childList = new ArrayList<SimpleChildInfo>();

	public boolean isClassSelected() {
		return isClassSelected;
	}

	public void setClassSelected(boolean isClassSelected) {
		this.isClassSelected = isClassSelected;
	}

	public List<SimpleChildInfo> getChildList() {
		return childList;
	}

	public void setChildList(List<SimpleChildInfo> childList) {
		this.childList = childList;
	}

	public ClassInfo getInfo() {
		return info;
	}

	public void setInfo(ClassInfo info) {
		this.info = info;
	}

}
