package com.cocobaby.teacher.listdata;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;

public class SimpleClassSummary {
	private ClassInfo info = new ClassInfo();
	private List<ChildInfo> childList = new ArrayList<ChildInfo>();

	public List<ChildInfo> getChildList() {
		return childList;
	}

	public void setChildList(List<ChildInfo> childList) {
		this.childList = childList;
	}

	public ClassInfo getInfo() {
		return info;
	}

	public void setInfo(ClassInfo info) {
		this.info = info;
	}

}
