package com.cocobaby.teacher.listdata;

import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ChildStatus;

public class ChildSummary {
	private ChildInfo info = new ChildInfo();
	private ChildStatus status = new ChildStatus();
	private ChatInfo lastChatInfo = new ChatInfo();

	private boolean hasNewChat = false;

	public boolean isHasNewChat() {
		return hasNewChat;
	}

	public void setHasNewChat(boolean hasNewChat) {
		this.hasNewChat = hasNewChat;
	}

	public ChatInfo getLastChatInfo() {
		return lastChatInfo;
	}

	public void setLastChatInfo(ChatInfo lastChatInfo) {
		this.lastChatInfo = lastChatInfo;
	}

	public ChildInfo getInfo() {
		return info;
	}

	public void setInfo(ChildInfo info) {
		this.info = info;
	}

	public ChildStatus getStatus() {
		return status;
	}

	public void setStatus(ChildStatus status) {
		this.status = status;
	}

}
