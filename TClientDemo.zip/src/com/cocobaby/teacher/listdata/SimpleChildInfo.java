package com.cocobaby.teacher.listdata;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;

public class SimpleChildInfo {
	private boolean bSelected;

	private String name;
	private String headicon;

	private String child_id;

	public String getChild_id() {
		return child_id;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public boolean isbSelected() {
		return bSelected;
	}

	public void setbSelected(boolean bSelected) {
		this.bSelected = bSelected;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHeadicon() {
		return headicon;
	}

	public void setHeadicon(String headicon) {
		this.headicon = headicon;
	}

	public static List<SimpleChildInfo> childInfoToSimpleChildInfo(
			List<ChildInfo> childInfos) {
		List<SimpleChildInfo> list = new ArrayList<SimpleChildInfo>();

		for (ChildInfo childInfo : childInfos) {
			SimpleChildInfo simpleChildInfo = new SimpleChildInfo();
			simpleChildInfo.setHeadicon(childInfo.getChildrenLocalIconPath());
			simpleChildInfo.setName(childInfo.getName());
			simpleChildInfo.setChild_id(childInfo.getServerID());
			list.add(simpleChildInfo);
		}
		return list;
	}

}
