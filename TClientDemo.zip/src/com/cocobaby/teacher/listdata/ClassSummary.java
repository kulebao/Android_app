package com.cocobaby.teacher.listdata;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ClassInfo;

public class ClassSummary {
	private ClassInfo info;
	private List<ChildSummary> childList = new ArrayList<ChildSummary>();

	public List<ChildSummary> getChildList() {
		return childList;
	}

	public void setChildList(List<ChildSummary> childList) {
		this.childList = childList;
	}

	public ClassInfo getInfo() {
		return info;
	}

	public void setInfo(ClassInfo info) {
		this.info = info;
	}

}
