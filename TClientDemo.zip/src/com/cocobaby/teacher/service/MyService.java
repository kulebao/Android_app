package com.cocobaby.teacher.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class MyService extends Service {

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	@Override
	public void onCreate() {
		super.onCreate();
		Log.d("DJC 10-16", "MyService onCreate");
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		// try {
		// int type = getCommand(intent);
		// Command command = CommandFactory.getCommandFactory().createCommand(
		// type);
		// command.execute();
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		return START_STICKY;
	}

}
