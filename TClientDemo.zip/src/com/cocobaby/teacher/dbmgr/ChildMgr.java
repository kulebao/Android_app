package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;

class ChildMgr {
	private SqliteHelper dbHelper;

	ChildMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	void addDataList(List<ChildInfo> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		writableDatabase.beginTransaction(); // 手动设置开始事务

		try {
			for (ChildInfo info : list) {
				ContentValues values = buildInfo(info);
				writableDatabase
						.insertWithOnConflict(SqliteHelper.CHILD_TAB, null, values, SQLiteDatabase.CONFLICT_REPLACE);
			}
			// 数据插入操作循环
			writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
		} finally{
			writableDatabase.endTransaction(); // 处理完成
		}
	}

	List<ChildInfo> getChildByClass(int classid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CHILD_TAB + " WHERE " + ChildInfo.CLASS_ID + " = "
				+ classid + " ORDER BY " + ChildInfo.CHILD_NAME, null);

		return getList(cursor);
	}

	ChildInfo getChildByID(String child_id) {
		Cursor cursor = null;
		ChildInfo info = null;
		try {
			SQLiteDatabase db = dbHelper.getReadableDatabase();
			String sql = "SELECT * FROM " + SqliteHelper.CHILD_TAB + " WHERE " + ChildInfo.CHILD_ID + " = '" + child_id
					+ "'";
			Log.w("getChildByID ", "sql =" + sql);
			cursor = db.rawQuery(sql, null);

			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				break;
			}

		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return info;
	}

	List<ChildInfo> getAllChild() {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CHILD_TAB + " ORDER BY " + ChildInfo.CHILD_NAME,
				null);

		return getList(cursor);
	}

	void clear() {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM " + SqliteHelper.CHILD_TAB);
	}

	private List<ChildInfo> getList(Cursor cursor) {
		List<ChildInfo> list = new ArrayList<ChildInfo>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				ChildInfo info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	ContentValues buildInfo(ChildInfo info) {
		ContentValues values = new ContentValues();
		values.put(ChildInfo.CLASS_NAME, info.getClass_name());
		values.put(ChildInfo.CLASS_ID, info.getClass_id());
		values.put(ChildInfo.BIRTHDAY, info.getBirthday());
		values.put(ChildInfo.CHILD_ID, info.getServerID());
		values.put(ChildInfo.CHILD_NAME, info.getName());
		values.put(ChildInfo.NICK, info.getNick());
		values.put(ChildInfo.PORTRAIT, info.getPortrait());
		values.put(ChildInfo.TIMESTAMP, info.getTimestamp());
		return values;
	}

	private ChildInfo getDataByCursor(Cursor cursor) {
		ChildInfo info = new ChildInfo();

		info.setId(cursor.getInt(0));
		info.setBirthday(cursor.getString(1));
		info.setServerID(cursor.getString(2));
		info.setName(cursor.getString(3));
		info.setClass_id(cursor.getInt(4));
		info.setClass_name(cursor.getString(5));
		info.setNick(cursor.getString(6));
		info.setPortrait(cursor.getString(7));
		info.setTimestamp(cursor.getLong(8));
		return info;
	}
}
