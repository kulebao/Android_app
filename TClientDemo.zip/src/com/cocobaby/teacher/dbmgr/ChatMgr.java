package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cocobaby.teacher.dbmgr.info.ChatInfo;

class ChatMgr {
	private SqliteHelper dbHelper;

	ChatMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	void addDataList(List<ChatInfo> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		writableDatabase.beginTransaction(); // 手动设置开始事务

		try {
			for (ChatInfo info : list) {
				ContentValues values = buildInfo(info);
				writableDatabase.insertWithOnConflict(SqliteHelper.CHAT_TAB,
						null, values, SQLiteDatabase.CONFLICT_REPLACE);
			}
			// 数据插入操作循环
			writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
		} finally {
			writableDatabase.endTransaction(); // 处理完成
		}
	}

	void clear() {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM " + SqliteHelper.CHAT_TAB);
	}

	// 返回最多max条chat记录，按照timestamp倒序，再将此list倒序排列
	List<ChatInfo> getChatInfoWithLimite(int max, String childid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CHAT_TAB
				+ " WHERE " + ChatInfo.CHILD_ID + "='" + childid
				+ "' ORDER BY " + ChatInfo.TIMESTAMP + " DESC LIMIT " + max,
				null);
		List<ChatInfo> list = getChatInfoList(cursor);
		if (!list.isEmpty()) {
			Collections.reverse(list);
		}
		return list;
	}

	// 返回小于to的所有chat，最多max条，按照timestamp倒序，再将此list倒序排列
	List<ChatInfo> getChatInfoWithLimite(int max, long to, String childid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CHAT_TAB
				+ " WHERE " + ChatInfo.CHILD_ID + "='" + childid + "' AND "
				+ ChatInfo.TIMESTAMP + " < " + to + " ORDER BY "
				+ ChatInfo.TIMESTAMP + " DESC LIMIT " + max, null);
		List<ChatInfo> list = getChatInfoList(cursor);
		if (!list.isEmpty()) {
			Collections.reverse(list);
		}
		return list;
	}

	// 返回该小孩最后一条家户互动记录
	ChatInfo getLastChatInfo(String childid) {
		ChatInfo info = null;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CHAT_TAB
				+ " WHERE " + ChatInfo.CHILD_ID + "='" + childid
				+ "' ORDER BY " + ChatInfo.CHAT_ID + " DESC LIMIT " + 1, null);

		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				break;
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return info;
	}

	Map<String, ChatInfo> getAllChildLastChatMap() {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery(
				"SELECT * FROM chat_tab as c1 ,(SELECT MAX(timestamp),"
						+ "chat_id FROM chat_tab GROUP BY child_id) AS c2 "
						+ "WHERE c1.chat_id = c2.chat_id", null);
		Map<String, ChatInfo> map = getChatInfoMap(cursor);

		return map;
	}

	private Map<String, ChatInfo> getChatInfoMap(Cursor cursor) {
		Map<String, ChatInfo> map = new HashMap<String, ChatInfo>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				ChatInfo info = getDataByCursor(cursor);
				map.put(info.getChild_id(), info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return map;
	}

	private List<ChatInfo> getChatInfoList(Cursor cursor) {
		List<ChatInfo> list = new ArrayList<ChatInfo>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				ChatInfo info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	void deleteChat(long chatid) {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM " + SqliteHelper.CHAT_TAB + " WHERE "
				+ ChatInfo.CHAT_ID + " = " + chatid);
	}

	private ContentValues buildInfo(ChatInfo info) {
		ContentValues values = new ContentValues();
		values.put(ChatInfo.CHAT_ID, info.getChat_id());
		values.put(ChatInfo.CHILD_ID, info.getChild_id());
		values.put(ChatInfo.CONTENT, info.getContent());
		values.put(ChatInfo.MEDIA_TYPE, info.getMedia_type());
		values.put(ChatInfo.MEDIA_URL, info.getMedia_url());
		values.put(ChatInfo.SENDER_ID, info.getSender_id());
		values.put(ChatInfo.SENDER_TYPE, info.getSender_type());
		values.put(ChatInfo.TIMESTAMP, info.getTimestamp());
		return values;
	}

	private ChatInfo getDataByCursor(Cursor cursor) {
		ChatInfo info = new ChatInfo();

		info.setId(cursor.getInt(0));
		info.setChat_id(cursor.getLong(1));
		info.setChild_id(cursor.getString(2));
		info.setContent(cursor.getString(3));
		info.setMedia_type(cursor.getString(4));
		info.setMedia_url(cursor.getString(5));
		info.setSender_id(cursor.getString(6));
		info.setSender_type(cursor.getString(7));
		info.setTimestamp(cursor.getLong(8));
		return info;
	}
}
