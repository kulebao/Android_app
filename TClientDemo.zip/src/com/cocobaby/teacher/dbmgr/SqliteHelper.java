package com.cocobaby.teacher.dbmgr;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.dbmgr.info.Homework;
import com.cocobaby.teacher.dbmgr.info.IMGroupInfo;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.dbmgr.info.RelationshipMap;
import com.cocobaby.teacher.dbmgr.info.SchoolInfo;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;

public class SqliteHelper extends SQLiteOpenHelper{
    public static final String TEACHER_TAB           = "teacher_tab";
    public static final String CLASS_TAB             = "class_tab";
    public static final String CHILD_TAB             = "child_tab";
    public static final String CHAT_TAB              = "chat_tab";
    public static final String PARENT_TAB            = "parent_tab";
    public static final String RELATIONSHIP_TAB      = "relationship_tab";
    public static final String EDUCATION_TAB         = "education_tab";
    public static final String EXP_TAB               = "exp_tab";
    public static final String MONTH_TAB             = "month_tab";
    public static final String NEWS_TAB              = "news_tab";
    public static final String HOMEWORK_TAB          = "homework_tab";
    public static final String IM_GROUP_TAB          = "im_group_tab";
    public static final String SCHOOL_INFO_TAB         = "school_info_tab";
    // 家长自己从本地选择多媒体资源发送，需要保存文件路径，否则又要从服务器上下载
    public static final String NATIVE_MEDIUM_URL_TAB = "native_medium_url_tab";

    public SqliteHelper(Context context, String name, CursorFactory factory, int version){
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        addTeacherTab(db);

        addClassTab(db);

        addRelationTab(db);

        addSchoolInfoTab(db);
        
        addChildTab(db);

        addChatTab(db);

        addExpTab(db);

        addParentTab(db);

        addEduTab(db);

        addNewsTab(db);

        addHomeworkTab(db);

        addNativeMediumUrlTab(db);

        initMonthTab(db);

        addIMGroupTab(db);
        // db.execSQL("create index rindex on contacttab(rosterid)");
        // db.execSQL("create index ismashupedindex on contacttab(ismashuped)");
        Log.d("Database", "onCreate");
    }

    void addIMGroupTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + IM_GROUP_TAB + "(" + IMGroupInfo.ID
                + " integer primary key autoincrement," + IMGroupInfo.CLASS_ID + " integer," + IMGroupInfo.GROUP_ID
                + " varchar, " + IMGroupInfo.GROUP_NAME + " varchar, " + " UNIQUE(" + IMGroupInfo.GROUP_ID + ") " + ")");
    }

    void addNativeMediumUrlTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + NATIVE_MEDIUM_URL_TAB + "(" + NativeMediumInfo.ID
                + " integer primary key autoincrement," + NativeMediumInfo.KEY + " varchar,"
                + NativeMediumInfo.LOCAL_URL + " varchar," + NativeMediumInfo.LOCAL_NAIL_URL + " varchar," + "UNIQUE("
                + NativeMediumInfo.KEY + ") " + ")");
    }

    void addHomeworkTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + HOMEWORK_TAB + "(" + Homework.ID
                + " integer primary key autoincrement," + Homework.TITLE + " varchar," + Homework.CONTENT + " varchar,"
                + Homework.TIMESTAMP + " biginteger ," + Homework.ICON_URL + " varchar," + Homework.SERVER_ID
                + " integer," + Homework.CLASS_ID + " integer," + Homework.PUBLISHER + " varchar," + "UNIQUE("
                + Homework.SERVER_ID + ") " + ")");
    }

    void addEduTab(SQLiteDatabase db){
        // 每个小孩只保留最近一条评价，所以把CHILD_ID也作为unique字段
        db.execSQL("CREATE TABLE IF NOT EXISTS " + EDUCATION_TAB + "(" + EstimateInfo.ID
                + " integer primary key autoincrement," + EstimateInfo.SERVER_ID + " integer," + EstimateInfo.TIMESTAMP
                + " biginteger," + EstimateInfo.PUBLISHER + " varchar ," + EstimateInfo.COMMENTS + " varchar,"
                + EstimateInfo.EMOTION + " integer," + EstimateInfo.DINING + " integer," + EstimateInfo.REST
                + " integer," + EstimateInfo.ACTIVITY + " integer," + EstimateInfo.EXERCISE + " integer,"
                + EstimateInfo.SELF_CARE + " integer," + EstimateInfo.MANNER + " integer," + EstimateInfo.GAME
                + " integer," + EstimateInfo.CHILD_ID + " varchar," + "UNIQUE(" + EstimateInfo.SERVER_ID + "), "
                + "UNIQUE(" + EstimateInfo.CHILD_ID + ") " + ")");
    }

    void addParentTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + PARENT_TAB + "(" + ParentInfo.ID
                + " integer primary key autoincrement," + ParentInfo.CARD_NUMBER + " varchar,"
                + ParentInfo.MEMBER_STATUS + " integer, " + ParentInfo.PARENT_ID + " varchar, "
                + ParentInfo.PARENT_NAME + " varchar, " + ParentInfo.PHONE + " varchar, " + ParentInfo.PORTRAIT
                + " varchar, " + ParentInfo.TIMESTAMP + " biginteger, "

                + ParentInfo.RELATIONSHIP + " varchar, " + ParentInfo.INTERNAL_ID + " integer, "

                + " UNIQUE(" + ParentInfo.PARENT_ID + ") " + ")");
    }

    void addExpTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + EXP_TAB + "(" + ExpInfo.ID + " integer primary key autoincrement,"
                + ExpInfo.EXP_ID + " biginteger," + ExpInfo.CHILD_ID + " varchar, " + ExpInfo.CONTENT + " varchar, "
                + ExpInfo.MEDIUM + " varchar, " + ExpInfo.SENDER_ID + " varchar, " + ExpInfo.SENDER_TYPE + " varchar, "
                + ExpInfo.TIMESTAMP + " biginteger, " + " UNIQUE(" + ExpInfo.EXP_ID + ") " + ")");

        // 创建索引
        db.execSQL("CREATE INDEX IF NOT EXISTS timeindex on " + EXP_TAB + "(" + ExpInfo.TIMESTAMP + ")");
    }

    void addNewsTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + NEWS_TAB + "(" + News.ID + " integer primary key autoincrement,"
                + News.TITLE + " varchar," + News.CONTENT + " varchar," + News.TIMESTAMP + " biginteger ,"
                + News.NEWS_TYPE + " integer," + News.NEWS_SERVER_ID + " integer," + News.PUBLISHER + " varchar,"
                + News.ICON_URL + " varchar," + News.CLASS_ID + " integer," + News.NEED_RECEIPT + " integer,"
                + News.TAGS + " varchar," + "UNIQUE(" + News.NEWS_SERVER_ID + ") " + ")");
    }
    
    void addSchoolInfoTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + SCHOOL_INFO_TAB + "(" + SchoolInfo.ID
                + " integer primary key autoincrement," + SchoolInfo.SCHOOL_ID + " varchar," + SchoolInfo.SCHOOL_NAME
                + " varchar," + SchoolInfo.SCHOOL_PHONE + " varchar," + SchoolInfo.SCHOOL_DESC + " varchar,"
                + SchoolInfo.SCHOOL_LOCAL_URL + " integer," + SchoolInfo.SCHOOL_SERVER_URL + " varchar,"
                + SchoolInfo.TIMESTAMP + " varchar," + "UNIQUE(" + SchoolInfo.SCHOOL_ID + ") " + ")");
    }

    void addChatTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + CHAT_TAB + "(" + ChatInfo.ID + " integer primary key autoincrement,"
                + ChatInfo.CHAT_ID + " biginteger," + ChatInfo.CHILD_ID + " varchar, " + ChatInfo.CONTENT
                + " varchar, " + ChatInfo.MEDIA_TYPE + " varchar, " + ChatInfo.MEDIA_URL + " varchar, "
                + ChatInfo.SENDER_ID + " varchar, " + ChatInfo.SENDER_TYPE + " varchar, " + ChatInfo.TIMESTAMP
                + " biginteger, " + " UNIQUE(" + ChatInfo.CHAT_ID + ") " + ")");

        // 对CHAT_TAB的CHILD_ID字段创建索引
        db.execSQL("CREATE INDEX IF NOT EXISTS idindex on " + CHAT_TAB + "(" + ChatInfo.CHILD_ID + ")");
    }

    void addChildTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + CHILD_TAB + "(" + ChildInfo.ID
                + " integer primary key autoincrement," + ChildInfo.BIRTHDAY + " varchar," + ChildInfo.CHILD_ID
                + " varchar, " + ChildInfo.CHILD_NAME + " varchar, " + ChildInfo.CLASS_ID + " integer, "
                + ChildInfo.CLASS_NAME + " varchar, " + ChildInfo.NICK + " varchar, " + ChildInfo.PORTRAIT
                + " varchar, " + ChildInfo.TIMESTAMP + " biginteger, " + " UNIQUE(" + ChildInfo.CHILD_ID + ") " + ")");
    }

    void addRelationTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + RELATIONSHIP_TAB + "(" + RelationshipMap.ID
                + " integer primary key autoincrement," + RelationshipMap.CHILD_ID + " varchar,"
                + RelationshipMap.PARENT_ID + " varchar, " + RelationshipMap.RELATIONSHIP + " varchar, " + " UNIQUE("
                + RelationshipMap.CHILD_ID + "," + RelationshipMap.PARENT_ID + ") " + ")");
    }

    void addClassTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + CLASS_TAB + "(" + ClassInfo.ID
                + " integer primary key autoincrement," + ClassInfo.CLASS_NAME + " varchar," + ClassInfo.CLASS_ID
                + " integer, " + " UNIQUE(" + ClassInfo.CLASS_ID + ") " + ")");
    }

    void addTeacherTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TEACHER_TAB + "(" + TeacherInfo.ID
                + " integer primary key autoincrement," + TeacherInfo.NAME + " varchar," + TeacherInfo.PHONE
                + " varchar," + TeacherInfo.TIMESTAMP + " biginteger, " + TeacherInfo.LOGIN_NAME + " varchar, "
                + TeacherInfo.PORTRAIT + " varchar, " + TeacherInfo.SERVER_ID + " varchar, " + TeacherInfo.PWD
                + " varchar, " + TeacherInfo.WORKDUTY + " varchar, " + TeacherInfo.WORKGROUP + " varchar, "
                + TeacherInfo.BIRTHDAY + " varchar, " + TeacherInfo.GENDER + " integer, " + TeacherInfo.UID
                + " biginteger DEFAULT 0, " + "UNIQUE(" + TeacherInfo.SERVER_ID + ") " + ")");
    }

    void initMonthTab(SQLiteDatabase db){
        db.execSQL("CREATE TABLE IF NOT EXISTS " + MONTH_TAB + "(month_name varchar)");
        db.beginTransaction(); // 手动设置开始事务
        try{
            for(int i = 1; i < 13; i++){
                String month = "";
                if(i < 10){
                    month = "0" + i;
                } else{
                    month = "" + i;
                }
                ContentValues values = new ContentValues();
                values.put("month_name", month);
                db.insertWithOnConflict(SqliteHelper.MONTH_TAB, null, values, SQLiteDatabase.CONFLICT_REPLACE);
            } // 数据插入操作循环
            db.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
        }
        finally{
            db.endTransaction(); // 处理完成
        }
    }

    @Override
    // 当数据库升级时，可以根据oldVersion，newVersion来做一些数据迁移，更新的操作
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){
        Log.d("Database", "onUpgrade begain");
        long current = System.currentTimeMillis();
        try{
            MyApplication.getInstance().setDbUpdating(true);
            new UpgradeDbHelper(db, this).upgradeDb();
        } catch(Exception e){
            e.printStackTrace();
        }
        finally{
            MyApplication.getInstance().setDbUpdating(false);
        }
        Log.d("Database", "onUpgrade over time =" + (System.currentTimeMillis() - current));
    }

    public void clearAll(SQLiteDatabase db){
        db.execSQL("DROP TABLE IF EXISTS " + TEACHER_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + CLASS_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + CHILD_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + RELATIONSHIP_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + PARENT_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + CHAT_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + EDUCATION_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + EXP_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + NEWS_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + HOMEWORK_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + NATIVE_MEDIUM_URL_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + SCHOOL_INFO_TAB);
        db.execSQL("DROP TABLE IF EXISTS " + IM_GROUP_TAB);
        onCreate(db);
    }
}
