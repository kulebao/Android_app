package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.dbmgr.info.RelationshipMap;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

class ParentMgr {
	private SqliteHelper dbHelper;
	private DataMgr datamgr;
	private static final String IMPOSSIBLE_RELATION = "-1233>?XX!UY21";

	ParentMgr(SqliteHelper dbHelper, DataMgr datamgr) {
		this.dbHelper = dbHelper;
		this.datamgr = datamgr;
	}

	void addData(ParentInfo info) {
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		ContentValues values = buildInfo(info);
		writableDatabase.insertWithOnConflict(SqliteHelper.PARENT_TAB, null, values, SQLiteDatabase.CONFLICT_REPLACE);
	}

	List<ParentInfo> getAllParents() {
		List<ParentInfo> list = new ArrayList<>();
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.PARENT_TAB, null);

		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				ParentInfo info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return list;
	}

	ParentInfo getParentByID(String parentid) {
		ParentInfo info = null;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery(
				"SELECT * FROM " + SqliteHelper.PARENT_TAB + " WHERE " + ParentInfo.PARENT_ID + " = '" + parentid + "'",
				null);

		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return info;
	}

	List<ParentInfo> getAllParentsWithNick() {
		List<ParentInfo> allParents = getAllParents();
		for (ParentInfo parentInfo : allParents) {
			fillInfoWithNick(parentInfo);
		}

		return allParents;
	}

	ParentInfo getParentByInternalIDWithNick(int internalid) {
		ParentInfo info = getParentByInternalID(internalid);
		return fillInfoWithNick(info);
	}

	private ParentInfo fillInfoWithNick(ParentInfo info) {
		if (info != null) {
			List<RelationshipMap> relationshipInfos = datamgr.getRelationshipInfoByParentid(info.getParent_id());

			if (relationshipInfos.size() == 1) {
				RelationshipMap relationshipInfo = relationshipInfos.get(0);
				ChildInfo groupChildInfo = datamgr.getChildByID(relationshipInfo.getChild_id());
				info.setNick_name(groupChildInfo.getDisplayName() + relationshipInfo.getRelationship());
			} else {
				setParentNickWhenMuitipleChild(info, relationshipInfos);
			}
		}
		return info;
	}

	private void setParentNickWhenMuitipleChild(ParentInfo info, List<RelationshipMap> relationshipInfos) {
		String relation = IMPOSSIBLE_RELATION;
		boolean useOriginalRelation = true;
		StringBuffer parentNick = new StringBuffer();

		for (RelationshipMap relationshipInfo : relationshipInfos) {
			if (IMPOSSIBLE_RELATION.equals(relation)) {
				// 第一次赋初值
				relation = relationshipInfo.getRelationship();
			} else {
				if (!relation.equals(relationshipInfo.getRelationship())) {
					// 只要有一个亲属关系不同，那么就使用"亲属"作为泛指的关系
					useOriginalRelation = false;
				}
			}

			ChildInfo groupChildInfo = datamgr.getChildByID(relationshipInfo.getChild_id());
			if (groupChildInfo != null) {
				parentNick.append(groupChildInfo.getDisplayName() + ",");
			}
		}

		if (useOriginalRelation) {
			parentNick.deleteCharAt(parentNick.length() - 1).append("的").append(relation);
		} else {
			parentNick.deleteCharAt(parentNick.length() - 1).append("的亲属");
		}

		info.setNick_name(parentNick.toString());
	}

	ParentInfo getParentByInternalID(int internalid) {
		ParentInfo info = null;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery(
				"SELECT * FROM " + SqliteHelper.PARENT_TAB + " WHERE " + ParentInfo.INTERNAL_ID + " = " + internalid,
				null);

		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return info;
	}

	ContentValues buildInfo(ParentInfo info) {
		ContentValues values = new ContentValues();
		values.put(ParentInfo.CARD_NUMBER, info.getCard());
		values.put(ParentInfo.MEMBER_STATUS, info.getMember_status());
		values.put(ParentInfo.PARENT_ID, info.getParent_id());
		values.put(ParentInfo.PARENT_NAME, info.getName());
		values.put(ParentInfo.PHONE, info.getPhone());
		values.put(ParentInfo.PORTRAIT, info.getPortrait());
		values.put(ParentInfo.TIMESTAMP, info.getTimestamp());
		values.put(ParentInfo.RELATIONSHIP, info.getRelationship());
		values.put(ParentInfo.INTERNAL_ID, info.getInternal_id());
		return values;
	}

	ParentInfo getDataByCursor(Cursor cursor) {
		ParentInfo info = new ParentInfo();

		info.setId(cursor.getInt(0));
		info.setCard(cursor.getString(1));
		info.setMember_status(cursor.getInt(2));
		info.setParent_id(cursor.getString(3));
		info.setName(cursor.getString(4));
		info.setPhone(cursor.getString(5));
		info.setPortrait(cursor.getString(6));
		info.setTimestamp(cursor.getLong(7));
		info.setRelationship(cursor.getString(8));
		info.setInternal_id(cursor.getInt(9));
		return info;
	}
}
