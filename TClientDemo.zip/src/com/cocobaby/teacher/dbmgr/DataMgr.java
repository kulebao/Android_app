package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.dbmgr.info.Homework;
import com.cocobaby.teacher.dbmgr.info.IMGroupInfo;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.dbmgr.info.RelationshipMap;
import com.cocobaby.teacher.dbmgr.info.SchoolInfo;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.pojo.ForbidInfo;
import com.cocobaby.teacher.pojo.GroupExpInfo;
import com.cocobaby.teacher.pojo.IMExpandInfo;
import com.cocobaby.teacher.utils.Utils;

public class DataMgr{
    public static int                                DB_VERSION = 10;
    private static final String                      DB_NAME    = "coolbao_teacher" + ".db";
    private static Object                            mLock      = new Object();
    private static DataMgr                           instance;

    private Context                                  context;
    private SqliteHelper                             dbHelper;
    private TeacherMgr                               teacherMgr;
    private ClassMgr                                 classMgr;
    private ChatMgr                                  chatMgr;
    private ChildMgr                                 childMgr;
    private ParentMgr                                parentMgr;
    private RelationshipMgr                          relationshipMgr;
    private EstimateMgr                              estimateMgr;
    private ExpMgr                                   expMgr;
    private NewsMgr                                  newsMgr;
    private HomeworkMgr                              homeworkMgr;
    private NativeMediumMgr                          nativeMediumMgr;
    private com.cocobaby.teacher.dbmgr.IMGroupMgr    iMGroupMgr;
    private com.cocobaby.teacher.dbmgr.SchoolInfoMgr schoolInfoMgr;

    public static synchronized DataMgr getInstance(){
        synchronized(mLock){
            if(instance == null){
                Log.d("test db 111", "get new instance!");
                instance = new DataMgr();
            }
        }
        return instance;
    }

    private DataMgr(){
        context = MyApplication.getInstance().getApplicationContext();
        dbHelper = new SqliteHelper(context, DB_NAME, null, DB_VERSION);

        teacherMgr = new TeacherMgr(dbHelper);
        classMgr = new ClassMgr(dbHelper);
        chatMgr = new ChatMgr(dbHelper);
        childMgr = new ChildMgr(dbHelper);
        relationshipMgr = new RelationshipMgr(dbHelper);
        estimateMgr = new EstimateMgr(dbHelper);
        expMgr = new ExpMgr(dbHelper);
        newsMgr = new NewsMgr(dbHelper);
        homeworkMgr = new HomeworkMgr(dbHelper);
        nativeMediumMgr = new NativeMediumMgr(dbHelper);
        iMGroupMgr = new IMGroupMgr(dbHelper);
        schoolInfoMgr = new SchoolInfoMgr(dbHelper);
        parentMgr = new ParentMgr(dbHelper, this);
    }

    public void updateSchoolInfo(String schoolid, SchoolInfo info){
        schoolInfoMgr.updateSchoolInfo(schoolid, info);
    }

    public long addSchoolInfo(SchoolInfo info){
        return schoolInfoMgr.addSchoolInfo(info);
    }

    public SchoolInfo getSchoolInfo(){
        return schoolInfoMgr.getSchoolInfo();
    }

    public void updateSchoolLogoLocalUrl(String schoolid, String localurl){
        schoolInfoMgr.updateSchoolLogoLocalUrl(schoolid, localurl);
    }

    public long addHomework(Homework info){
        return homeworkMgr.addHomework(info);
    }

    public void addHomeworkList(List<Homework> list){
        homeworkMgr.addHomeworkList(list);
    }

    public Homework getHomeworkByID(int id){
        return homeworkMgr.getHomeworkByID(id);
    }

    public List<Homework> getHomeworkWithLimite(int max){
        return homeworkMgr.getHomeworkWithLimite(max);
    }

    public void removeAllHomework(){
        homeworkMgr.removeAllHomework();
    }

    public long addNews(News info){
        return newsMgr.addNews(info);
    }

    public void deleteNews(int newsid){
        newsMgr.deleteNews(newsid);
    }

    public void addNewsList(List<News> list){
        newsMgr.addNewsList(list);
    }

    public List<News> getNews(int max, long timestamp){
        return newsMgr.getNews(max, timestamp);
    }

    public News getNewsByID(int id){
        return newsMgr.getNewsByID(id);
    }

    public List<News> getAllNewsByType(int type){
        return newsMgr.getAllNewsByType(type);
    }

    public List<News> getNewsByType(int type, int max){
        return newsMgr.getNewsByType(type, max);
    }

    public void removeAllNewsByType(int type){
        newsMgr.removeAllNewsByType(type);
    }

    public void addExpDataList(List<ExpInfo> list){
        expMgr.addDataList(list);
    }

    public List<GroupExpInfo> getExpCountGroupByMonthPerYear(int year){
        return expMgr.getExpCountGroupByMonthPerYear(year);
    }

    public List<ExpInfo> getExpInfoByMonthAndYear(String monthAndYear){
        return expMgr.getExpInfoByMonthAndYear(monthAndYear);
    }

    public void addEstimateRecordList(List<EstimateInfo> list){
        estimateMgr.addEstimateRecordList(list);
    }

    public EstimateInfo getLastEstimate(String childid){
        return estimateMgr.getLastEstimate(childid);
    }

    public long addEstimate(EstimateInfo info){
        return estimateMgr.addEstimate(info);
    }

    public long addTeacher(TeacherInfo info){
        return teacherMgr.addData(info);
    }

    public boolean handleIncomingTeacher(TeacherInfo fromnet){
        return teacherMgr.handleIncomingTeacher(fromnet);
    }

    public TeacherInfo getTeacherInfo(){
        return teacherMgr.getInfo(Utils.getSelfID());
    }

    public TeacherInfo getTeacherInfoByID(String id){
        return teacherMgr.getInfo(id);
    }

    public List<TeacherInfo> getAllTeachers(){
        return teacherMgr.getAllTeachers();
    }

    public TeacherInfo getTeacherByInternalID(int internalid){
        return teacherMgr.getInfoByInternalID(internalid);
    }

    public void clearAll(){
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        dbHelper.clearAll(db);
    }

    public void addClassList(List<ClassInfo> list){
        classMgr.addDataList(list);
    }

    public List<ClassInfo> getAllClasses(){
        return classMgr.getAllClasses();
    }

    public ClassInfo getClassByID(int classid){
        return classMgr.getClassByid(classid);
    }

    public void clearClass(){
        classMgr.clear();
    }

    public void addChildList(List<ChildInfo> list){
        childMgr.addDataList(list);
    }

    public List<ChildInfo> getChildByClass(int classid){
        return childMgr.getChildByClass(classid);
    }

    public ChildInfo getChildByID(String child_id){
        return childMgr.getChildByID(child_id);
    }

    public List<ChildInfo> getAllChild(){
        return childMgr.getAllChild();
    }

    public void clearChild(){
        childMgr.clear();
    }

    public List<RelationshipMap> getRelationshipInfoByParentid(String parentid){
        return relationshipMgr.getRelationshipInfoByParentid(parentid);
    }

    public RelationshipMap getRelationship(String childid){
        List<RelationshipMap> relationships = relationshipMgr.getRelationship(childid);
        return relationships.isEmpty() ? null : relationships.get(0);
    }

    public List<ChatInfo> getChatInfoWithLimite(int max, String childid){
        return chatMgr.getChatInfoWithLimite(max, childid);
    }

    public List<ChatInfo> getChatInfoWithLimite(int max, long to, String childid){
        return chatMgr.getChatInfoWithLimite(max, to, childid);
    }

    public void removeAllChatInfo(){
        chatMgr.clear();
    }

    public void addChatInfoList(List<ChatInfo> list){
        chatMgr.addDataList(list);
    }

    public ChatInfo getLastChatInfo(String childid){
        return chatMgr.getLastChatInfo(childid);
    }

    public Map<String, ChatInfo> getAllChildLastChatMap(){
        return chatMgr.getAllChildLastChatMap();
    }

    public void deleteChat(long chatid){
        chatMgr.deleteChat(chatid);
    }

    public long getLastChatServerid(String childid){
        ChatInfo lastChatInfo = getLastChatInfo(childid);
        if(lastChatInfo != null){
            return lastChatInfo.getChat_id();
        }
        return -1;
    }

    public void addNativeMediumInfo(NativeMediumInfo info){
        nativeMediumMgr.addInfo(info);
    }

    public void addNativeMediumInfoList(List<NativeMediumInfo> list){
        nativeMediumMgr.addList(list);
    }

    public NativeMediumInfo getNativeMediumInfo(String key){
        return nativeMediumMgr.getInfo(key);
    }

    public List<NativeMediumInfo> getAllNativeMediumInfo(){
        return nativeMediumMgr.getAllInfo();
    }

    public void clearNativeMedium(){
        nativeMediumMgr.clear();
    }

    public List<String> getParentIDsByChildId(String childid){
        return relationshipMgr.getParentIDsByChildId(childid);
    }

    public void removeRelationShip(String childid){
        relationshipMgr.removeRelationShip(childid);
    }

    public List<ParentInfo> getAllParents(){
        return parentMgr.getAllParents();
    }

    public List<ParentInfo> getAllParentsWithNick(){
        return parentMgr.getAllParentsWithNick();
    }

    public ParentInfo getParentByID(String parentid){
        return parentMgr.getParentByID(parentid);
    }

    public ParentInfo getParentByInternalID(int internalid){
        return parentMgr.getParentByInternalID(internalid);
    }

    public ParentInfo getParentByInternalIDWithNick(int internalid){
        return parentMgr.getParentByInternalIDWithNick(internalid);
    }

    public long addIMGroupInfo(IMGroupInfo info){
        return iMGroupMgr.addInfo(info);
    }

    public IMGroupInfo getIMGroupInfo(int classid){
        return iMGroupMgr.getInfo(classid);
    }

    public IMGroupInfo getIMGroupInfoByGroupID(String groupid){
        return iMGroupMgr.getInfoByGroupID(groupid);
    }

    public void addRelationship(String childid, ParentInfo info, String relationship){
        SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
        writableDatabase.beginTransaction(); // 手动设置开始事务

        try{
            ContentValues values = parentMgr.buildInfo(info);
            writableDatabase.insertWithOnConflict(SqliteHelper.PARENT_TAB, null, values,
                                                  SQLiteDatabase.CONFLICT_REPLACE);

            values = new ContentValues();
            values.put(RelationshipMap.CHILD_ID, childid);
            values.put(RelationshipMap.PARENT_ID, info.getParent_id());
            values.put(RelationshipMap.RELATIONSHIP, relationship);

            writableDatabase.insertWithOnConflict(SqliteHelper.RELATIONSHIP_TAB, null, values,
                                                  SQLiteDatabase.CONFLICT_REPLACE);

            writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
        }
        finally{
            writableDatabase.endTransaction(); // 处理完成
        }
    }

    public void addGroupInfo(String content) throws Exception{
        JSONArray array = new JSONArray(content);
        List<ChildInfo> groupChildInfos = new ArrayList<>();
        List<ParentInfo> groupParentInfos = new ArrayList<>();
        List<RelationshipMap> relationshipInfos = new ArrayList<>();

        for(int i = 0; i < array.length(); i++){
            JSONObject jsonObject = array.getJSONObject(i);
            ParentInfo parentInfo = ParentInfo.parse(jsonObject);

            JSONObject childJson = jsonObject.getJSONObject("child");
            ChildInfo childInfo = ChildInfo.parseChildInfo(childJson);

            String relationship = jsonObject.getString("relationship");
            RelationshipMap relationshipInfo = new RelationshipMap();
            relationshipInfo.setChild_id(childInfo.getServerID());
            relationshipInfo.setParent_id(parentInfo.getParent_id());
            relationshipInfo.setRelationship(relationship);

            groupChildInfos.add(childInfo);
            groupParentInfos.add(parentInfo);
            relationshipInfos.add(relationshipInfo);
        }

        addImpl(groupChildInfos, groupParentInfos, relationshipInfos);
    }

    private void addImpl(List<ChildInfo> groupChildInfos, List<ParentInfo> groupParentInfos,
            List<RelationshipMap> relationshipInfos){
        SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
        writableDatabase.beginTransaction(); // 手动设置开始事务
        try{

            for(ChildInfo groupChildInfo : groupChildInfos){
                ContentValues values = childMgr.buildInfo(groupChildInfo);
                writableDatabase.insertWithOnConflict(SqliteHelper.CHILD_TAB, null, values,
                                                      SQLiteDatabase.CONFLICT_REPLACE);
            }

            for(ParentInfo groupParentInfo : groupParentInfos){
                ContentValues values = parentMgr.buildInfo(groupParentInfo);
                writableDatabase.insertWithOnConflict(SqliteHelper.PARENT_TAB, null, values,
                                                      SQLiteDatabase.CONFLICT_REPLACE);
            }

            for(RelationshipMap relationshipInfo : relationshipInfos){
                ContentValues values = relationshipMgr.buildInfo(relationshipInfo);
                writableDatabase.insertWithOnConflict(SqliteHelper.RELATIONSHIP_TAB, null, values,
                                                      SQLiteDatabase.CONFLICT_REPLACE);
            }

            // 数据插入操作循环
            writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
        }
        finally{
            writableDatabase.endTransaction(); // 处理完成
        }
    }

    public List<IMExpandInfo> getClassMemberInfo(String classid){
        List<IMExpandInfo> infos = new ArrayList<>();
        List<ChildInfo> GroupChildInfos = childMgr.getChildByClass(Integer.parseInt(classid));

        for(ChildInfo groupChildInfo : GroupChildInfos){
            IMExpandInfo imExpandInfo = new IMExpandInfo();
            imExpandInfo.setChildInfo(groupChildInfo);

            List<RelationshipMap> relationshipInfos = relationshipMgr.getRelationship(groupChildInfo.getServerID());
            List<ParentInfo> parentInfos = new ArrayList<>();

            for(RelationshipMap relationshipInfo : relationshipInfos){
                ParentInfo groupParentInfo = parentMgr.getParentByID(relationshipInfo.getParent_id());
                if(groupParentInfo != null && !parentInfos.contains(groupParentInfo)){
                    groupParentInfo.setNick_name(getNick(groupChildInfo, relationshipInfo.getRelationship()));
                    groupParentInfo.setRelationship(relationshipInfo.getRelationship());
                    parentInfos.add(groupParentInfo);
                }
            }

            imExpandInfo.setGroupParentInfoList(parentInfos);
            infos.add(imExpandInfo);
        }

        return infos;
    }

    private String getNick(ChildInfo groupChildInfo, String relationship){
        if(!TextUtils.isEmpty(groupChildInfo.getNick())){
            return groupChildInfo.getNick() + relationship;
        }
        return groupChildInfo.getName() + relationship;
    }

    public List<ForbidInfo> getForbidInfo(String classid){
        List<ForbidInfo> infos = new ArrayList<>();
        List<ChildInfo> GroupChildInfos = childMgr.getChildByClass(Integer.parseInt(classid));

        for(ChildInfo groupChildInfo : GroupChildInfos){
            List<RelationshipMap> relationshipInfos = relationshipMgr.getRelationship(groupChildInfo.getServerID());

            for(RelationshipMap relationshipInfo : relationshipInfos){
                ForbidInfo forbidInfo = new ForbidInfo();
                ParentInfo groupParentInfo = parentMgr.getParentByID(relationshipInfo.getParent_id());
                if(groupParentInfo != null && !infos.contains(forbidInfo)){
                    forbidInfo.setName(getNick(groupChildInfo, relationshipInfo.getRelationship()));
                    forbidInfo.setId(groupParentInfo.getIMUserid());
                    infos.add(forbidInfo);
                }
            }

        }

        return infos;
    }

    public void close(){
        synchronized(mLock){
            if(dbHelper != null){
                dbHelper.close();
                dbHelper = null;
            }

            instance = null;
        }
    }

}
