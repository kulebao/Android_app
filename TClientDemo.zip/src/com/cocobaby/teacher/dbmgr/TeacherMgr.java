package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cocobaby.teacher.dbmgr.info.TeacherInfo;

class TeacherMgr {
	private SqliteHelper dbHelper;

	TeacherMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	long addData(TeacherInfo info) {
		ContentValues values = buildInfo(info);
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		return writableDatabase.insertWithOnConflict(SqliteHelper.TEACHER_TAB, null, values,
				SQLiteDatabase.CONFLICT_REPLACE);
	}

	List<TeacherInfo> getAllTeachers() {
		List<TeacherInfo> list = new ArrayList<TeacherInfo>();
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.TEACHER_TAB, null);
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				TeacherInfo info = getDataByCursor(cursor);
				cursor.moveToNext();
				list.add(info);
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return list;
	}

	// 处理从服务器端获取到的教师信息，如果客户端没有，则保存，如果有，并且服务器端信息更新，则更新
	boolean handleIncomingTeacher(TeacherInfo fromnet) {
		boolean bret = false;
		TeacherInfo localone = getInfo(fromnet.getPhone());
		if (localone == null) {
			addData(fromnet);
			bret = true;
		} else if (localone.getUid() == 0) {
			addData(fromnet);
			bret = true;
		} else if (fromnet.getTimestamp() > localone.getTimestamp()) {
			addData(fromnet);
			bret = true;
		}

		return bret;
	}

	TeacherInfo getInfo(String teacherid) {
		TeacherInfo info = null;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.TEACHER_TAB + " WHERE " + TeacherInfo.SERVER_ID
				+ " ='" + teacherid + "'", null);
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				cursor.moveToNext();
				break;
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return info;
	}

	TeacherInfo getInfoByInternalID(int internalid) {
		TeacherInfo info = null;
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery(
				"SELECT * FROM " + SqliteHelper.TEACHER_TAB + " WHERE " + TeacherInfo.UID + " =" + internalid, null);
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				info = getDataByCursor(cursor);
				cursor.moveToNext();
				break;
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return info;
	}

	private ContentValues buildInfo(TeacherInfo info) {
		ContentValues values = new ContentValues();
		values.put(TeacherInfo.TIMESTAMP, info.getTimestamp());
		values.put(TeacherInfo.LOGIN_NAME, info.getLogin_name());
		values.put(TeacherInfo.NAME, info.getName());
		values.put(TeacherInfo.PHONE, info.getPhone());
		values.put(TeacherInfo.PORTRAIT, info.getPortrait());
		values.put(TeacherInfo.SERVER_ID, info.getServer_id());
		values.put(TeacherInfo.PWD, info.getPwd());
		values.put(TeacherInfo.WORKDUTY, info.getWorkduty());
		values.put(TeacherInfo.WORKGROUP, info.getWorkgroup());
		values.put(TeacherInfo.BIRTHDAY, info.getBirthday());
		values.put(TeacherInfo.GENDER, info.getGender());
		values.put(TeacherInfo.UID, info.getUid());
		return values;
	}

	private TeacherInfo getDataByCursor(Cursor cursor) {
		TeacherInfo info = new TeacherInfo();

		info.setId(cursor.getInt(0));
		info.setName(cursor.getString(1));
		info.setPhone(cursor.getString(2));
		info.setTimestamp(cursor.getLong(3));
		info.setLogin_name(cursor.getString(4));
		info.setPortrait(cursor.getString(5));
		info.setServer_id(cursor.getString(6));
		info.setPwd(cursor.getString(7));
		info.setWorkduty(cursor.getString(8));
		info.setWorkgroup(cursor.getString(9));
		info.setBirthday(cursor.getString(10));
		info.setGender(cursor.getInt(11));
		info.setUid(cursor.getLong(12));
		return info;
	}
}
