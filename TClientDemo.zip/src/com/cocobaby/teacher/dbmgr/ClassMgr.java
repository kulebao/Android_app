package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cocobaby.teacher.dbmgr.info.ClassInfo;

class ClassMgr {
	private SqliteHelper dbHelper;

	ClassMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	void addDataList(List<ClassInfo> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		writableDatabase.beginTransaction(); // 手动设置开始事务

		try {
			for (ClassInfo info : list) {
				ContentValues values = buildInfo(info);
				writableDatabase.insertWithOnConflict(SqliteHelper.CLASS_TAB, null, values,
						SQLiteDatabase.CONFLICT_REPLACE);
			}
			// 数据插入操作循环
			writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
		} finally {
			writableDatabase.endTransaction(); // 处理完成
		}
	}

	long addData(ClassInfo info) {
		ContentValues values = buildInfo(info);
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		return writableDatabase.insertWithOnConflict(SqliteHelper.CLASS_TAB, null, values,
				SQLiteDatabase.CONFLICT_REPLACE);
	}

	List<ClassInfo> getAllClasses() {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db
				.rawQuery("SELECT * FROM " + SqliteHelper.CLASS_TAB + " ORDER BY " + ClassInfo.CLASS_ID, null);

		return getList(cursor);
	}

	ClassInfo getClassByid(int classid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.CLASS_TAB + " WHERE  " + ClassInfo.CLASS_ID + " = "
				+ classid, null);
		List<ClassInfo> list = getList(cursor);
		return list.isEmpty() ? new ClassInfo() : list.get(0);
	}

	void clear() {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM  " + SqliteHelper.CLASS_TAB);
	}

	private List<ClassInfo> getList(Cursor cursor) {
		List<ClassInfo> list = new ArrayList<ClassInfo>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				ClassInfo info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	private ContentValues buildInfo(ClassInfo info) {
		ContentValues values = new ContentValues();
		values.put(ClassInfo.CLASS_NAME, info.getClassName());
		values.put(ClassInfo.CLASS_ID, info.getClassID());
		return values;
	}

	private ClassInfo getDataByCursor(Cursor cursor) {
		ClassInfo info = new ClassInfo();

		info.setId(cursor.getInt(0));
		info.setClassName(cursor.getString(1));
		info.setClassID(cursor.getInt(2));
		return info;
	}
}
