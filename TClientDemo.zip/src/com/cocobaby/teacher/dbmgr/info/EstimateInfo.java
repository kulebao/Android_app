package com.cocobaby.teacher.dbmgr.info;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.utils.Utils;

public class EstimateInfo {
	private static final String SCHOOL_ID = "school_id";
	private static final int DEFAULT_RANK = 3;
	public static final String ID = "_id";
	public static final String SERVER_ID = "server_id";
	public static final String TIMESTAMP = "timestamp";
	public static final String PUBLISHER = "publisher";
	public static final String COMMENTS = "comments";
	public static final String EMOTION = "emotion";
	public static final String DINING = "dining";
	public static final String REST = "rest";
	public static final String ACTIVITY = "activity";
	public static final String EXERCISE = "exercise";
	public static final String SELF_CARE = "self_care";
	public static final String MANNER = "manner";
	public static final String GAME = "game";
	public static final String CHILD_ID = "child_id";

	private int id = 0;
	private int server_id = 0;

	private String publisher = "";
	private String comments = "";
	private int emotion = DEFAULT_RANK;
	private int dining = DEFAULT_RANK;
	private int rest = DEFAULT_RANK;
	private int activity = DEFAULT_RANK;
	private int exercise = DEFAULT_RANK;
	private int self_care = DEFAULT_RANK;
	private int manner = DEFAULT_RANK;
	private int game = DEFAULT_RANK;
	private String child_id = "";
	private long timestamp = 0;

	public EstimateInfo() {
	}

	public EstimateInfo(String comments, int emotion, int dining, int rest,
			int activity, int exercise, int self_care, int manner, int game) {
		this.comments = comments;
		this.emotion = emotion;
		this.dining = dining;
		this.rest = rest;
		this.activity = activity;
		this.exercise = exercise;
		this.self_care = self_care;
		this.manner = manner;
		this.game = game;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getServer_id() {
		return server_id;
	}

	public void setServer_id(int server_id) {
		this.server_id = server_id;
	}

	public String getPublisher() {
		return publisher;
	}

	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public int getEmotion() {
		return emotion;
	}

	public void setEmotion(int emotion) {
		this.emotion = emotion;
	}

	public int getDining() {
		return dining;
	}

	public void setDining(int dining) {
		this.dining = dining;
	}

	public int getRest() {
		return rest;
	}

	public void setRest(int rest) {
		this.rest = rest;
	}

	public int getActivity() {
		return activity;
	}

	public void setActivity(int activity) {
		this.activity = activity;
	}

	public int getExercise() {
		return exercise;
	}

	public void setExercise(int exercise) {
		this.exercise = exercise;
	}

	public int getSelf_care() {
		return self_care;
	}

	public void setSelf_care(int self_care) {
		this.self_care = self_care;
	}

	public int getManner() {
		return manner;
	}

	public void setManner(int manner) {
		this.manner = manner;
	}

	public int getGame() {
		return game;
	}

	public void setGame(int game) {
		this.game = game;
	}

	public String getChild_id() {
		return child_id;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public static List<EstimateInfo> jsonArrayToList(JSONArray array) {
		List<EstimateInfo> list = new ArrayList<EstimateInfo>();

		try {
			for (int i = 0; i < array.length(); i++) {
				JSONObject jsonObject = array.getJSONObject(i);
				EstimateInfo info = parse(jsonObject);
				list.add(info);
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}

		return list;
	}

	public static EstimateInfo parse(JSONObject jsonObject)
			throws JSONException {
		EstimateInfo info = new EstimateInfo();
		// 注意服务器端给出的key是id
		info.setServer_id(jsonObject.getInt("id"));
		info.setTimestamp(jsonObject.getLong(TIMESTAMP));
		info.setPublisher(jsonObject.getString(PUBLISHER));
		info.setComments(jsonObject.getString(COMMENTS));
		info.setEmotion(jsonObject.getInt(EMOTION));
		info.setDining(jsonObject.getInt(DINING));
		info.setRest(jsonObject.getInt(REST));
		info.setActivity(jsonObject.getInt(ACTIVITY));
		info.setExercise(jsonObject.getInt(EXERCISE));
		info.setSelf_care(jsonObject.getInt(SELF_CARE));
		info.setManner(jsonObject.getInt(MANNER));
		info.setGame(jsonObject.getInt(GAME));
		info.setChild_id(jsonObject.getString(CHILD_ID));
		return info;
	}

	public JSONObject toJsonObj() throws JSONException {
		JSONObject object = new JSONObject();
		String teachername = DataMgr.getInstance().getTeacherInfo().getName();

		object.put(SCHOOL_ID, Utils.getSchoolID());
		object.put(PUBLISHER, teachername);
		object.put("child_id", child_id);
		object.put(EMOTION, emotion);
		object.put(COMMENTS, comments);
		object.put(DINING, dining);
		object.put(REST, rest);
		object.put(ACTIVITY, activity);
		object.put(EXERCISE, exercise);
		object.put(SELF_CARE, self_care);
		object.put(MANNER, manner);
		object.put(GAME, game);

		return object;
	}

	public JSONArray toJsonArray(List<String> childIDs) throws JSONException {
		JSONArray array = new JSONArray();
		int scholl_id = Integer.parseInt(Utils.getProp(JSONConstant.SCHOOL_ID));
		String teachername = DataMgr.getInstance().getTeacherInfo().getName();

		for (String id : childIDs) {
			JSONObject object = new JSONObject();
			object.put(SCHOOL_ID, scholl_id);
			object.put(PUBLISHER, teachername);
			object.put("child_id", id);
			object.put(EMOTION, emotion);
			object.put(COMMENTS, comments);
			object.put(DINING, dining);
			object.put(REST, rest);
			object.put(ACTIVITY, activity);
			object.put(EXERCISE, exercise);
			object.put(SELF_CARE, self_care);
			object.put(MANNER, manner);
			object.put(GAME, game);
			array.put(object);
		}

		return array;
	}

	public String getFormattedTime() {
		String ret = "";
		try {
			ret = Utils.convertTime(timestamp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	@Override
	public String toString() {
		StringBuffer buffer = new StringBuffer();
		buffer.append(getFormattedTime() + "\n");
		buffer.append(publisher + ":" + comments + "\n");
		buffer.append(Utils.getResString(R.string.self_care) + ":" + self_care
				+ ",");
		buffer.append(Utils.getResString(R.string.activity) + ":" + activity
				+ ",");
		buffer.append(Utils.getResString(R.string.manner) + ":" + manner + ",");
		buffer.append(Utils.getResString(R.string.exercise) + ":" + exercise
				+ ",");
		buffer.append(Utils.getResString(R.string.game) + ":" + game + ",");
		buffer.append(Utils.getResString(R.string.emotion) + ":" + emotion
				+ ",");
		buffer.append(Utils.getResString(R.string.dining) + ":" + dining + ",");
		buffer.append(Utils.getResString(R.string.rest) + ":" + rest);
		return buffer.toString();
	}

}
