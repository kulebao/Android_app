package com.cocobaby.teacher.dbmgr.info;

public class ClassInfo {
	public static final String ID = "_id";
	public static String CLASS_ID = "class_id";
	public static String CLASS_NAME = "name";

	private int classID = -1;
	private String className = "";
	private int id = 0;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getClassID() {
		return classID;
	}

	public void setClassID(int classID) {
		this.classID = classID;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

}
