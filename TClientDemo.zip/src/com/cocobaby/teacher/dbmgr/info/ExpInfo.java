package com.cocobaby.teacher.dbmgr.info;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.utils.Utils;

public class ExpInfo {
	public static final String TEACHER_TYPE = "t";
	public static final String PARENT_TYPE = "p";

	public static final String ID = "_id";
	public static final String CONTENT = "content";
	public static final String TIMESTAMP = "timestamp";
	public static final String EXP_ID = "exp_id";
	public static final String CHILD_ID = "child_id";
	public static final String MEDIA_URL = "media_url";
	public static final String MEDIA_TYPE = "media_type";
	public static final String SENDER_TYPE = "sender_type";
	public static final String SENDER_ID = "sender_id";
	public static final String MEDIUM = "medium";

	private String content = "";
	private long timestamp = 0;
	private String sender_id = "";
	private String medium = "";
	private String sender_type = "";
	private String child_id = "";
	private int id = 0;
	private long exp_id = 0;

	public long getExp_id() {
		return exp_id;
	}

	public void setExp_id(long exp_id) {
		this.exp_id = exp_id;
	}

	public String getChild_id() {
		return child_id;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public String getSender_type() {
		return sender_type;
	}

	public void setSender_type(String sender_type) {
		this.sender_type = sender_type;
	}

	public String getSender_id() {
		return sender_id;
	}

	public void setSender_id(String sender_id) {
		this.sender_id = sender_id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getMedium() {
		return medium;
	}

	public void setMedium(String medium) {
		this.medium = medium;
	}

	public String getFormattedTime() {
		String ret = "";
		try {
			ret = Utils.convertTime(timestamp);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ret;
	}

	public int getLayoutID() {
		int layoutid = 0;
		if (!TEACHER_TYPE.equals(sender_type)) {
			layoutid = R.layout.chat_item_right;
		} else {
			layoutid = R.layout.chat_item_left;
		}

		return layoutid;
	}

	public boolean isSendBySelf() {
		return TEACHER_TYPE.equals(sender_type);
	}

	public static ExpInfo parseFromJson(JSONObject object) throws JSONException {
		ExpInfo info = new ExpInfo();

		info.setExp_id(object.getLong("id"));
		info.setChild_id(object.getString(JSONConstant.TOPIC));
		info.setContent(object.getString(CONTENT));
		info.setSender_id(object.getJSONObject(JSONConstant.SENDER).getString(JSONConstant.ID));
		info.setSender_type(object.getJSONObject(JSONConstant.SENDER).getString(JSONConstant.TYPE));
		info.setTimestamp(object.getLong(TIMESTAMP));
		info.setMedium(object.getJSONArray(MEDIUM).toString());
		return info;
	}

	public String getMediumType() {
		String type = JSONConstant.TEXT_TYPE;
		if (!TextUtils.isEmpty(medium)) {
			try {
				JSONArray array = new JSONArray(medium);
				if (array.length() > 0) {
					// 返回的类型会多出\\，临时解决一下
					type = array.getJSONObject(0).getString(JSONConstant.TYPE).replace("\\", "");
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return type;
	}

	public List<String> getServerUrls() {
		List<String> list = new ArrayList<String>();
		if (!TextUtils.isEmpty(medium)) {
			try {
				JSONArray array = new JSONArray(medium);
				for (int i = 0; i < array.length(); i++) {
					String url = array.getJSONObject(i).getString(JSONConstant.URL);
					list.add(url);
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	public boolean isSame(ExpInfo other) {
		boolean bret = false;

		// 目前无法判断成长经历是否是同一条，因为在服务器上同时发送给多个小孩的成长经历，被保存为多条，只有通过内容和时间戳简单认定一下了
		if (content.equals(other.content) && medium.equals(other.medium)
				&& Math.abs(timestamp - other.timestamp) < 1000) {
			bret = true;
		}

		return bret;
	}

	// 如果存在medium就用medium来表示，因为对于教师来说，同样内容的成长经历发给了多个学生，在服务器上
	// 对应的是多条记录，用exp_id是无法标识的，不过如果存在medium，这个url应该是唯一的
	public String getUniqueIdentity() {
		if (!TextUtils.isEmpty(medium)) {
			return Utils.MD5(medium);
		} else {
			return exp_id + "";
		}
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (exp_id ^ (exp_id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExpInfo other = (ExpInfo) obj;
		if (exp_id != other.exp_id)
			return false;
		return true;
	}

}
