package com.cocobaby.teacher.dbmgr.info;

import java.util.List;

import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;

public class InfoHelper {

	public static String getAllClassIDs(List<ClassInfo> list) {
		if (list.isEmpty()) {
			return "";
		}

		StringBuffer ids = new StringBuffer();
		for (ClassInfo classInfo : list) {
			ids.append(classInfo.getClassID());
			ids.append(",");
		}

		Log.d("getAllClassIDs", "ids =" + ids.substring(0, ids.length() - 1));
		return ids.substring(0, ids.length() - 1);
	}

	public static boolean classIsEmpty() {
		return DataMgr.getInstance().getAllClasses().isEmpty();
	}

	public static String formatChatContent(String content, String mediaUrl,
			String childid, String mediaType) {
		JSONObject jsonObject = new JSONObject();
		JSONObject mediaJsonObj = new JSONObject();
		JSONObject senderJsonObj = new JSONObject();
		try {
			jsonObject.put(JSONConstant.TOPIC, childid);
			jsonObject.put(ChatInfo.CONTENT, content);

			mediaJsonObj.put("url", mediaUrl);
			mediaJsonObj.put("type", mediaType);
			jsonObject.put(JSONConstant.MEDIA, mediaJsonObj);

			senderJsonObj.put("id", DataMgr.getInstance().getTeacherInfo()
					.getServer_id());
			senderJsonObj.put("type", ChatInfo.TEACHER_TYPE);
			jsonObject.put(JSONConstant.SENDER, senderJsonObj);

		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsonObject.toString();
	}
}
