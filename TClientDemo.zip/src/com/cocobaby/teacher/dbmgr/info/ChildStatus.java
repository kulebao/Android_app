package com.cocobaby.teacher.dbmgr.info;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.json.JSONException;
import org.json.JSONObject;

public class ChildStatus {
	// 刷卡入园
	public static final int SWIPE_IN = 1;
	// 刷卡离园
	public static final int SWIPE_OUT = 0;

	public static String NOTICE_TYPE = "notice_type";
	public static String PARENT_NAME = "parent_name";
	public static String TIMESTAMP = "timestamp";
	public static String RECORD_URL = "record_url";
	public static String CHILD_ID = "child_id";

	private int notice_type = SWIPE_OUT;
	private String parent_name = "";
	private String record_url = "";
	private String child_id = "";
	private long timestamp = -1;

	public int getNotice_type() {
		return notice_type;
	}

	public void setNotice_type(int notice_type) {
		this.notice_type = notice_type;
	}

	public String getParent_name() {
		return parent_name;
	}

	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}

	public String getRecord_url() {
		return record_url;
	}

	public void setRecord_url(String record_url) {
		this.record_url = record_url;
	}

	public String getChild_id() {
		return child_id;
	}

	public void setChild_id(String child_id) {
		this.child_id = child_id;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public String getFormattedTime() {
		SimpleDateFormat fomat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
				Locale.CHINESE);
		return fomat.format(new Date(timestamp));
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public boolean isEmptyStatus() {
		return timestamp == -1;
	}

	public String getContent() {
		String content = "未刷卡";
		if (!isEmptyStatus()) {
			try {
				String swip = notice_type == SWIPE_IN ? "刷卡入园" : "刷卡离园";
				content = "由 " + parent_name + " 于" + getFormattedTime() + swip;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return content;
	}

	public static ChildStatus parse(JSONObject jsonObject) throws JSONException {
		ChildStatus info = new ChildStatus();
		info.setNotice_type(jsonObject.getInt(NOTICE_TYPE));
		info.setParent_name(jsonObject.getString(PARENT_NAME));
		info.setRecord_url(jsonObject.getString(RECORD_URL));
		info.setChild_id(jsonObject.getString(CHILD_ID));
		info.setTimestamp(jsonObject.getLong(TIMESTAMP));
		return info;
	}

}
