package com.cocobaby.teacher.dbmgr.info;

public class NativeMediumInfo {
	public static final String ID = "_id";
	public static final String KEY = "key";
	public static final String LOCAL_URL = "local_url";
	public static final String LOCAL_NAIL_URL = "local_nail_url";

	private long id = 0;
	private String key = "";
	private String local_url = "";
	private String local_nail_url = "";

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getLocal_url() {
		return local_url;
	}

	public void setLocal_url(String local_url) {
		this.local_url = local_url;
	}

	public String getLocal_nail_url() {
		return local_nail_url;
	}

	public void setLocal_nail_url(String local_nail_url) {
		this.local_nail_url = local_nail_url;
	}

	@Override
	public String toString() {
		return "NativeMediumInfo [key=" + key + ", local_url=" + local_url + "]";
	}

}
