package com.cocobaby.teacher.dbmgr.info;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.utils.Utils;

public class ChildInfo {
	public static final String ID = "_id";
	public static String CLASS_ID = "class_id";
	public static String CLASS_NAME = "class_name";
	public static String CHILD_NAME = "name";
	public static String PORTRAIT = "portrait";
	public static String CHILD_ID = "child_id";
	public static String NICK = "nick";
	public static String BIRTHDAY = "birthday";
	public static String TIMESTAMP = "timestamp";

	private String serverID = "";
	private String name = "";
	private String nick = "";
	private String birthday = "";
	private String portrait = "";
	private int class_id = -1;
	private String class_name = "";
	private long timestamp = -1;

	private int id = 0;

	private boolean feedback = false;

	public boolean isFeedback() {
		return feedback;
	}

	public void setFeedback(boolean feedback) {
		this.feedback = feedback;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getServerID() {
		return serverID;
	}

	public void setServerID(String serverID) {
		this.serverID = serverID;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getNick() {
		return nick;
	}

	public void setNick(String nick) {
		this.nick = nick;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getPortrait() {
		return portrait;
	}

	public void setPortrait(String portrait) {
		this.portrait = portrait;
	}

	public int getClass_id() {
		return class_id;
	}

	public void setClass_id(int class_id) {
		this.class_id = class_id;
	}

	public String getClass_name() {
		return class_name;
	}

	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public String getDisplayName() {
		return TextUtils.isEmpty(nick) ? name : nick;
	}

	public String getChildrenLocalIconPath() {
		String dir = Utils.getChildIconDir(serverID);

		Utils.mkDirs(dir);
		String url = dir + serverID;
		Log.d("DDD", "getChildrenDefaultLocalIconPath url=" + url);
		return url;
	}

	public static ChildInfo parseChildInfo(JSONObject jsonObject) throws JSONException {
		ChildInfo info = new ChildInfo();
		info.setClass_id(jsonObject.getInt(CLASS_ID));
		info.setClass_name(jsonObject.getString(CLASS_NAME));
		info.setBirthday(jsonObject.getString(BIRTHDAY));
		info.setName(jsonObject.getString(CHILD_NAME));
		info.setNick(jsonObject.getString(NICK));
		info.setPortrait(jsonObject.getString(PORTRAIT));
		info.setServerID(jsonObject.getString(CHILD_ID));
		info.setTimestamp(jsonObject.getLong(TIMESTAMP));
		return info;
	}

}
