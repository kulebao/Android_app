package com.cocobaby.teacher.dbmgr.info;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.utils.Utils;

import android.util.Log;

public class TeacherInfo{
    public static final String ID         = "_id";
    public static final String NAME       = "name";

    public static final String LOGIN_NAME = "login_name";
    public static final String PHONE      = "phone";
    public static final String TIMESTAMP  = "timestamp";
    public static final String SERVER_ID  = "server_id";

    public static final String PORTRAIT   = "portrait";
    public static final String GENDER     = "gender";
    public static final String WORKDUTY   = "workduty";
    public static final String WORKGROUP  = "workgroup";
    public static final String BIRTHDAY   = "birthday";

    public static final String PWD        = "pwd";
    // 服务器上唯一整形id
    public static final String UID        = "uid";

    private int                id         = 0;
    private String             name       = "";
    private String             login_name = "";
    private String             phone      = "";
    private String             server_id  = "";
    private String             portrait   = "";
    private String             pwd        = "";
    private long               timestamp  = -1;
    private long               uid        = 0;
    private int                gender     = 1;
    private String             workduty   = "";
    private String             workgroup  = "";
    private String             birthday   = "";

    public long getUid(){
        return uid;
    }

    public void setUid(long uid){
        this.uid = uid;
    }

    public int getId(){
        return id;
    }

    public void setId(int id){
        this.id = id;
    }

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getLogin_name(){
        return login_name;
    }

    public void setLogin_name(String login_name){
        this.login_name = login_name;
    }

    public String getPhone(){
        return phone;
    }

    public void setPhone(String phone){
        this.phone = phone;
    }

    public String getServer_id(){
        return server_id;
    }

    public void setServer_id(String server_id){
        this.server_id = server_id;
    }

    public String getPortrait(){
        return portrait;
    }

    public void setPortrait(String portrait){
        this.portrait = portrait;
    }

    public long getTimestamp(){
        return timestamp;
    }

    public void setTimestamp(long timestamp){
        this.timestamp = timestamp;
    }

    public String getPwd(){
        return pwd;
    }

    public void setPwd(String pwd){
        this.pwd = pwd;
    }

    public int getGender(){
        return gender;
    }

    public void setGender(int gender){
        this.gender = gender;
    }

    public String getWorkduty(){
        return workduty;
    }

    public void setWorkduty(String workduty){
        this.workduty = workduty;
    }

    public String getWorkgroup(){
        return workgroup;
    }

    public void setWorkgroup(String workgroup){
        this.workgroup = workgroup;
    }

    public String getBirthday(){
        return birthday;
    }

    public void setBirthday(String birthday){
        this.birthday = birthday;
    }

    public JSONObject toJsonObj() throws JSONException{
        JSONObject object = new JSONObject();
        object.put(NAME, name);
        object.put(LOGIN_NAME, login_name);
        object.put(PHONE, phone);
        object.put(PORTRAIT, portrait);
        object.put("id", server_id);
        object.put(WORKDUTY, workduty);
        object.put(WORKGROUP, workgroup);
        object.put(BIRTHDAY, birthday);
        object.put(GENDER, gender);
        object.put(JSONConstant.SCHOOL_ID, Utils.getSchoolID());
        return object;
    }

    public static TeacherInfo parseInfoFromJson(JSONObject jsonObject) throws JSONException{
        TeacherInfo info = new TeacherInfo();
        info.setName(jsonObject.getString(NAME));
        info.setLogin_name(jsonObject.getString(LOGIN_NAME));
        info.setPhone(jsonObject.getString(PHONE));
        info.setPortrait(jsonObject.getString(PORTRAIT));
        info.setServer_id(jsonObject.getString("id"));
        info.setTimestamp(jsonObject.getLong(TIMESTAMP));
        info.setWorkduty(jsonObject.getString(WORKDUTY));
        info.setWorkgroup(jsonObject.getString(WORKGROUP));
        info.setBirthday(jsonObject.getString(BIRTHDAY));
        info.setGender(jsonObject.getInt(GENDER));
        info.setUid(jsonObject.getLong(UID));
        return info;
    }

    public static List<TeacherInfo> toTeacherList(JSONArray array){
        List<TeacherInfo> list = new ArrayList<TeacherInfo>();

        for(int i = 0; i < array.length(); i++){
            try{
                JSONObject jsonObject = array.getJSONObject(i);
                list.add(parseInfoFromJson(jsonObject));
            } catch(JSONException e){
                e.printStackTrace();
            }
        }

        return list;
    }

    public static String getPhones(List<TeacherInfo> list){
        StringBuffer buffer = new StringBuffer();
        for(TeacherInfo teacher : list){
            buffer.append(teacher.getPhone());
            buffer.append(ConstantValue.COMMON_SEPEARAOR);
        }
        String result = "";
        if(buffer.length() > 0){
            result = buffer.substring(0, buffer.length() - 1);
        }
        return result;
    }

    public String getLocalHeadIconPath(){
        String dir = Utils.getTeacherIconDir();

        Utils.mkDirs(dir);

        String url = dir + server_id;
        Log.d("DDD", "getChildrenDefaultLocalIconPath url=" + url);
        return url;
    }

    // 根据约定，拼接出融云im对应的userid
    public String getIMUserid(){
        String schoolID = Utils.getSchoolID() + "";
        String id = "t_" + schoolID + "_Some(" + uid + ")_" + login_name;
        return id;
    }

    @Override
    public String toString(){
        return "TeacherInfo [id=" + id + ", name=" + name + ", login_name=" + login_name + ", phone=" + phone
                + ", server_id=" + server_id + ", portrait=" + portrait + ", pwd=" + pwd + ", timestamp=" + timestamp
                + ", uid=" + uid + ", gender=" + gender + ", workduty=" + workduty + ", workgroup=" + workgroup
                + ", birthday=" + birthday + "]";
    }

    @Override
    public int hashCode(){
        final int prime = 31;
        int result = 1;
        result = prime * result + ((server_id == null) ? 0 : server_id.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj){
        if(this == obj)
            return true;
        if(obj == null)
            return false;
        if(getClass() != obj.getClass())
            return false;
        TeacherInfo other = (TeacherInfo)obj;
        if(server_id == null){
            if(other.server_id != null)
                return false;
        } else if(!server_id.equals(other.server_id))
            return false;
        return true;
    }

}
