package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.RelationshipMap;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

class RelationshipMgr {
	private SqliteHelper dbHelper;

	RelationshipMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	void addData(String childid, String parentid, String relationship) {
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();

		ContentValues values = new ContentValues();
		values.put(RelationshipMap.CHILD_ID, childid);
		values.put(RelationshipMap.PARENT_ID, parentid);
		values.put(RelationshipMap.RELATIONSHIP, relationship);

		writableDatabase.insertWithOnConflict(SqliteHelper.RELATIONSHIP_TAB, null, values,
				SQLiteDatabase.CONFLICT_REPLACE);
	}

	List<RelationshipMap> getRelationship(String childid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.RELATIONSHIP_TAB + " WHERE "
				+ RelationshipMap.CHILD_ID + " = '" + childid + "'", null);

		return getList(cursor);
	}

	private List<RelationshipMap> getList(Cursor cursor) {
		List<RelationshipMap> list = new ArrayList<RelationshipMap>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				RelationshipMap info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	private RelationshipMap getDataByCursor(Cursor cursor) {
		RelationshipMap info = new RelationshipMap();

		info.setId(cursor.getInt(0));
		info.setChild_id(cursor.getString(1));
		info.setParent_id(cursor.getString(2));
		info.setRelationship(cursor.getString(3));
		return info;
	}

	void removeRelationShip(String childid) {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM " + SqliteHelper.RELATIONSHIP_TAB + " WHERE " + RelationshipMap.CHILD_ID + " = '"
				+ childid + "'");
	}

	List<String> getParentIDsByChildId(String childid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT " + RelationshipMap.PARENT_ID + " FROM " + SqliteHelper.RELATIONSHIP_TAB
				+ " WHERE " + RelationshipMap.CHILD_ID + " = '" + childid + "'", null);

		return getParentIDList(cursor);
	}

	List<RelationshipMap> getRelationshipInfoByParentid(String parentid) {
		List<RelationshipMap> list = new ArrayList<RelationshipMap>();
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.RELATIONSHIP_TAB + " WHERE "
				+ RelationshipMap.PARENT_ID + " ='" + parentid + "'", null);
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				RelationshipMap info = getDataByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		return list;
	}

	private List<String> getParentIDList(Cursor cursor) {
		List<String> list = new ArrayList<String>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(0) != null)) {
				String info = cursor.getString(0);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	ContentValues buildInfo(RelationshipMap info) {
		ContentValues values = new ContentValues();
		values.put(RelationshipMap.CHILD_ID, info.getChild_id());
		values.put(RelationshipMap.PARENT_ID, info.getParent_id());
		values.put(RelationshipMap.RELATIONSHIP, info.getRelationship());
		return values;
	}

}
