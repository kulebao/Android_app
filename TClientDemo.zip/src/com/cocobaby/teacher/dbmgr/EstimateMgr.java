package com.cocobaby.teacher.dbmgr;

import java.util.ArrayList;
import java.util.List;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.cocobaby.teacher.dbmgr.info.EstimateInfo;

class EstimateMgr {
	private SqliteHelper dbHelper;

	EstimateMgr(SqliteHelper dbHelper) {
		this.dbHelper = dbHelper;
	}

	long addEstimate(EstimateInfo info) {
		ContentValues values = buildInfo(info);
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		return writableDatabase.insertWithOnConflict(SqliteHelper.EDUCATION_TAB, null, values,
				SQLiteDatabase.CONFLICT_REPLACE);
	}

	void addEstimateRecordList(List<EstimateInfo> list) {
		if (list == null || list.isEmpty()) {
			return;
		}
		SQLiteDatabase writableDatabase = dbHelper.getWritableDatabase();
		writableDatabase.beginTransaction(); // 手动设置开始事务

		for (EstimateInfo info : list) {
			ContentValues values = buildInfo(info);
			writableDatabase.insertWithOnConflict(SqliteHelper.EDUCATION_TAB, null, values,
					SQLiteDatabase.CONFLICT_REPLACE);
		}
		// 数据插入操作循环
		writableDatabase.setTransactionSuccessful(); // 设置事务处理成功，不设置会自动回滚不提交
		writableDatabase.endTransaction(); // 处理完成
	}

	private ContentValues buildInfo(EstimateInfo info) {
		ContentValues values = new ContentValues();
		values.put(EstimateInfo.SERVER_ID, info.getServer_id());
		values.put(EstimateInfo.TIMESTAMP, info.getTimestamp());
		values.put(EstimateInfo.PUBLISHER, info.getPublisher());
		values.put(EstimateInfo.COMMENTS, info.getComments());
		values.put(EstimateInfo.EMOTION, info.getEmotion());
		values.put(EstimateInfo.DINING, info.getDining());
		values.put(EstimateInfo.REST, info.getRest());
		values.put(EstimateInfo.ACTIVITY, info.getActivity());
		values.put(EstimateInfo.EXERCISE, info.getExercise());
		values.put(EstimateInfo.SELF_CARE, info.getSelf_care());
		values.put(EstimateInfo.MANNER, info.getManner());
		values.put(EstimateInfo.GAME, info.getGame());
		values.put(EstimateInfo.CHILD_ID, info.getChild_id());
		return values;
	}

	EstimateInfo getLastEstimate(String childid) {
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		Cursor cursor = db.rawQuery("SELECT * FROM " + SqliteHelper.EDUCATION_TAB + " WHERE " + EstimateInfo.CHILD_ID
				+ " = '" + childid + "' ORDER BY " + EstimateInfo.TIMESTAMP + " DESC LIMIT 1", null);
		List<EstimateInfo> eduList = getEduList(cursor);

		return eduList.isEmpty() ? null : eduList.get(0);
	}

	void removeEduRecord(String childid) {
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		db.execSQL("DELETE FROM " + SqliteHelper.EDUCATION_TAB + " WHERE " + EstimateInfo.CHILD_ID + " = '" + childid
				+ "'");
	}

	private List<EstimateInfo> getEduList(Cursor cursor) {
		List<EstimateInfo> list = new ArrayList<EstimateInfo>();
		try {
			cursor.moveToFirst();
			while (!cursor.isAfterLast() && (cursor.getString(1) != null)) {
				EstimateInfo info = getEduByCursor(cursor);
				list.add(info);
				cursor.moveToNext();
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}
		return list;
	}

	private EstimateInfo getEduByCursor(Cursor cursor) {
		EstimateInfo info = new EstimateInfo();

		info.setId(cursor.getInt(0));
		info.setServer_id(cursor.getInt(1));
		info.setTimestamp(cursor.getLong(2));
		info.setPublisher(cursor.getString(3));
		info.setComments(cursor.getString(4));
		info.setEmotion(cursor.getInt(5));
		info.setDining(cursor.getInt(6));
		info.setRest(cursor.getInt(7));
		info.setActivity(cursor.getInt(8));
		info.setExercise(cursor.getInt(9));
		info.setSelf_care(cursor.getInt(10));
		info.setManner(cursor.getInt(11));
		info.setGame(cursor.getInt(12));
		info.setChild_id(cursor.getString(13));
		return info;
	}
}
