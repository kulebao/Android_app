package com.cocobaby.teacher.proxy;


public interface MyProxyImpl {
	public Object handle() throws Exception;
}
