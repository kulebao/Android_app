package com.cocobaby.teacher.im;

public interface ForbidUser{
    public void forbidUser(String userid, boolean forbid);
}
