package com.cocobaby.teacher.im;

import io.rong.imkit.RongIM;
import io.rong.imkit.fragment.ConversationListFragment;
import io.rong.imlib.RongIMClient;
import io.rong.imlib.model.Conversation;

import java.util.ArrayList;
import java.util.List;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.activities.ActivityHelper;
import com.cocobaby.teacher.activities.ContactListActivity;
import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.utils.IMUtils;

/**
 * Created by Bob on 15/8/18. 会话列表
 */
@SuppressLint("NewApi")
public class ConversationListActivity extends FragmentActivity{

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.im_conversationlist);

        initUI();

        isReconnect();
    }

    private void initUI(){
        ImageView contact = (ImageView)findViewById(R.id.rightImage);
        contact.setVisibility(View.VISIBLE);
        contact.setImageResource(R.drawable.contactbtn);

        contact.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();

                if(allClasses.size() > 1){
                    showListDlg();
                } else{
                    startToContactListActivity(allClasses.get(0).getClassID() + "");
                }
            }
        });

        setActionBarTitle("家园互动");
    }

    private void startToContactListActivity(String class_id){
        Intent intent = new Intent(ConversationListActivity.this, ContactListActivity.class);
        intent.putExtra(ConstantValue.CLASS_ID, class_id);
        intent.putExtra(ConstantValue.SHOW_GROUP_ENTRY, true);
        ConversationListActivity.this.startActivity(intent);
    }

    protected void showListDlg(){
        AlertDialog.Builder builder = new AlertDialog.Builder(ConversationListActivity.this);
        builder.setIcon(R.drawable.small_logo);
        builder.setTitle("选择一个班级");

        final List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();

        List<String> classnamelist = new ArrayList<>();
        for(ClassInfo classInfo : allClasses){
            classnamelist.add(classInfo.getClassName());
        }

        final String[] array = classnamelist.toArray(new String[classnamelist.size()]);

        builder.setItems(array, new DialogInterface.OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                String class_id = allClasses.get(which).getClassID() + "";
                startToContactListActivity(class_id);
            }
        });
        builder.show();
    }

    /**
     * 设置 actionbar title
     */
    private void setActionBarTitle(String title){
        ActivityHelper.setTopbarTitle(this, title);
    }

    /**
     * 加载 会话列表 ConversationListFragment
     */
    private void enterFragment(){

        ConversationListFragment fragment = (ConversationListFragment)getSupportFragmentManager()
                .findFragmentById(R.id.conversationlist);

        Uri uri = Uri.parse("rong://" + getApplicationInfo().packageName).buildUpon().appendPath("conversationlist")
                .appendQueryParameter(Conversation.ConversationType.PRIVATE.getName(), "false") // 设置私聊会话非聚合显示
                .appendQueryParameter(Conversation.ConversationType.GROUP.getName(), "false")// 设置群组会话聚合显示
                .appendQueryParameter(Conversation.ConversationType.DISCUSSION.getName(), "false")// 设置讨论组会话非聚合显示
                .appendQueryParameter(Conversation.ConversationType.SYSTEM.getName(), "false")// 设置系统会话非聚合显示
                .build();

        fragment.setUri(uri);
    }

    /**
     * 判断消息是否是 push 消息
     *
     */
    private void isReconnect(){

        Intent intent = getIntent();

        String token = IMUtils.getToken();

        // push或通知过来
        if(intent != null && intent.getData() != null && intent.getData().getScheme().equals("rong")){

            // 通过intent.getData().getQueryParameter("push") 为true，判断是否是push消息
            if(intent.getData().getQueryParameter("push") != null
                    && intent.getData().getQueryParameter("push").equals("true")){
                reconnect(token);
            } else{
                // 程序切到后台，收到消息后点击进入,会执行这里
                if(RongIM.getInstance() == null || RongIM.getInstance().getRongIMClient() == null){
                    reconnect(token);
                } else{
                    enterFragment();
                }
            }
        }

    }

    /**
     * 重连
     *
     * @param token
     */
    private void reconnect(String token){

        if(getApplicationInfo().packageName.equals(MyApplication.getCurProcessName(getApplicationContext()))){

            RongIM.connect(token, new RongIMClient.ConnectCallback(){
                @Override
                public void onTokenIncorrect(){

                }

                @Override
                public void onSuccess(String s){
                    enterFragment();
                }

                @Override
                public void onError(RongIMClient.ErrorCode errorCode){

                }
            });
        }
    }
}
