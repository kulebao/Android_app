package com.cocobaby.teacher.customexception;

public class AutoLoginFailException extends CustomException {

	private static final long serialVersionUID = 1L;

	public AutoLoginFailException() {
		super();
	}

	public AutoLoginFailException(String detailMessage) {
		super(detailMessage);
	}

}
