package com.cocobaby.teacher.pojo;

import java.util.ArrayList;
import java.util.List;

import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;

public class IMExpandInfo{
    // 在扩展列表中，小孩是一级菜单，家长是二级菜单,有点绕。。。
    private ChildInfo        childInfo;
    private List<ParentInfo> groupParentInfoList = new ArrayList<>();

    public ChildInfo getChildInfo(){
        return childInfo;
    }

    public void setChildInfo(ChildInfo childInfo){
        this.childInfo = childInfo;
    }

    public List<ParentInfo> getGroupParentInfoList(){
        return groupParentInfoList;
    }

    public void setGroupParentInfoList(List<ParentInfo> groupParentInfoList){
        this.groupParentInfoList = groupParentInfoList;
    }

}
