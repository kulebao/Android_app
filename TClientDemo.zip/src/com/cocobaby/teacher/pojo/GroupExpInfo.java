package com.cocobaby.teacher.pojo;

public class GroupExpInfo {
	private String month = "";
	private int count = 0;

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

}
