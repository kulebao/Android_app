package com.cocobaby.teacher.media;

import android.content.Context;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.util.Log;

import com.cocobaby.teacher.utils.DataUtils;

public class MyMediaScannerConnectionClient{
    private MediaScannerConnection msc;
    private Uri                    uri;

    public MyMediaScannerConnectionClient(Context context){
        msc = new MediaScannerConnection(context, new PicMediaScannerConnectionClient());
    }

    public void addPicToGallery(Uri uri){
        this.uri = uri;
        msc.connect();
    }

    private class PicMediaScannerConnectionClient implements MediaScannerConnectionClient{

        @Override
        public void onMediaScannerConnected(){
            try{
                Log.d("DDD", "onMediaScannerConnected");
                msc.scanFile(DataUtils.getPath(uri), "image/jpeg");
            } catch(Exception e){
                e.printStackTrace();
            }
        }

        @Override
        public void onScanCompleted(String path, Uri uri){
            Log.d("DDD", "onScanCompleted");
            msc.disconnect();
        }

    }

}
