package com.cocobaby.teacher.handler;

import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v4.content.IntentCompat;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.activities.LoginActivity;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.utils.Utils;

public class MyHandler extends Handler {

	private Dialog dialog;
	private Activity activity;

	public MyHandler(Activity activity) {
		this(activity, null);
	}

	public MyHandler(Activity activity, Dialog dialog) {
		this.activity = activity;
		this.dialog = dialog;
	}

	@Override
	public void handleMessage(Message msg) {
		if (msg.arg2 != ConstantValue.DO_NOT_CANCEL_DIALOG && dialog != null) {
			dialog.cancel();
		}

		switch (msg.what) {
		case EventType.NET_WORK_INVALID:
			Toast.makeText(activity, R.string.net_error, Toast.LENGTH_SHORT).show();
			break;
		case EventType.SERVER_INNER_ERROR:
			Toast.makeText(activity, R.string.server_busy, Toast.LENGTH_SHORT).show();
			break;
		case EventType.SERVER_BUSY:
			Toast.makeText(activity, R.string.server_busy, Toast.LENGTH_SHORT).show();
			break;
		case EventType.AUTO_LOGIN_FAIL:
			showRestartDlg(R.string.token_invalid);
			break;

		default:
			break;
		}
	}

	private void showRestartDlg(int resID) {
		DlgMgr.showSingleBtnResDlg(resID, activity, new OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Utils.clearProp();
				DataMgr.getInstance().clearAll();
				Utils.clearSDFolder();
				restartApp();
			}
		});
	}

	private void restartApp() {
		Intent intent = new Intent(activity, LoginActivity.class);
		ComponentName cn = intent.getComponent();
		Intent mainIntent = IntentCompat.makeRestartActivityTask(cn);
		activity.startActivity(mainIntent);
	}

}
