package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ChildMethod {
	private ChildMethod() {
	}

	public static ChildMethod getMethod() {
		return new ChildMethod();
	}

	public MethodResult getChildren() throws Exception {
		if (InfoHelper.classIsEmpty()) {
			return new MethodResult(EventType.GET_CHILDREN_SUCCESS);
		}

		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createCommand();
		Log.d("", "cmd=" + command);
		result = HttpClientHelper.executeGet(command);
		bret = handle(result);
		return bret;
	}

	private MethodResult handle(HttpResult result) throws JSONException {
		MethodResult methodResult = new MethodResult(EventType.GET_CHILDREN_FAIL);
		if (result.getResCode() == HttpStatus.SC_OK) {
			methodResult.setResultType(EventType.GET_CHILDREN_SUCCESS);

			JSONArray jsonArray = result.getJSONArray();
			parseChildInfoFromArray(jsonArray);
			Log.d("DDD ChildMethod", "info:" + jsonArray.toString());
		}

		return methodResult;
	}

	private void parseChildInfoFromArray(JSONArray jsonArray) throws JSONException {
		List<ChildInfo> list = new ArrayList<ChildInfo>();
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			ChildInfo info = ChildInfo.parseChildInfo(jsonObject);
			list.add(info);
		}
		// 存新的之前先删除旧的
		DataMgr.getInstance().clearChild();
		DataMgr.getInstance().addChildList(list);
	}

	private String createCommand() {
		String url = String.format(ServerUrls.GET_CHILDREN, Utils.getProp(JSONConstant.SCHOOL_ID));
		url += "class_id=" + InfoHelper.getAllClassIDs(DataMgr.getInstance().getAllClasses()) + "&connected=true";
		return url;
	}
}
