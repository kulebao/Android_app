package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class NewsMethod{

    private static final String MOST = "most";
    private static final String FROM = "from";
    private static final String TO   = "to";
    private int                 type;

    private NewsMethod(){}

    public static NewsMethod getMethod(){
        return new NewsMethod();
    }

    public MethodResult getNormalNews(int most, long from, long to, int getType) throws Exception{
        this.type = getType;
        HttpResult result = new HttpResult();
        String command = createNormalNoticeCommand(most, from, to);
        Log.e("DDDDD ", "getSchoolInfo cmd:" + command);
        result = HttpClientHelper.executeGet(command);
        MethodResult bret = handleGetNormalNewsResult(result);
        return bret;
    }

    private MethodResult handleGetNormalNewsResult(HttpResult result) throws JSONException{
        MethodResult bret = new MethodResult(EventType.GET_NEWS_FAIL);
        List<News> list = new ArrayList<News>();
        if(result.getResCode() == HttpStatus.SC_OK){
            JSONArray array = result.getJSONArray();

            for(int i = 0; i < array.length(); i++){
                JSONObject object = array.getJSONObject(i);
                News info = parseNews(object);
                list.add(info);
            }

            // 如果是获取最新的公告，并且获取的数量超过或者等于一次性获取到的最大数量
            // 说明可能还有公告没有获取完，为了避免再也无法获取到这些公告，简单点处理
            // 删除本地保存的所有公告。
            // 复杂处理的处理办法是（暂不考虑实现），继续通过这次获取到的最后一条
            // 公告的时间搓，继续获取下去，直到获取的公告在本地已经有了
            if(type == ConstantValue.Type_INSERT_HEAD && list.size() >= ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT){
                DataMgr.getInstance().removeAllNewsByType(JSONConstant.NOTICE_TYPE_NORMAL);
            }

            DataMgr.getInstance().addNewsList(list);

            bret.setResultType(EventType.GET_NEWS_SUCCESS);
            bret.setResultObj(list);
        }

        return bret;
    }

    private News parseNews(JSONObject object) throws JSONException{
        News info = new News();
        String title = object.getString("title");
        long timestamp = object.getLong(JSONConstant.TIME_STAMP);
        String body = object.getString("content");
        int serverID = object.getInt("news_id");
        String tags = object.getJSONArray("tags").toString();
        int class_id = object.getInt("class_id");
        String image = object.getString("image");
        boolean needReceipt = object.getBoolean("feedback_required");

        info.setClass_id(class_id);
        info.setContent(body);
        info.setNews_server_id(serverID);
        // info.setPublisher("测试djc");
        info.setIcon_url(image);
        info.setTitle(title);
        info.setTimestamp(timestamp);
        info.setType(JSONConstant.NOTICE_TYPE_NORMAL);
        info.setNeed_receipt(needReceipt ? 1 : 0);
        info.setTags(tags);
        return info;
    }

    private String createNormalNoticeCommand(int most, long from, long to){
        if(most == 0){
            most = ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT;
        }
        String cmd = String.format(ServerUrls.GET_NOTICE_WITH_TAGS, Utils.getSchoolID());

        cmd += MOST + "=" + most;
        if(from != 0){
            cmd += "&" + FROM + "=" + from;
        }

        if(to != 0){
            cmd += "&" + TO + "=" + to;
        }

        cmd += "&class_id=" + MethodHelper.getAllFormatedClassid();

        // 返回的公告带标签
        cmd += "&tag=true";

        Log.d("DDD", "createNormalNoticeCommand cmd=" + cmd);
        return cmd;
    }

    public MethodResult deleteNews(int newsid) throws Exception{
        // String url = createDeleteNewsUrl(newsid);
        String url = createDeleteNewsUrlEx(newsid);
        Log.d("DDD", "deleteNews url=" + url);
        HttpResult result = HttpClientHelper.executeDelete(url);
        Log.d("DDD", "deleteNews result=" + result.getContent());
        MethodResult bret = handleDeleteNewsResult(result);
        return bret;
    }

    private MethodResult handleDeleteNewsResult(HttpResult result) throws JSONException{
        MethodResult bret = new MethodResult(EventType.DELETE_NEWS_FAIL);

        if(result.getResCode() == HttpStatus.SC_OK && result.getErrorCode() == 0){
            bret.setResultType(EventType.DELETE_NEWS_SUCCESS);
        }
        return bret;
    }

    private String createDeleteNewsUrl(int newsid){
        return String.format(ServerUrls.DELETE_NEWS_URL, Utils.getSchoolID(), newsid);
    }

    private String createDeleteNewsUrlEx(int newsid){
        return String.format(ServerUrls.DELETE_NEWS_URL_EX, Utils.getSchoolID(), DataMgr.getInstance().getTeacherInfo()
                .getServer_id(), newsid);
    }

    public MethodResult sendNews(News news) throws Exception{
        String url = createSendNewsUrl();
        String command = createSendNewsCommand(news);
        Log.d("DDD", "sendNews cmd=" + command);
        Log.d("DDD", "sendNews url=" + url);
        HttpResult result = HttpClientHelper.executePost(url, command);
        MethodResult bret = handleSendNewsResult(result);
        return bret;
    }

    private MethodResult handleSendNewsResult(HttpResult result) throws JSONException{
        MethodResult bret = new MethodResult(EventType.SEND_NEWS_FAIL);

        if(result.getResCode() == HttpStatus.SC_OK){
            JSONObject object = result.getJsonObject();
            News info = parseNews(object);
            bret.setResultType(EventType.SEND_NEWS_SUCCESS);
            bret.setResultObj(info);
        }
        return bret;
    }

    private String createSendNewsCommand(News news) throws JSONException{
        JSONObject object = new JSONObject();

        object.put(JSONConstant.SCHOOL_ID, Utils.getSchoolID());
        object.put(News.TITLE, news.getTitle());
        object.put(News.CONTENT, news.getContent());
        object.put(News.CLASS_ID, news.getClass_id());
        // 设置为true，表示该条公告计入积分
        object.put("published", true);
        object.put("publisher_id", DataMgr.getInstance().getTeacherInfo().getServer_id());

        if(!TextUtils.isEmpty(news.getIcon_url())){
            object.put("image", news.getIcon_url());
        }

        object.put("feedback_required", news.getNeed_receipt() == 1);

        object.put("tags", getTags(news.getTags()));
        return object.toString();
    }

    private Object getTags(String tags) throws JSONException{
        JSONArray array = new JSONArray();

        if(!TextUtils.isEmpty(tags)){
            array.put(0, tags);
        }
        return array;
    }

    private String createSendNewsUrl(){
        return String.format(ServerUrls.SEND_NEWS_URL_WITH_FEEDBACK, Utils.getSchoolID(), DataMgr.getInstance()
                .getTeacherInfo().getServer_id());
    }

}
