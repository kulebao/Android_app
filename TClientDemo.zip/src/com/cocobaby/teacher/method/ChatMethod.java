package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ChatMethod {

	private static final String MOST = "most";
	private static final String FROM = "from";
	private static final String TO = "to";

	private ChatMethod() {
	}

	public static ChatMethod getMethod() {
		return new ChatMethod();
	}

	public MethodResult getChatInfo(int most, long from, long to, String childid)
			throws Exception {
		MethodResult methodResult = new MethodResult(EventType.GET_CHAT_SUCCESS);

		List<ChatInfo> list = new ArrayList<ChatInfo>();
		HttpResult result = new HttpResult();
		String command = createGetChatInfoCommand(most, from, to, childid);
		Log.e("DDDDD ", "getSchoolInfo cmd:" + command);
		result = HttpClientHelper.executeGet(command);
		if (!result.isRequestOK()) {
			methodResult.setResultType(EventType.GET_CHAT_FAIL);
			return methodResult;
		}
		list = handleGetChatMethodResult(result);
		methodResult.setResultObj(list);
		return methodResult;
	}

	public MethodResult getLastChatByClassid() throws Exception {
		MethodResult methodResult = new MethodResult(EventType.GET_CHAT_FAIL);
		Map<String, ChatInfo> map = new HashMap<String, ChatInfo>();
		HttpResult result = new HttpResult();
		Log.d("DJC", "getLastChatByClassid");
		if (!InfoHelper.classIsEmpty()) {
			String command = createGetLastChatInfoCommand();
			result = HttpClientHelper.executeGet(command);
			if (result.isRequestOK()) {
				JSONArray array = result.getJSONArray();
				Log.d("DJC", "array =" + array.toString());
				for (int i = 0; i < array.length(); i++) {
					JSONObject object = array.getJSONObject(i);
					ChatInfo info = ChatInfo.parseFromJson(object);
					Log.d("DJC", "put new content=" + info.getContent());
					map.put(info.getChild_id(), info);
				}
				methodResult.setResultType(EventType.GET_CHAT_SUCCESS);
			}
		}
		methodResult.setResultObj(map);
		return methodResult;
	}

	private String createGetLastChatInfoCommand() {
		String cmd = String.format(ServerUrls.GET_LAST_CHAT,
				Utils.getSchoolID());
		cmd += "class_id="
				+ InfoHelper.getAllClassIDs(DataMgr.getInstance()
						.getAllClasses());
		return cmd;
	}

	public MethodResult sendChat(String content, long lastid, String childid)
			throws Exception {
		MethodResult methodResult = new MethodResult(
				EventType.SEND_CHAT_SUCCESS);
		List<ChatInfo> list = new ArrayList<ChatInfo>();
		HttpResult result = new HttpResult();
		String url = createSendChatUrl(lastid, childid);
		Log.e("DDDDD ", "uploadChildInfo cmd:" + url + " content=" + content);
		result = HttpClientHelper.executePost(url, content);
		if (result.getResCode() != HttpStatus.SC_OK) {
			methodResult.setResultType(EventType.SEND_CHAT_FAIL);
			return methodResult;
		}
		list = handleGetChatMethodResult(result);
		if (list.size() > 1) {
			Collections.reverse(list);
		}
		methodResult.setResultObj(list);
		return methodResult;
	}

	private String createSendChatUrl(long lastid, String childid) {
		String url = String.format(ServerUrls.SEND_CHAT, Utils.getSchoolID(),
				childid);

		if (lastid != 0) {
			url += "?retrieve_recent_from=" + lastid;
		}
		return url;
	}

	private List<ChatInfo> handleGetChatMethodResult(HttpResult result)
			throws JSONException {
		List<ChatInfo> list = new ArrayList<ChatInfo>();
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONArray array = result.getJSONArray();

			for (int i = 0; i < array.length(); i++) {
				JSONObject object = array.getJSONObject(i);
				ChatInfo info = ChatInfo.parseFromJson(object);
				list.add(info);
			}
		}

		return list;
	}

	private String createGetChatInfoCommand(int most, long from, long to,
			String childid) {
		String cmd = String.format(ServerUrls.GET_CHAT, Utils.getSchoolID(),
				childid);
		if (most == 0) {
			most = ConstantValue.GET_CHATINFO_MAX_COUNT;
		}

		cmd += MOST + "=" + most;
		if (from != 0) {
			cmd += "&" + FROM + "=" + from;
		}

		if (to != 0) {
			cmd += "&" + TO + "=" + to;
		}

		Log.d("DDD", "createGetChatInfoCommand cmd=" + cmd);
		return cmd;
	}

	public MethodResult deleteChat(long chatid, String childid)
			throws Exception {
		MethodResult methodResult = new MethodResult(
				EventType.DELETE_CHAT_SUCCESS);
		HttpResult result = new HttpResult();
		String url = createDeleteChatUrl(chatid, childid);
		Log.e("DDDDD ", "deleteChat cmd:" + url + " content=" + chatid);
		result = HttpClientHelper.executeDelete(url);
		Log.e("DDDDD ", " result =" + result.getContent());
		if (result.getResCode() != HttpStatus.SC_OK) {
			methodResult.setResultType(EventType.DELETE_CHAT_FAIL);
		}
		return methodResult;
	}

	private String createDeleteChatUrl(long chatid, String childid) {
		String url = String.format(ServerUrls.DELETE_CHAT, Utils.getSchoolID(),
				childid, chatid);
		return url;
	}
}
