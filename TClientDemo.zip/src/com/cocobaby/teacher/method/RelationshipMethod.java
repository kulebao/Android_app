package com.cocobaby.teacher.method;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class RelationshipMethod{
    private RelationshipMethod(){}

    public static RelationshipMethod getMethod(){
        return new RelationshipMethod();
    }

    public MethodResult getRelationship(String childid) throws Exception{
        MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String command = createCommand(childid);
        Log.d("", "cmd=" + command);
        result = HttpClientHelper.executeGet(command);
        bret = handle(result, childid);
        return bret;
    }

    private MethodResult handle(HttpResult result, String childid) throws JSONException{
        MethodResult methodResult = new MethodResult(EventType.GET_RELATIONSHIP_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){

            JSONArray jsonArray = result.getJSONArray();
            parseParentFromArray(jsonArray, childid);
            methodResult.setResultType(EventType.GET_RELATIONSHIP_SUCCESS);
            Log.d("DDD ChildMethod", "info:" + jsonArray.toString());
        }

        return methodResult;
    }

    private void parseParentFromArray(JSONArray jsonArray, String childid) throws JSONException{
        DataMgr.getInstance().removeRelationShip(childid);
        for(int i = 0; i < jsonArray.length(); i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            ParentInfo info = ParentInfo.parse(jsonObject);
            String relationship = jsonObject.optString("relationship");
            DataMgr.getInstance().addRelationship(childid, info, relationship);
        }
    }

    private String createCommand(String childid){
        String url = String.format(ServerUrls.GET_RELATIONSHIP, Utils.getSchoolID());
        url += "child=" + childid;
        return url;
    }

    public MethodResult getClassRelationship(String classid) throws Exception{
        MethodResult bret = new MethodResult(EventType.GET_CLASS_RELATIONSHIP_FAIL);
        HttpResult result = new HttpResult();
        String command = createGetClassRelationshipCommand(classid);
        Log.d("", "getClassRelationship cmd=" + command);
        result = HttpClientHelper.executeGet(command);
        Log.d("", "getClassRelationship result=" + result.getContent());
        bret = handleGetClassRelationship(result);
        return bret;
    }

    private MethodResult handleGetClassRelationship(HttpResult result) throws Exception{
        MethodResult methodResult = new MethodResult(EventType.GET_CLASS_RELATIONSHIP_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            DataMgr.getInstance().addGroupInfo(result.getContent());
            methodResult.setResultType(EventType.GET_CLASS_RELATIONSHIP_SUCCESS);
        }

        return methodResult;
    }

    private String createGetClassRelationshipCommand(String classid){
        String url = String.format(ServerUrls.GET_CLASS_RELATIONSHIP, Utils.getSchoolID());
        url += "class_id=" + classid;
        return url;
    }

}
