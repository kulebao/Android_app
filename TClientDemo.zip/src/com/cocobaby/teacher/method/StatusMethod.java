package com.cocobaby.teacher.method;

import java.util.HashMap;
import java.util.Map;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildStatus;
import com.cocobaby.teacher.dbmgr.info.InfoHelper;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class StatusMethod {
	private StatusMethod() {
	}

	public static StatusMethod getMethod() {
		return new StatusMethod();
	}

	public MethodResult getChildStatus() throws Exception {
		if (InfoHelper.classIsEmpty()) {
			return new MethodResult(EventType.GET_CHILD_STATUS_SUCCESS);
		}

		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createCommand();
		Log.d("", "cmd=" + command);
		result = HttpClientHelper.executeGet(command);
		bret = handle(result);
		return bret;
	}

	private MethodResult handle(HttpResult result) throws JSONException {
		MethodResult methodResult = new MethodResult(
				EventType.GET_CHILD_STATUS_FAIL);
		if (result.getResCode() == HttpStatus.SC_OK) {
			methodResult.setResultType(EventType.GET_CHILD_STATUS_SUCCESS);

			JSONArray jsonArray = result.getJSONArray();
			Log.d("DDD StatusMethod", "info:" + jsonArray.toString());
			parseChildStatusFromArray(jsonArray);
		}

		return methodResult;
	}

	private void parseChildStatusFromArray(JSONArray jsonArray)
			throws JSONException {
		Map<String, ChildStatus> map = new HashMap<String, ChildStatus>();
		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			ChildStatus info = ChildStatus.parse(jsonObject);
			map.put(info.getChild_id(), info);
		}
		MyApplication.getInstance().setChildStatusMap(map);
	}

	private String createCommand() {
		String url = String.format(ServerUrls.GET_CHILD_STATUS,
				Utils.getProp(JSONConstant.SCHOOL_ID));
		url += "class_id="
				+ InfoHelper.getAllClassIDs(DataMgr.getInstance()
						.getAllClasses());
		return url;
	}
}
