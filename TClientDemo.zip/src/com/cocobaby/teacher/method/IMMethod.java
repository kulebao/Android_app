package com.cocobaby.teacher.method;

import org.apache.http.HttpStatus;

import android.util.Log;

import com.alibaba.fastjson.JSONObject;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.IMGroupInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class IMMethod{
    private IMMethod(){}

    public static IMMethod getMethod(){
        return new IMMethod();
    }

    public MethodResult getGroupInfo(String classid) throws Exception{
        HttpResult result = new HttpResult();
        String command = createCommand(classid);
        Log.d("", " DDD getGroupInfo getInfo  command: " + command);
        result = HttpClientHelper.executeGet(command);
        Log.d("", " DDD getGroupInfo getInfo result : " + result.getContent());
        return getResult(result);
    }

    private MethodResult getResult(HttpResult result) throws Exception{
        MethodResult methodResult = new MethodResult(EventType.GET_IM_GROUP_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            IMGroupInfo groupinfo = JSONObject.parseObject(result.getContent(), IMGroupInfo.class);
            DataMgr.getInstance().addIMGroupInfo(groupinfo);
            methodResult.setResultObj(groupinfo);
            methodResult.setResultType(EventType.GET_IM_GROUP_SUCCESS);
        }
        return methodResult;
    }

    private String createCommand(String classid){
        String cmd = String.format(ServerUrls.GET_GROUP_INFO_URL, Utils.getSchoolID(), classid);
        return cmd;
    }
}
