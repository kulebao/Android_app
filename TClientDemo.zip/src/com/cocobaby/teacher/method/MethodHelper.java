package com.cocobaby.teacher.method;

import java.util.List;

import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;

public class MethodHelper {

	public static String getAllFormatedClassid() {
		StringBuffer classIDs = new StringBuffer();
		List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
		for (ClassInfo classInfo : allClasses) {
			classIDs.append(classInfo.getClassID() + ",");
		}
		return classIDs.substring(0, classIDs.length() - 1);
	}

	public static boolean isInit() {
		List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
		return !allClasses.isEmpty();
	}

}
