package com.cocobaby.teacher.method;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ChangePWDMethod {
	private ChangePWDMethod() {
	}

	public static ChangePWDMethod getMethod() {
		return new ChangePWDMethod();
	}

	// 在忘记密码的情况下，通过短信收到的校验码进行密码重置
	public MethodResult changePwd(String newPwd, String oldPwd) throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();

		String command = createChangePWDCommand(newPwd, oldPwd);
		String url = getUrl();
		Log.d("DDD", "changePwd url=" + url + " \n command=" + command);
		result = HttpClientHelper.executePost(url, command);
		bret = handleResult(result);
		return bret;
	}

	private String getUrl() {
		String url = String.format(ServerUrls.CHANGE_PWD_URL, Utils.getSchoolID(), DataMgr.getInstance()
				.getTeacherInfo().getPhone());
		return url;
	}

	private MethodResult handleResult(HttpResult result) throws JSONException {
		MethodResult bret = new MethodResult(EventType.CHANGE_PWD_FAIL);
		Log.d("DDD", "changePwd handleResult result=" + result.getContent());
		if (result.getResCode() == HttpStatus.SC_OK) {
			bret.setResultType(EventType.CHANGE_PWD_SUCCESS);
		} else {
			bret.setResultType(EventType.OLD_PWD_NOT_EQUAL);
		}

		return bret;
	}

	private String createChangePWDCommand(String newPwd, String odlPwd) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		TeacherInfo teacherInfo = DataMgr.getInstance().getTeacherInfo();
		jsonObject.put(JSONConstant.EMPLOYEE_ID, teacherInfo.getServer_id());
		jsonObject.put(TeacherInfo.LOGIN_NAME, teacherInfo.getLogin_name());
		jsonObject.put(JSONConstant.NEW_PASSWORD, newPwd);
		jsonObject.put(JSONConstant.OLD_PASSWORD, odlPwd);
		jsonObject.put(TeacherInfo.PHONE, teacherInfo.getPhone());
		jsonObject.put(JSONConstant.SCHOOL_ID, Utils.getSchoolID());
		return jsonObject.toString();
	}
}
