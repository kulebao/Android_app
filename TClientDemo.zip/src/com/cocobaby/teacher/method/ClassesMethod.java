package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ClassesMethod{
    private ClassesMethod(){}

    public static ClassesMethod getMethod(){
        return new ClassesMethod();
    }

    public MethodResult getAllIneligibleClassInfo() throws Exception{
        MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String command = createGetIneligibleClassCommand();
        Log.d("", "getIneligibleClassInfo command =" + command);
        result = HttpClientHelper.executeGet(command);
        Log.d("", "getIneligibleClassInfo result:" + result.getContent());
        bret = handleGetAllIneligibleClass(result);
        return bret;
    }

    private MethodResult handleGetAllIneligibleClass(HttpResult result) throws JSONException{
        MethodResult methodResult = new MethodResult(EventType.WITHOUT_SCHOOL_NOTICE_PRIVILEGE);
        if(result.getResCode() == HttpStatus.SC_OK){
            JSONArray jsonArray = result.getJSONArray();
            // 没有权限的班级为空，表示支持管理全部班级
            if(jsonArray.length() == 0){
                methodResult.setResultType(EventType.WITH_SCHOOL_NOTICE_PRIVILEGE);
            }
        }

        return methodResult;
    }

    public MethodResult getAllClassInfo() throws Exception{
        MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String command = createGetIneligibleClassCommand();
        Log.d("", "getAllClassInfo command =" + command);
        result = HttpClientHelper.executeGet(command);
        Log.d("", "getAllClassInfo result:" + result.getContent());
        bret = handleGetAllClass(result);
        return bret;
    }

    private MethodResult handleGetAllClass(HttpResult result) throws JSONException{
        MethodResult methodResult = new MethodResult(EventType.GET_CLASSES_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            JSONArray jsonArray = result.getJSONArray();
            List<Integer> list = new ArrayList<Integer>();

            for(int i = 0; i < jsonArray.length(); i++){
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                list.add(jsonObject.getInt(ClassInfo.CLASS_ID));
            }
            methodResult.setResultObj(list);
            methodResult.setResultType(EventType.GET_CLASSES_SUCCESS);
        }

        return methodResult;
    }

    public MethodResult getInfo() throws Exception{
        MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String command = createCommand();
        result = HttpClientHelper.executeGet(command);
        bret = handle(result);
        return bret;
    }

    private MethodResult handle(HttpResult result) throws JSONException{
        MethodResult methodResult = new MethodResult(EventType.GET_CLASSES_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            methodResult.setResultType(EventType.GET_CLASSES_SUCCESS);

            JSONArray jsonArray = result.getJSONArray();
            parseClassInfoFromArray(jsonArray);
            Log.d("DDD ClassesMethod", "info:" + jsonArray.toString());
        }

        return methodResult;
    }

    private void parseClassInfoFromArray(JSONArray jsonArray) throws JSONException{
        List<ClassInfo> list = getClassList(jsonArray);
        // 先清空班级，再获取，每次都取最新的
        DataMgr.getInstance().clearClass();
        DataMgr.getInstance().addClassList(list);
    }

    private List<ClassInfo> getClassList(JSONArray jsonArray) throws JSONException{
        List<ClassInfo> list = new ArrayList<ClassInfo>();
        for(int i = 0; i < jsonArray.length(); i++){
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            ClassInfo info = new ClassInfo();
            info.setClassID(jsonObject.getInt(ClassInfo.CLASS_ID));
            info.setClassName(jsonObject.getString(ClassInfo.CLASS_NAME));
            list.add(info);
        }
        return list;
    }

    private String createCommand(){
        return String.format(ServerUrls.GET_CLASSES, Utils.getProp(JSONConstant.SCHOOL_ID), DataMgr.getInstance()
                .getTeacherInfo().getPhone());
    }

    private String createGetIneligibleClassCommand(){
        return String.format(ServerUrls.GET_INELIGIBLE_CLASSES, Utils.getProp(JSONConstant.SCHOOL_ID), DataMgr
                .getInstance().getTeacherInfo().getUid());
    }
}
