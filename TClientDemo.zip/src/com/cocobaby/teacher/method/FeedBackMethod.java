package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.alibaba.fastjson.JSON;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class FeedBackMethod {

	private static final String PHONE_NUM = "phone";
	private static final String FEEDBACK_CONTENT = "content";
	private static final String SOURCE = "source";
	private static final String ANDROID_TEACHER = "android_teacher";

	private FeedBackMethod() {
	}

	public static FeedBackMethod getMethod() {
		return new FeedBackMethod();
	}

	public MethodResult feedBack(String content) throws Exception {
		MethodResult methodResult = new MethodResult(EventType.FEEDBACK_FAILED);
		HttpResult result = new HttpResult();
		String url = ServerUrls.FEED_BACK;
		Log.e("DDDDD ", "uploadChildInfo cmd:" + url);
		String command = formatContent(content);
		result = HttpClientHelper.executePost(url, command);
		methodResult = handleFeedbackResult(result);
		return methodResult;
	}

	private String formatContent(String content) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(PHONE_NUM, DataMgr.getInstance().getTeacherInfo().getPhone());
		jsonObject.put(FEEDBACK_CONTENT, content);
		jsonObject.put(SOURCE, ANDROID_TEACHER);
		return jsonObject.toString();
	}

	private MethodResult handleFeedbackResult(HttpResult result) throws JSONException {
		MethodResult methodResult = new MethodResult(EventType.FEEDBACK_FAILED);
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONObject jsonObject = result.getJsonObject();
			Log.d("DDD handleGetChildInfoResult", "str : " + jsonObject.toString());
			int errorcode = jsonObject.getInt(JSONConstant.ERROR_CODE);
			// 登录成功，保存token
			if (errorcode == 0) {
				methodResult.setResultType(EventType.FEEDBACK_SUCESS);
			}
		}

		return methodResult;
	}

	public MethodResult checkFeedBack(int newid) throws Exception {
		MethodResult methodResult = new MethodResult(EventType.CHECK_FEEDBACK_FAILED);
		HttpResult result = new HttpResult();
		String command = createCheckFeedBackCommand(newid);
		Log.e("DDDDD ", "checkFeedBack cmd:" + command);
		result = HttpClientHelper.executeGet(command);
		methodResult = handleCheckFeedbackResult(result);
		return methodResult;
	}

	private MethodResult handleCheckFeedbackResult(HttpResult result) {
		MethodResult methodResult = new MethodResult(EventType.CHECK_FEEDBACK_FAILED);
		if (result.getResCode() == HttpStatus.SC_OK) {
			List<ParentInfo> parents = JSON.parseArray(result.getContent(), ParentInfo.class);
			if (parents == null) {
				parents = new ArrayList<ParentInfo>();
			}
			methodResult.setResultType(EventType.CHECK_FEEDBACK_SUCESS);
			methodResult.setResultObj(parents);
		}
		return methodResult;
	}

	private String createCheckFeedBackCommand(int newid) {
		return String.format(ServerUrls.CHECK_FEEDBACK, Utils.getProp(JSONConstant.SCHOOL_ID), newid);
	}

}
