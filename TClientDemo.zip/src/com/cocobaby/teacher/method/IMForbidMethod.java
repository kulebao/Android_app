package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;

import android.util.Log;

import com.alibaba.fastjson.JSONArray;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.pojo.ForbidInfo;
import com.cocobaby.teacher.utils.Utils;

public class IMForbidMethod{
    private IMForbidMethod(){}

    public static IMForbidMethod getMethod(){
        return new IMForbidMethod();
    }

    // 群组禁言
    public MethodResult forbidUser(String classid, String userid) throws Exception{
        String url = createForbidUrl(classid);
        String content = createForbidContent(userid);
        Log.d("", " DDD forbidUser getInfo  url: " + url);
        Log.d("", " DDD forbidUser getInfo  content: " + content);
        HttpResult result = HttpClientHelper.executePost(url, content);
        Log.d("", " DDD forbidUser getInfo result : " + result.getContent());
        return getForbidResult(result, userid);
    }

    // 解除群组禁言
    public MethodResult unForbidUser(String classid, String userid) throws Exception{
        String url = createUnForbidUrl(classid, userid);
        Log.d("", " DDD unForbidUser getInfo  url: " + url);
        HttpResult result = HttpClientHelper.executeDelete(url);
        Log.d("", " DDD unForbidUser getInfo result : " + result.getContent());
        return getUnForbidResult(result, userid);
    }

    // 获取群组禁言名单
    public MethodResult getForbidUsers(String classid) throws Exception{
        String url = createForbidUrl(classid);
        Log.d("", " DDD getForbidUsers getInfo  url: " + url);
        HttpResult result = HttpClientHelper.executeGet(url);
        Log.d("", " DDD getForbidUsers getInfo result : " + result.getContent());
        return getForbidUsersResult(result);
    }

    private MethodResult getForbidUsersResult(HttpResult result){
        MethodResult methodResult = new MethodResult(EventType.GET_GROUP_FORBID_USERS_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            List<ForbidInfo> list = JSONArray.parseArray(result.getContent(), ForbidInfo.class);
            methodResult.setResultObj(list);
            methodResult.setResultType(EventType.GET_GROUP_FORBID_USERS_SUCCESS);
        }
        return methodResult;
    }

    private String createForbidContent(String userid){
        List<Forbid> list = new ArrayList<>();
        Forbid forbid = new Forbid();
        forbid.setId(userid);
        list.add(forbid);
        return JSONArray.toJSONString(list, true);
    }

    private MethodResult getUnForbidResult(HttpResult result, String userid) throws Exception{
        MethodResult methodResult = new MethodResult(EventType.GROUP_UNFORBID_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            methodResult.setResultObj(userid);
            methodResult.setResultType(EventType.GROUP_UNFORBID_SUCCESS);
        }
        return methodResult;
    }

    private MethodResult getForbidResult(HttpResult result, String userid) throws Exception{
        MethodResult methodResult = new MethodResult(EventType.GROUP_FORBID_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            methodResult.setResultObj(userid);
            methodResult.setResultType(EventType.GROUP_FORBID_SUCCESS);
        }
        return methodResult;
    }

    private String createUnForbidUrl(String classid, String userid){
        String cmd = String.format(ServerUrls.GROUP_UNFORBID, Utils.getSchoolID(), classid, userid);
        return cmd;
    }

    private String createForbidUrl(String classid){
        String cmd = String.format(ServerUrls.GROUP_FORBID, Utils.getSchoolID(), classid);
        return cmd;
    }

    private static class Forbid{
        private String id     = "";
        private int    minute = 99999;

        public String getId(){
            return id;
        }

        public void setId(String id){
            this.id = id;
        }

        public int getMinute(){
            return minute;
        }

        public void setMinute(int minute){
            this.minute = minute;
        }

    }
}
