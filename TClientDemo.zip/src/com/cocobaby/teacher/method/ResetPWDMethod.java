package com.cocobaby.teacher.method;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.MyErrorCode;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ResetPWDMethod {
	private ResetPWDMethod() {
	}

	public static ResetPWDMethod getResetPwdMethod() {
		return new ResetPWDMethod();
	}

	// 在忘记密码的情况下，通过短信收到的校验码进行密码重置
	public MethodResult resetPwd(String authcode, String newPwd, String account)
			throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createResetPWDCommand(authcode, newPwd, account);
		result = HttpClientHelper
				.executePost(ServerUrls.RESET_PWD_URL, command);
		bret = handleResetPwdResult(result);
		return bret;
	}

	private MethodResult handleResetPwdResult(HttpResult result)
			throws JSONException {
		MethodResult bret = new MethodResult(EventType.RESET_PWD_FAILED);
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONObject jsonObject = result.getJsonObject();
			Log.d("DDD changePwd", "str : " + jsonObject.toString());

			int errorcode = jsonObject.getInt(JSONConstant.ERROR_CODE);

			// 登录成功，保存token
			if (errorcode == 0) {
				String token = jsonObject.getString(JSONConstant.ACCESS_TOKEN);
				Utils.saveProp(JSONConstant.ACCESS_TOKEN, token);
				bret.setResultType(EventType.RESET_PWD_SUCCESS);
			} else if (errorcode == MyErrorCode.INVALID_AUTHCODE) {
				bret.setResultType(EventType.AUTH_CODE_IS_INVALID);
			} else {
				bret.setResultType(EventType.RESET_PWD_FAILED);
			}
		}

		return bret;
	}

	private String createResetPWDCommand(String authcode, String newPwd,
			String account) throws JSONException {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(JSONConstant.ACCOUNT_NAME, account);
		jsonObject.put(JSONConstant.AUTH_CODE, authcode);
		jsonObject.put(JSONConstant.NEW_PASSWORD, newPwd);
		return jsonObject.toString();
	}
}
