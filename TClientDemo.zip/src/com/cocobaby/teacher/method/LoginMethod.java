package com.cocobaby.teacher.method;

import org.apache.http.HttpStatus;
import org.json.JSONException;
import org.json.JSONObject;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.IMUtils;
import com.cocobaby.teacher.utils.Utils;

import android.util.Log;

public class LoginMethod {
	private LoginMethod() {
	}

	public static LoginMethod getLoginMethod() {
		return new LoginMethod();
	}

	public MethodResult login(String pwd, String account) throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createCommand(pwd, account);
		result = HttpClientHelper.executePost(ServerUrls.LOGIN_URL, command);
		bret = handle(result, pwd);
		return bret;
	}

	private MethodResult handle(HttpResult result, String pwd) throws JSONException {
		MethodResult methodResult = new MethodResult(EventType.PWD_INCORRECT);
		if (result.getResCode() == HttpStatus.SC_OK) {
			Log.d("DDD LOGIN", " str : " + result.getContent());
			methodResult.setResultType(EventType.LOGIN_SUCCESS);

			JSONObject jsonObject = result.getJsonObject();

			String imToken = jsonObject.getJSONObject("im_token").getString("token");
			IMUtils.saveToken(imToken);

			Utils.saveProp(JSONConstant.SCHOOL_ID, jsonObject.getString(JSONConstant.SCHOOL_ID));
			TeacherInfo info = TeacherInfo.parseInfoFromJson(jsonObject);
			Utils.saveProp(JSONConstant.SELF_ID, info.getServer_id());
			Utils.saveProp(JSONConstant.SELF_PWD, pwd);
			// info.setPwd(pwd);
			DataMgr.getInstance().addTeacher(info);

			Log.d("DDD LOGIN", DataMgr.getInstance().getTeacherInfo().toString());
		}

		return methodResult;
	}

	private String createCommand(String pwd, String account) {
		JSONObject jsonObject = new JSONObject();
		try {
			jsonObject.put(JSONConstant.ACCOUNT_NAME, account);
			jsonObject.put(JSONConstant.PASSWORD, pwd);
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return jsonObject.toString();
	}
}
