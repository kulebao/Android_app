package com.cocobaby.teacher.method;

import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class TeacherMethod{
    private TeacherMethod(){}

    public static TeacherMethod getMethod(){
        return new TeacherMethod();
    }

    public MethodResult postInfo(TeacherInfo info) throws Exception{
        MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String command = createCommand();
        String content = createContent(info);
        Log.d("DDD TeacherMethod", " content : " + content);
        result = HttpClientHelper.executePost(command, content);
        bret = handle(result, info);
        return bret;
    }

    private String createContent(TeacherInfo info) throws JSONException{
        return info.toJsonObj().toString();
    }

    private MethodResult handle(HttpResult result, TeacherInfo info) throws JSONException{
        MethodResult methodResult = new MethodResult(EventType.POST_TEACHER_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            Log.d("DDD TeacherMethod", " str : " + result.getContent());
            DataMgr.getInstance().addTeacher(info);
            methodResult.setResultType(EventType.POST_TEACHER_SUCCESS);
        }

        return methodResult;
    }

    private String createCommand(){
        return String.format(ServerUrls.TEATHER_URL, Utils.getProp(JSONConstant.SCHOOL_ID), DataMgr.getInstance()
                .getTeacherInfo().getPhone());
    }

    public MethodResult getTeacherInfo(String phones) throws Exception{
        MethodResult bret = new MethodResult(EventType.GET_TEACHER_FAIL);
        HttpResult result = new HttpResult();
        String url = createGetTeacherInfoUrl(phones);
        Log.e("DDDDD ", "createGetChildrenInfoUrl cmd:" + url);
        result = HttpClientHelper.executeGet(url);
        bret = handleGetTeacherResult(result);
        return bret;
    }

    private String createGetTeacherInfoUrl(String phones){
        String url = String.format(ServerUrls.GET_TEACHER_INFO, Utils.getSchoolID(), phones);
        return url;
    }

    private MethodResult handleGetTeacherResult(HttpResult result){
        MethodResult bret = new MethodResult(EventType.GET_TEACHER_FAIL);
        if(result.getResCode() == HttpStatus.SC_OK){
            try{
                JSONArray array = result.getJSONArray();
                List<TeacherInfo> fromnetTeachers = checkUpdate(array);
                bret.setResultObj(fromnetTeachers);
                bret.setResultType(EventType.GET_TEACHER_SUCCESS);
                Log.d("DDD handleGetTeacherResult", "str : " + array.toString());
            } catch(JSONException e){
                e.printStackTrace();
            }
        }
        return bret;
    }

    private List<TeacherInfo> checkUpdate(JSONArray array) throws JSONException{
        DataMgr instance = DataMgr.getInstance();
        List<TeacherInfo> fromnetTeachers = TeacherInfo.toTeacherList(array);
        handleIncomingTeacher(instance, fromnetTeachers);
        return fromnetTeachers;
    }

    private void handleIncomingTeacher(DataMgr instance, List<TeacherInfo> fromnetTeachers){
        for(TeacherInfo teacher : fromnetTeachers){
            instance.handleIncomingTeacher(teacher);
        }
    }

    public MethodResult getTeacherListByClassID(String classid) throws Exception{
        MethodResult methodResult = new MethodResult(EventType.NET_WORK_INVALID);
        HttpResult result = new HttpResult();
        String url = createGetTeacherListUrl(classid);
        Log.e("DDDDD ", "getTeacherListByClassID cmd:" + url);
        result = HttpClientHelper.executeGet(url);
        Log.e("DDDDD ", "getTeacherListByClassID result:" + result.getContent());
        methodResult = handleGetTeacherResult(result);
        return methodResult;
    }

    private String createGetTeacherListUrl(String classid){
        String url = String.format(ServerUrls.GET_TEACHER_LIST, Utils.getSchoolID(), classid);
        return url;
    }

}
