package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class ExpMethod {

	private static final String MOST = "most";
	private static final String FROM = "from";
	private static final String TO = "to";

	private ExpMethod() {
	}

	public static ExpMethod getMethod() {
		return new ExpMethod();
	}

	public MethodResult getExp(int most, long from, long to, int getType) throws Exception {
		MethodResult methodResult = new MethodResult(EventType.GET_EXP_INFO_FAIL);
		HttpResult result = new HttpResult();
		String url = createGetExpUrl(most, from, to);
		Log.e("DJC", "getExp cmd:" + url);
		result = HttpClientHelper.executeGet(url);
		Log.e("DJC", "getExp result:" + result.getContent());
		if (result.getResCode() == HttpStatus.SC_OK) {
			methodResult = handleGetExp(result);
		}
		return methodResult;
	}

	private MethodResult handleGetExp(HttpResult result) throws JSONException {
		List<ExpInfo> expInfos = new ArrayList<ExpInfo>();
		MethodResult methodResult = new MethodResult(EventType.GET_EXP_INFO_SUCCESS);
		JSONArray jsonArray = result.getJSONArray();

		for (int i = 0; i < jsonArray.length(); i++) {
			expInfos.add(ExpInfo.parseFromJson(jsonArray.getJSONObject(i)));
		}
		methodResult.setResultObj(expInfos);
		return methodResult;
	}

	private String createGetExpUrl(int most, long from, long to) {
		if (most == 0) {
			most = ConstantValue.GET_EXP_MAX_COUNT;
		}
		String cmd = String.format(ServerUrls.GET_EXP, Utils.getSchoolID(), DataMgr.getInstance().getTeacherInfo()
				.getServer_id());

		cmd += MOST + "=" + most;
		if (from != 0) {
			cmd += "&" + FROM + "=" + from;
		}

		if (to != 0) {
			cmd += "&" + TO + "=" + to;
		}

		return cmd;
	}

	public MethodResult sendExp(String content, String childids, Map<String, String> map) throws Exception {
		MethodResult methodResult = new MethodResult(EventType.POST_EXP_SUCCESS);
		HttpResult result = new HttpResult();
		String url = createSendExpUrl(childids);
		Log.e("DJC", "sendExp cmd:" + url + " content=" + content);
		result = HttpClientHelper.executePost(url, content);
		Log.e("DJC", "sendExp result = " + result.getContent());
		if (result.getResCode() != HttpStatus.SC_OK) {
			methodResult.setResultType(EventType.POST_EXP_FAIL);
			return methodResult;
		}

		// 本地发送的成长记录，把多媒体资源的本地地址和服务器地址保存起来，避免去服务器下载资源
		if (!map.isEmpty()) {
			List<NativeMediumInfo> list = new ArrayList<NativeMediumInfo>();

			Set<Entry<String, String>> entrySet = map.entrySet();
			Iterator<Entry<String, String>> iterator = entrySet.iterator();
			while (iterator.hasNext()) {
				Entry<String, String> next = iterator.next();
				NativeMediumInfo info = new NativeMediumInfo();
				info.setKey(next.getKey());
				info.setLocal_url(next.getValue());
				list.add(info);
			}

			if (!list.isEmpty()) {
				Log.d("", "AAA addNativeMediumInfoList  list=" + list);
				DataMgr.getInstance().addNativeMediumInfoList(list);
			}
		}

		return methodResult;
	}

	private String createSendExpUrl(String childids) {
		String url = String.format(ServerUrls.POST_EXP, Utils.getSchoolID());
		url += "child_id=" + childids;
		return url;
	}

	private List<ChatInfo> handleGetChatMethodResult(HttpResult result) throws JSONException {
		List<ChatInfo> list = new ArrayList<ChatInfo>();
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONArray array = result.getJSONArray();

			for (int i = 0; i < array.length(); i++) {
				JSONObject object = array.getJSONObject(i);
				ChatInfo info = ChatInfo.parseFromJson(object);
				list.add(info);
			}
		}

		return list;
	}

}
