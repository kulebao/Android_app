package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class EstimateMethod {
	private static final String MOST = "most";
	private static final String FROM = "from";
	private static final String TO = "to";

	private EstimateMethod() {
	}

	public static EstimateMethod getMethod() {
		return new EstimateMethod();
	}

	public MethodResult getInfo(int most, int from, int to, String childid) throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createGetEstimateCommand(most, from, to, childid);
		Log.d("DDD EstimateMethod", " command : " + command);
		result = HttpClientHelper.executeGet(command);
		bret = handleGet(result);
		return bret;
	}

	private MethodResult handleGet(HttpResult result) throws JSONException {
		MethodResult bret = new MethodResult(EventType.GET_ESTIMATE_FAIL);
		List<EstimateInfo> list = new ArrayList<EstimateInfo>();
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONArray array = result.getJSONArray();
			list = EstimateInfo.jsonArrayToList(array);
			DataMgr.getInstance().addEstimateRecordList(list);
			bret.setResultType(EventType.GET_ESTIMATE_SUCCESS);
		}

		return bret;
	}

	public MethodResult postInfo(String childid, EstimateInfo info) throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createPostCommand(info.getChild_id());
		String content = createPostContent(info);
		Log.d("DDD EstimateMethod", " content : " + content);
		result = HttpClientHelper.executePost(command, content);
		bret = handlePost(result);
		return bret;
	}

	private MethodResult handlePost(HttpResult result) throws JSONException {
		MethodResult bret = new MethodResult(EventType.POST_ESTIMATE_FAIL);
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONObject jsonObject = result.getJsonObject();
			EstimateInfo info = EstimateInfo.parse(jsonObject);
			DataMgr.getInstance().addEstimate(info);
			bret.setResultType(EventType.POST_ESTIMATE_SUCCESS);
		}
		return bret;
	}

	private String createPostContent(EstimateInfo info) throws JSONException {
		return info.toJsonObj().toString();
	}

	private String createPostCommand(String childid) {
		return String.format(ServerUrls.POST_ESTIMATE, Utils.getSchoolID(), childid);
	}

	public MethodResult multiPostInfo(List<String> childIDs, EstimateInfo info) throws Exception {
		MethodResult bret = new MethodResult(EventType.NET_WORK_INVALID);
		HttpResult result = new HttpResult();
		String command = createMultiPostCommand();
		String content = createMultiPostContent(childIDs, info);
		Log.d("DDD EstimateMethod", " content : " + content);
		result = HttpClientHelper.executePost(command, content);
		bret = handleMultiPost(result);
		return bret;
	}

	private String createMultiPostContent(List<String> childIDs, EstimateInfo info) throws JSONException {
		return info.toJsonArray(childIDs).toString();
	}

	private MethodResult handleMultiPost(HttpResult result) throws JSONException {
		MethodResult methodResult = new MethodResult(EventType.POST_ESTIMATE_FAIL);
		if (result.getResCode() == HttpStatus.SC_OK) {
			Log.d("DDD EstimateMethod", " str : " + result.getContent());
			int error_code = result.getJsonObject().getInt(JSONConstant.ERROR_CODE);
			if (error_code == 0) {
				methodResult.setResultType(EventType.POST_ESTIMATE_SUCCESS);
			}
		}

		return methodResult;
	}

	private String createMultiPostCommand() {
		return String.format(ServerUrls.MULTI_POST_ESTIMATE, Utils.getProp(JSONConstant.SCHOOL_ID));
	}

	private String createGetEstimateCommand(int most, long from, long to, String childid) {
		if (most == 0) {
			most = 1;
		}
		String cmd = String.format(ServerUrls.GET_ESTIMATE, Utils.getSchoolID(), childid);

		cmd += MOST + "=" + most;
		if (from != 0) {
			cmd += "&" + FROM + "=" + from;
		}

		if (to != 0) {
			cmd += "&" + TO + "=" + to;
		}
		Log.d("DDD", "createCommand cmd=" + cmd);
		return cmd;
	}

}
