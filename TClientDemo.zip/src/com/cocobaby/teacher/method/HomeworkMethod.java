package com.cocobaby.teacher.method;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;
import android.util.Log;

import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.constant.ServerUrls;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.Homework;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.httpclientmgr.HttpClientHelper;
import com.cocobaby.teacher.httpclientmgr.HttpResult;
import com.cocobaby.teacher.utils.Utils;

public class HomeworkMethod {

	private static final String MOST = "most";
	private static final String FROM = "from";
	private static final String TO = "to";

	private HomeworkMethod() {
	}

	public static HomeworkMethod getMethod() {
		return new HomeworkMethod();
	}

	public MethodResult getGetHomework(int most, long from, long to)
			throws Exception {
		HttpResult result = new HttpResult();
		String command = createGetHomeworkCommand(most, from, to);
		Log.e("DDDDD ", "getGetHomework cmd:" + command);
		result = HttpClientHelper.executeGet(command);
		MethodResult bret = handleGetHomeworkResult(result);
		return bret;
	}

	private MethodResult handleGetHomeworkResult(HttpResult result)
			throws JSONException {
		MethodResult bret = new MethodResult(EventType.GET_HOMEWORK_FAIL);
		List<Homework> list = new ArrayList<Homework>();
		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONArray array = result.getJSONArray();

			for (int i = 0; i < array.length(); i++) {
				JSONObject object = array.getJSONObject(i);
				Homework info = parseHomework(object);
				list.add(info);
			}

			bret.setResultType(EventType.GET_HOMEWORK_SUCCESS);
			bret.setResultObj(list);
		}

		return bret;
	}

	private Homework parseHomework(JSONObject object) throws JSONException {
		Homework info = new Homework();
		String title = object.getString("title");
		long timestamp = object.getLong(JSONConstant.TIME_STAMP);
		String body = object.getString("content");
		int serverID = object.getInt("id");
		String publisher = object.getString("publisher");
		String icon_url = object.getString("icon_url");
		int class_id = object.getInt("class_id");

		info.setContent(body);
		info.setServer_id(serverID);
		info.setPublisher(publisher);
		info.setTitle(title);
		info.setTimestamp(timestamp);
		info.setIcon_url(icon_url);
		info.setClass_id(class_id);
		return info;
	}

	private String createGetHomeworkCommand(int most, long from, long to) {
		if (most == 0) {
			most = ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT;
		}
		String cmd = String
				.format(ServerUrls.GET_HOMEWORK, Utils.getSchoolID());

		cmd += MOST + "=" + most;
		if (from != 0) {
			cmd += "&" + FROM + "=" + from;
		}

		if (to != 0) {
			cmd += "&" + TO + "=" + to;
		}

		cmd += "&" + "class_id=" + MethodHelper.getAllFormatedClassid();

		Log.d("DDD", "createGetHomeworkCommand cmd=" + cmd);
		return cmd;
	}

	public MethodResult sendHomework(String title, String content, int classid,
			String image) throws Exception {
		String url = createSendHomeworkUrl();
		String command = createSendHomeworkCommand(title, content, classid,
				image);
		Log.d("DDD", "sendHomework cmd=" + command);
		Log.d("DDD", "sendHomework url=" + url);
		HttpResult result = HttpClientHelper.executePost(url, command);
		MethodResult bret = handleSendNewsResult(result);
		return bret;
	}

	private MethodResult handleSendNewsResult(HttpResult result)
			throws JSONException {
		MethodResult bret = new MethodResult(EventType.SEND_HOMEWORK_FAIL);

		if (result.getResCode() == HttpStatus.SC_OK) {
			JSONObject object = result.getJsonObject();
			Homework info = parseHomework(object);
			bret.setResultType(EventType.SEND_HOMEWORK_SUCCESS);
			bret.setResultObj(info);
		}
		return bret;
	}

	private String createSendHomeworkCommand(String title, String content,
			int classid, String image) throws JSONException {
		JSONObject object = new JSONObject();

		object.put(JSONConstant.SCHOOL_ID, Utils.getSchoolID());
		object.put(Homework.TITLE, title);
		object.put(Homework.CONTENT, content);
		object.put(Homework.CLASS_ID, classid);
		object.put(Homework.PUBLISHER, DataMgr.getInstance().getTeacherInfo()
				.getName());
		object.put("publisher_id", DataMgr.getInstance().getTeacherInfo()
				.getServer_id());

		if (!TextUtils.isEmpty(image)) {
			object.put("icon_url", image);
		}
		return object.toString();
	}

	private String createSendHomeworkUrl() {
		return String.format(ServerUrls.SEND_HOMEWORK_URL, Utils.getSchoolID());
	}

}
