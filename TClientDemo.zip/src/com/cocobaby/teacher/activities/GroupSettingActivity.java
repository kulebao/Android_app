package com.cocobaby.teacher.activities;

import io.rong.imlib.RongIMClient.ErrorCode;
import io.rong.imlib.RongIMClient.ResultCallback;
import io.rong.imlib.model.Conversation.ConversationType;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.customview.CheckSwitchButton;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.SchoolInfo;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.im.IMHelper;
import com.cocobaby.teacher.taskmgr.UpdateSchoolInfoJob;
import com.cocobaby.teacher.utils.IMUtils;
import com.cocobaby.teacher.utils.Utils;

public class GroupSettingActivity extends UmengStatisticsActivity{
    private Handler              myhandler;
    private String            classid;
    private String            groupID;
    private CheckSwitchButton disturbButton;
    private String            groupName;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_member);
        initData();
        initUI();
        initHander();
        runUpdateSchoolInfoJob();
    }

    private void initData(){
        groupName = getIntent().getStringExtra(ConstantValue.IM_GROUP_NAME);
        groupID = getIntent().getStringExtra(ConstantValue.IM_GROUP_ID);
        classid = getIntent().getStringExtra(ConstantValue.CLASS_ID);
    }
    
    private void initHander(){
        myhandler = new MyHandler(this, null){
            @Override
            public void handleMessage(Message msg){
                if(GroupSettingActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.UPDATE_SCHOOL_INFO:
                        setSchoolName();
                        break;
                    default:
                        break;
                }
            }
        };
    }
    
    private void runUpdateSchoolInfoJob(){
        SchoolInfo schoolInfo = DataMgr.getInstance().getSchoolInfo();
        if(schoolInfo == null){
            UpdateSchoolInfoJob updateSchoolInfoJob = new UpdateSchoolInfoJob(myhandler);
            updateSchoolInfoJob.execute();
        }
    }

    private void initUI(){
        TextView class_name = (TextView)findViewById(R.id.class_name);
        class_name.setText(groupName);

        setSchoolName();

        disturbButton = (CheckSwitchButton)findViewById(R.id.checkSwithcButton);

        disturbButton.setChecked(IMUtils.isMessageDisturbEnable(groupID));
        disturbButton.setOnCheckedChangeListener(new OnCheckedChangeListener(){

            @Override
            public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked){
                Log.d("", "SetConversationNotificationFragment  isChecked = " + isChecked);
                IMUtils.setMessageDisturbEnable(groupID, isChecked);
            }
        });
    }

    private void setSchoolName(){
        TextView schoolname = (TextView)findViewById(R.id.schoolname);
        
        SchoolInfo schoolInfo = DataMgr.getInstance().getSchoolInfo();
        if(schoolInfo == null){
            schoolname.setVisibility(View.GONE);
        }else{
            schoolname.setVisibility(View.VISIBLE);
            schoolname.setText(schoolInfo.getSchool_name());
        }
    }

    public void groupMember(View view){
        Intent intent = new Intent(GroupSettingActivity.this, ContactListActivity.class);
        intent.putExtra(ConstantValue.CLASS_ID, classid);
        startActivity(intent);
    }

    public void forbid(View view){
        Intent intent = new Intent(GroupSettingActivity.this, ForbidSettingActivity.class);
        intent.putExtra(ConstantValue.CLASS_ID, classid);
        startActivity(intent);
    }

    public void clearChatRecord(View view){
        DlgMgr.showTwoBtnResDlg(R.string.clear_group_chat, this, new OnClickListener(){
            @Override
            public void onClick(DialogInterface dialog, int which){
                clearImpl();
            }
        });
    }

    private void clearImpl(){
        IMHelper.clearChatRecord(ConversationType.GROUP, groupID, new ResultCallback<Boolean>(){
            @Override
            public void onSuccess(Boolean arg0){
                Utils.makeToast(GroupSettingActivity.this, R.string.clear_success);
            }

            @Override
            public void onError(ErrorCode arg0){
                Utils.makeToast(GroupSettingActivity.this, "清除失败 error =" + arg0);
            }
        });
    }
}
