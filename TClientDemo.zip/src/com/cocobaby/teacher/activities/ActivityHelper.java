package com.cocobaby.teacher.activities;

import android.app.Activity;
import android.view.View;
import android.widget.TextView;

import com.cocobaby.teacher.R;

public class ActivityHelper{

    public static void setTopbarTitle(Activity activity, int resid){
        TextView title = (TextView)activity.findViewById(R.id.topbarTitle);
        title.setVisibility(View.VISIBLE);
        title.setText(resid);
    }

    public static void setTopbarTitle(Activity activity, String content){
        TextView title = (TextView)activity.findViewById(R.id.topbarTitle);
        title.setVisibility(View.VISIBLE);
        title.setText(content);
    }

}
