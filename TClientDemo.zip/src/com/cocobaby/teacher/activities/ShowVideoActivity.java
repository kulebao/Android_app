package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.Action;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.utils.Utils;

public class ShowVideoActivity extends UmengStatisticsActivity{

    private static final int PAUSE               = 0;
    private static final int PLAY                = 1;
    private Bitmap           bitmap;
    private String           videoUrl;
    private VideoView        videoView;
    private ImageView        play;
    private ImageView        pause;
    private ImageView        nailview;

    private int              mPositionWhenPaused = -1;

    private MediaController  mMediaController;
    private String           content;
    private long             size;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_video);

        // Create media controller
        mMediaController = new MediaController(this);

        initData();
        initUI();

        Log.d("", "ShowVideoActivity onCreate");
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig){
        super.onConfigurationChanged(newConfig);

        // int ori = newConfig.orientation; // 获取屏幕方向
        //
        // if (ori == Configuration.ORIENTATION_LANDSCAPE) {
        // // 横屏
        // setContentView(R.layout.show_video_land);
        // } else if (ori == Configuration.ORIENTATION_PORTRAIT) {
        // // 竖屏
        // setContentView(R.layout.show_video);
        // }
        Log.d("", "ShowVideoActivity onConfigurationChanged");
    }

    private void initUI(){
        nailview = (ImageView)findViewById(R.id.nailview);
        play = (ImageView)findViewById(R.id.play);
        pause = (ImageView)findViewById(R.id.pause);
        videoView = (VideoView)findViewById(R.id.videoView);
        bitmap = Utils.createVideoThumbnail(videoUrl);
        nailview.setImageBitmap(bitmap);

        videoView.setMediaController(mMediaController);

        videoView.setVideoPath(videoUrl);

        videoView.setOnCompletionListener(new OnCompletionListener(){
            @Override
            public void onCompletion(MediaPlayer mp){
                pauseVideo();
            }
        });

        play.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                playVideo();
            }

        });

        pause.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                pauseVideo();
            }

        });
    }

    private void pauseVideo(){
        videoView.pause();

        play.setVisibility(View.VISIBLE);
        pause.setVisibility(View.GONE);
    }

    private void playVideo(){
        nailview.setVisibility(View.GONE);
        videoView.setVisibility(View.VISIBLE);

        videoView.start();

        play.setVisibility(View.GONE);
        pause.setVisibility(View.GONE);
    }

    private void initData(){
        videoUrl = getIntent().getStringExtra(Action.VIDEO_URL);
        size = getIntent().getLongExtra(Action.VIDEO_SIZE, 0);
        content = getIntent().getStringExtra(Action.EXP_TEXT);
    }

    public void onPause(){
        // Stop video when the activity is pause.
        mPositionWhenPaused = videoView.getCurrentPosition();
        videoView.stopPlayback();
        Log.d("", "OnStop: mPositionWhenPaused = " + mPositionWhenPaused);
        Log.d("", "OnStop: getDuration  = " + videoView.getDuration());

        super.onPause();
    }

    public void onResume(){
        // Resume video player
        if(mPositionWhenPaused >= 0){
            videoView.seekTo(mPositionWhenPaused);
            mPositionWhenPaused = -1;
        }

        super.onResume();
    }

    @Override
    protected void onDestroy(){
        if(bitmap != null){
            bitmap.recycle();
        }
        super.onDestroy();
    }

    public void cancel(View view){
        this.finish();
    }

    public void send(View view){
        videoView.stopPlayback();
        startToChooseExpReceiverActivity();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != Activity.RESULT_OK){
            return;
        }
        switch(requestCode){
            case Action.SEND_TO:
                finish();
                break;

            default:
                break;
        }
    }

    protected void startToChooseExpReceiverActivity(){
        Intent intent = new Intent();
        List<String> ids = new ArrayList<String>();
        ids.add(videoUrl);

        intent.putExtra(Action.ALL_MEDIUM, ids.toArray(new String[ids.size()]));

        intent.putExtra(Action.MEDIUM_TYPE, JSONConstant.VIDEO_TYPE);
        intent.putExtra(Action.EXP_TEXT, content);

        intent.setClass(this, ChooseExpReceiverActivity.class);
        startActivityForResult(intent, Action.SEND_TO);
    }
}
