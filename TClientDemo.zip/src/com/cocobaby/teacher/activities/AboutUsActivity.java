package com.cocobaby.teacher.activities;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

import com.cocobaby.teacher.utils.Utils;
import com.cocobaby.teacher.R;

public class AboutUsActivity extends UmengStatisticsActivity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about_us);
		setVersion();
		initBtn();
		ActivityHelper.setTopbarTitle(this, R.string.aboutus);
	}

	private void initBtn() {
		final TextView support_phone_num1 = (TextView) findViewById(R.id.support_phone_num1);
		support_phone_num1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Utils.startToCall(AboutUsActivity.this, support_phone_num1.getText().toString());
			}
		});

		final TextView support_phone_num2 = (TextView) findViewById(R.id.support_phone_num2);
		support_phone_num2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Utils.startToCall(AboutUsActivity.this, support_phone_num2.getText().toString());
			}
		});

	}

	private void setVersion() {
		TextView versionView = (TextView) findViewById(R.id.version);
		versionView.setText(getVersionName());
	}

	private String getVersionName() {
		// 获取packagemanager的实例
		PackageManager packageManager = getPackageManager();
		// getPackageName()是你当前类的包名，0代表是获取版本信息
		String version = "";
		try {
			PackageInfo packInfo = packageManager.getPackageInfo(getPackageName(), 0);
			version = packInfo.versionName;
		} catch (NameNotFoundException e) {
			e.printStackTrace();
		}
		return version;
	}
}
