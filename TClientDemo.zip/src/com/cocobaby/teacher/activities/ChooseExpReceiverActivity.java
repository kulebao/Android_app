package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.MultiSelectedAdapter;
import com.cocobaby.teacher.constant.Action;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.listdata.MultiSelectedInfo;
import com.cocobaby.teacher.listdata.SimpleChildInfo;
import com.cocobaby.teacher.taskmgr.SendExpJob;
import com.cocobaby.teacher.utils.Utils;

public class ChooseExpReceiverActivity extends UmengStatisticsActivity {
	private Handler myhandler;
	private ProgressDialog dialog;
	private List<MultiSelectedInfo> list = new ArrayList<MultiSelectedInfo>();
	private MultiSelectedAdapter adapter;
	private String content;
	private List<String> urlList = new ArrayList<String>();
	private String medium_type;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.multi_selected_list);
		initData();
		initUI();
		initHander();
	}

	private void initHander() {
		myhandler = new MyHandler(this, dialog) {
			@Override
			public void handleMessage(Message msg) {
				if (ChooseExpReceiverActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.POST_EXP_SUCCESS:
					Utils.makeToast(ChooseExpReceiverActivity.this, R.string.send_exp_sucess);
					setResult(RESULT_OK);
					finish();
					break;
				case EventType.POST_EXP_FAIL:
					Utils.makeToast(ChooseExpReceiverActivity.this, R.string.send_exp_fail);
					break;
				case EventType.UPLOAD_ICON_SUCCESS:
					dialog.setProgress(msg.arg1);
					break;
				default:
					break;
				}
			}
		};
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.uploading_data));
	}

	private void initUI() {
		initDialog();
		initHeader();
		initList();
	}

	private void initHeader() {
		TextView send_to = (TextView) findViewById(R.id.rightBtn);
		send_to.setText(R.string.send);
		send_to.setVisibility(View.VISIBLE);
		send_to.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				handleSendBtnClick();
			}
		});

		TextView cancel = (TextView) findViewById(R.id.leftBtn);
		cancel.setText(R.string.cancel);
		cancel.setVisibility(View.VISIBLE);
		cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				ChooseExpReceiverActivity.this.finish();
			}
		});

	}

	protected void handleSendBtnClick() {
		// 一个人都没选不能发送
		if (getSelectedChildIDs().isEmpty()) {
			Utils.makeToast(this, R.string.no_receiver_choosed);
			return;
		}

		runSendExpJob();
	}

	private void runSendExpJob() {
		if (!urlList.isEmpty()) {
			dialog.setMax(urlList.size());
			dialog.setProgress(1);
			dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
		} else {
			dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
		}
		dialog.show();

		SendExpJob expJob = new SendExpJob(myhandler, content, Utils.listToString(getSelectedChildIDs(), ","), urlList,
				medium_type);
		expJob.execute();
	}

	private List<String> getSelectedChildIDs() {
		List<String> ids = new ArrayList<String>();
		List<MultiSelectedInfo> dataList = adapter.getDataList();

		for (MultiSelectedInfo multiSelectedInfo : dataList) {
			List<SimpleChildInfo> childList = multiSelectedInfo.getChildList();
			for (SimpleChildInfo simpleChildInfo : childList) {
				if (simpleChildInfo.isbSelected()) {
					ids.add(simpleChildInfo.getChild_id());
				}
			}
		}
		return ids;
	}

	private void initData() {
		getExpContent();

		List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
		for (ClassInfo mClassInfo : allClasses) {
			MultiSelectedInfo multiSelectedInfo = new MultiSelectedInfo();
			multiSelectedInfo.setInfo(mClassInfo);
			List<ChildInfo> children = DataMgr.getInstance().getChildByClass(mClassInfo.getClassID());
			List<SimpleChildInfo> simpleChildList = SimpleChildInfo.childInfoToSimpleChildInfo(children);
			multiSelectedInfo.setChildList(simpleChildList);
			list.add(multiSelectedInfo);
		}
	}

	private void getExpContent() {
		String[] stringArrayExtra = getIntent().getStringArrayExtra(Action.ALL_MEDIUM);

		if (stringArrayExtra != null) {
			Collections.addAll(urlList, stringArrayExtra);
		}

		content = getIntent().getStringExtra(Action.EXP_TEXT);
		if (content == null) {
			content = "";
		}
		
		medium_type = getIntent().getStringExtra(Action.MEDIUM_TYPE);
	}

	private void initList() {
		ExpandableListView exList = (ExpandableListView) findViewById(R.id.selectedList);
		exList.setDescendantFocusability(ExpandableListView.FOCUS_AFTER_DESCENDANTS);
		adapter = new MultiSelectedAdapter(this, list);

		// 分组展开
		exList.setOnGroupExpandListener(new OnGroupExpandListener() {
			public void onGroupExpand(int groupPosition) {
			}
		});
		// 分组关闭
		exList.setOnGroupCollapseListener(new OnGroupCollapseListener() {
			public void onGroupCollapse(int groupPosition) {
			}
		});
		// 子项单击
		exList.setOnChildClickListener(new OnChildClickListener() {

			public boolean onChildClick(ExpandableListView expandableListView, View view, int groupPosition,
					int childPosition, long arg4) {
				adapter.changeChildSelection(view, groupPosition, childPosition);
				return false;
			}
		});
		exList.setAdapter(adapter);
	}

}
