package com.cocobaby.teacher.activities;

import java.io.File;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.customview.PointerPopupWindow;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.CheckNewJob;
import com.cocobaby.teacher.taskmgr.PostTeacherJob;
import com.cocobaby.teacher.utils.DataUtils;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class SelfInfoActivity extends UmengStatisticsActivity {
	private ImageView headView;
	private TextView usernameView;
	// 下列序号与资源文件arrays.xml中的baby_setting_items配置保持一致
	private static final int SET_NICKNAME = 0;
	private static final int SET_ICON_BY_TAKE_PHOTO = 1;
	private static final int SET_ICON_FROM_ICONLIB = 2;
	private Handler myhandler;
	private ProgressDialog dialog;
	private static final int IMAGE_REQUEST_CODE = 0;
	private static final int CAMERA_REQUEST_CODE = 1;
	private static final int RESIZE_REQUEST_CODE = 2;
	private static final String IMAGE_FILE_NAME = "header.jpg";

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.selfinfo);
		initDialog();
		initHander();
		initUI();
	}

	private void initUI() {
		initHeader();
		initSelfInfo();
		initBtn();
	}

	private void initHeader() {
		TextView cancel = (TextView) findViewById(R.id.leftBtn);
		cancel.setText(R.string.setting);
		cancel.setVisibility(View.VISIBLE);
		cancel.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
	}

	private void initHander() {
		myhandler = new MyHandler(this, dialog) {
			@Override
			public void handleMessage(Message msg) {
				if (SelfInfoActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.POST_TEACHER_SUCCESS:
					if (msg.obj != null) {
						handleUploadHeadIconSuccess((Bitmap) msg.obj);
					} else {
						// usernameView.setText(DataMgr.getInstance().getTeacherInfo().getName());
						usernameView.setText(String.format(Utils.getResString(R.string.username), DataMgr.getInstance()
								.getTeacherInfo().getName()));
					}
					Utils.makeToast(SelfInfoActivity.this, R.string.upload_teacher_data_success);
					break;

				case EventType.POST_TEACHER_FAIL:
					Utils.makeToast(SelfInfoActivity.this, R.string.upload_teacher_data_fail);
					break;
				case EventType.HAS_NO_NEW_VERSION:
					Utils.makeToast(SelfInfoActivity.this, R.string.no_new_version);
					break;
				case EventType.HAS_NEW_VERSION:
					Utils.goNextActivity(SelfInfoActivity.this, UpdateActivity.class, false);
					break;
				default:
					break;
				}
			}

		};
	}

	private void handleUploadHeadIconSuccess(Bitmap bitmap) {
		// 上传头像
		Utils.setImg(headView, bitmap);
		TeacherInfo teacherInfo = DataMgr.getInstance().getTeacherInfo();
		try {
			Utils.saveBitmapToSDCard(bitmap, teacherInfo.getLocalHeadIconPath());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void initSelfInfo() {
		TeacherInfo teacherInfo = DataMgr.getInstance().getTeacherInfo();
		String headUrl = teacherInfo.getLocalHeadIconPath();

		initHead(headUrl);

		String login_name = teacherInfo.getLogin_name();
		TextView loginnameView = (TextView) findViewById(R.id.loginname);
		loginnameView.setText(String.format(Utils.getResString(R.string.loginname), login_name));

		String username = teacherInfo.getName();
		usernameView = (TextView) findViewById(R.id.username);
		usernameView.setText(String.format(Utils.getResString(R.string.username), username));
	}

	private void initHead(String headUrl) {
		headView = (ImageView) findViewById(R.id.head);
		Bitmap loacalBitmap = Utils.getLoacalBitmap(headUrl, ImageDownloader.getMaxPixWithDensity(
				ConstantValue.HEAD_ICON_BIG_WIDTH, ConstantValue.HEAD_ICON_BIG_HEIGHT));
		if (loacalBitmap != null) {
			Utils.setImg(headView, loacalBitmap);
		}

		headView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if (!Utils.isNetworkConnected(SelfInfoActivity.this)) {
					Utils.makeToast(SelfInfoActivity.this, R.string.net_error);
					Log.d("DDD", "DDD R.string.net_error");
					return;
				}
				showPopWindow();
			}

			private void showDlg() {
				DlgMgr.getListDialog(SelfInfoActivity.this, R.array.baby_setting_items,
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int which) {
								Log.d("initTitle ddd", "which =" + which);
								handleClick(which);
							}
						}).create().show();
			}
		});
	}

	private void showPopWindow() {
		// warning: you must specify the window width explicitly(do not use
		// WRAP_CONTENT or MATCH_PARENT)
		final PointerPopupWindow p = new PointerPopupWindow(this, getResources().getDimensionPixelSize(
				R.dimen.popup_width));
		View convertView = LayoutInflater.from(this).inflate(R.layout.teacher_option, null);
		View setNick = convertView.findViewById(R.id.setNick);
		View takepic = convertView.findViewById(R.id.takepic);
		View openGallery = convertView.findViewById(R.id.openGallery);

		setNick.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				p.dismiss();
				showTextDlg();
			}
		});

		takepic.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				p.dismiss();
				setHeadIconByTakePhoto();
			}
		});

		openGallery.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				p.dismiss();
				setHeadIconFromIconLib();
			}
		});

		p.setContentView(convertView);
		p.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
		p.setPointerImageRes(R.drawable.ic_popup_pointer);
		p.setAlignMode(PointerPopupWindow.AlignMode.CENTER_FIX);
		p.showAsPointer(headView);
	}

	private void handleClick(int which) {
		switch (which) {
		case SET_NICKNAME:
			showTextDlg();
			break;
		case SET_ICON_FROM_ICONLIB:
			setHeadIconFromIconLib();
			break;
		case SET_ICON_BY_TAKE_PHOTO:
			setHeadIconByTakePhoto();
			break;

		default:
			break;
		}
	}

	private void setHeadIconFromIconLib() {
		Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
		galleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
		galleryIntent.setType("image/*");
		startActivityForResult(galleryIntent, IMAGE_REQUEST_CODE);
	}

	private void setHeadIconByTakePhoto() {
		if (Utils.isSdcardExisting()) {
			Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
			cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, getImageUri());
			cameraIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
			startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
		} else {
			Toast.makeText(this, "请插入sd卡", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	// 处理从图库和拍照返回的照片
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK) {
			// Toast.makeText(this, "头像选择失败，错误码:" + resultCode,
			// Toast.LENGTH_SHORT).show();
			return;
		} else {
			switch (requestCode) {
			case IMAGE_REQUEST_CODE:
				resizeImage(data.getData());
				break;
			case CAMERA_REQUEST_CODE:
				if (Utils.isSdcardExisting()) {
					resizeImage(getImageUri());
				} else {
					Toast.makeText(SelfInfoActivity.this, "未找到存储卡，无法存储照片！", Toast.LENGTH_LONG).show();
				}
				break;

			case RESIZE_REQUEST_CODE:
				uploadIcon(data);
				break;
			}
		}

		super.onActivityResult(requestCode, resultCode, data);
	}

	private void uploadIcon(Intent data) {
		if (data != null) {
			Bitmap bitmap = getBitmap(data);
			if (bitmap != null) {
				runUploadTeacherIconJob(bitmap);
			}
		}
	}

	private void runUploadTeacherIconJob(Bitmap bitmap) {
		dialog.setMessage(getResources().getString(R.string.uploading_data));
		dialog.show();
		TeacherInfo info = DataMgr.getInstance().getTeacherInfo();
		PostTeacherJob job = new PostTeacherJob(myhandler, info);
		job.setBitmap(bitmap);
		job.execute();
	}

	private Bitmap getBitmap(Intent data) {
		Bundle extras = data.getExtras();
		Bitmap photo = null;
		if (extras != null) {
			photo = extras.getParcelable("data");
		}
		return photo;
	}

	private Uri getImageUri() {
		return Uri.fromFile(new File(Utils.getSDCardFileDir(Utils.APP_DIR_TMP), IMAGE_FILE_NAME));
	}

	// 此时是选中或拍好照片后，对照片进行裁剪
	public void resizeImage(Uri uri) {
		Intent intent = new Intent("com.android.camera.action.CROP");

		if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.KITKAT) {
			String url = DataUtils.getPath(uri);
			intent.setDataAndType(Uri.fromFile(new File(url)), "image/*");
		} else {
			intent.setDataAndType(uri, "image/*");
		}

		// intent.setDataAndType(uri, "image/*");
		intent.putExtra("crop", "true");
		intent.putExtra("aspectX", 1);
		intent.putExtra("aspectY", 1);
		intent.putExtra("outputX", 100);
		intent.putExtra("outputY", 100);
		intent.putExtra("return-data", true);
		startActivityForResult(intent, RESIZE_REQUEST_CODE);
	}

	// 修改昵称的对话框
	private void showTextDlg() {
		final View textEntryView = LayoutInflater.from(this).inflate(R.layout.nickname_text_entry, null);
		final EditText nicknameEdit = (EditText) textEntryView.findViewById(R.id.baby_nickname_edit);
		new AlertDialog.Builder(this).setTitle(R.string.changenickname).setView(textEntryView)
				.setPositiveButton(R.string.confirm, new android.content.DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						final String nick = nicknameEdit.getText().toString().replace(" ", "");

						if (TextUtils.isEmpty(nick)) {
							Toast.makeText(SelfInfoActivity.this, getResources().getString(R.string.invalidnickname),
									Toast.LENGTH_SHORT).show();
							return;
						}
						runPostTeacherJob(nick);
					}

				}).setNegativeButton(R.string.back, null).create().show();
	}

	private void runPostTeacherJob(final String nick) {
		dialog.setMessage(getResources().getString(R.string.uploading_data));
		dialog.show();
		TeacherInfo info = DataMgr.getInstance().getTeacherInfo();
		info.setName(nick);
		PostTeacherJob job = new PostTeacherJob(myhandler, info);
		job.execute();
	}

	private void initBtn() {
		Button exitLogin = (Button) findViewById(R.id.exitLogin);
		exitLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				DlgMgr.showTwoBtnResDlg(R.string.confirm_exit, SelfInfoActivity.this,
						new android.content.DialogInterface.OnClickListener() {
							@Override
							public void onClick(DialogInterface dialog, int which) {
								handleExitLogin();
							}

						});
			}
		});

		Button aboutus = (Button) findViewById(R.id.aboutus);
		aboutus.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Utils.goNextActivity(SelfInfoActivity.this, AboutUsActivity.class, false);
			}
		});

		Button changepwd = (Button) findViewById(R.id.changepwd);
		changepwd.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Utils.goNextActivity(SelfInfoActivity.this, ChangePWDActivity.class, false);
			}
		});

		Button checknew = (Button) findViewById(R.id.checknew);
		checknew.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				handleCheckNew();
			}
		});

		Button feedback = (Button) findViewById(R.id.feedback);
		feedback.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Utils.goNextActivity(SelfInfoActivity.this, FeedBackActivity.class, false);
			}
		});
	}

	protected void handleCheckNew() {
		dialog.show();
		dialog.setMessage(getResources().getString(R.string.checknew));
		CheckNewJob checkNewJob = new CheckNewJob(myhandler, Utils.getVersionCode());
		checkNewJob.execute();
	}

	private void handleExitLogin() {
		Utils.clearProp();
		DataMgr.getInstance().clearAll();
		Utils.clearSDFolder();
		setResult(ConstantValue.EXIT_LOGIN_RESULT);
		finish();
	}
}
