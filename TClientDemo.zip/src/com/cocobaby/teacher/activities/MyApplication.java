package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildStatus;
import com.cocobaby.teacher.handler.CrashHandler;
import com.cocobaby.teacher.httpclientmgr.HttpsModel;
import com.cocobaby.teacher.im.IMHelper;
import com.cocobaby.teacher.im.SimpleConversationBahavior;
import com.cocobaby.teacher.media.MyMediaScannerConnectionClient;
import com.cocobaby.teacher.service.MyService;

import android.app.ActivityManager;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import io.rong.imkit.RongContext;
import io.rong.imkit.RongIM;
import io.rong.imkit.widget.provider.CameraInputProvider;
import io.rong.imkit.widget.provider.ImageInputProvider;
import io.rong.imkit.widget.provider.InputProvider;
import io.rong.imlib.model.Conversation;

public class MyApplication extends Application{
    private static MyApplication           instance;
    private Map<String, ChildStatus>       childStatusMap       = new HashMap<String, ChildStatus>();
    private Map<String, String>            chatStatus           = new HashMap<String, String>();

    private boolean                        forTest              = true;
    private List<ChatInfo>                 tmpList              = new ArrayList<ChatInfo>();
    private boolean                        isNeedUpdateSelfInfo = false;
    private MyMediaScannerConnectionClient mediaScannerConnectionClient;

    public MyMediaScannerConnectionClient getMediaScannerConnectionClient(){
        return mediaScannerConnectionClient;
    }

    // 当前是否有数据库正在升级
    private boolean isDbUpdating = false;

    public boolean isDbUpdating(){
        return isDbUpdating;
    }

    public void setDbUpdating(boolean isDbUpdating){
        this.isDbUpdating = isDbUpdating;
    }

    public boolean isNeedUpdateSelfInfo(){
        return isNeedUpdateSelfInfo;
    }

    public void setNeedUpdateSelfInfo(boolean isNeedUpdateSelfInfo){
        this.isNeedUpdateSelfInfo = isNeedUpdateSelfInfo;
    }

    public synchronized void setLastChatStatus(String childid, String needChanged){
        chatStatus.clear();
        chatStatus.put(childid, needChanged);
    }

    public synchronized String getLastChatChanged(String childid){
        return chatStatus.get(childid);
    }

    public Map<String, ChildStatus> getChildStatusMap(){
        return childStatusMap;
    }

    public void setChildStatusMap(Map<String, ChildStatus> childStatusMap){
        this.childStatusMap.clear();
        this.childStatusMap = childStatusMap;
    }

    public List<ChatInfo> getTmpList(){
        return tmpList;
    }

    public void setTmpList(List<ChatInfo> tmpList){
        this.tmpList = tmpList;
    }

    public void clearCache(){
        this.childStatusMap.clear();
    }

    public boolean isForTest(){
        return forTest;
    }

    public static MyApplication getInstance(){
        return instance;
    }

    @Override
    public void onCreate(){
        super.onCreate();
        CrashHandler crashHandler = CrashHandler.getInstance();
        crashHandler.init(getApplicationContext());
        HttpsModel.initHttpsClient();
        instance = this;
        Intent service = new Intent(instance, MyService.class);
        instance.startService(service);
        initIM();
        // 如果有数据库需要升级，则触发onUpgrade方法
        DataMgr.getInstance();
        mediaScannerConnectionClient = new MyMediaScannerConnectionClient(this);
    }

    /**
     * 获得当前进程的名字
     *
     * @param context
     * @return
     */
    public static String getCurProcessName(Context context){

        int pid = android.os.Process.myPid();

        ActivityManager activityManager = (ActivityManager)context.getSystemService(Context.ACTIVITY_SERVICE);

        for(ActivityManager.RunningAppProcessInfo appProcess : activityManager.getRunningAppProcesses()){

            if(appProcess.pid == pid){

                return appProcess.processName;
            }
        }
        return null;
    }

    private void initIM(){
        /**
         *
         * OnCreate 会被多个进程重入，这段保护代码，确保只有您需要使用 RongIM 的进程和 Push 进程执行了 init。
         * io.rong.push 为融云 push 进程名称，不可修改。
         */
        if(getApplicationInfo().packageName.equals(getCurProcessName(getApplicationContext()))
                || "io.rong.push".equals(getCurProcessName(getApplicationContext()))){
            /**
             * IMKit SDK调用第一步 初始化
             */
            RongIM.init(this);
            // RongIM.init(this, appkey);

            IMHelper imHelper = new IMHelper();
            RongIM.setUserInfoProvider(imHelper, true);// 设置用户信息提供者。
            RongIM.setGroupInfoProvider(imHelper, true);// 设置群组信息提供者。
            RongIM.setOnReceiveMessageListener(imHelper);
            RongIM.setConversationBehaviorListener(new SimpleConversationBahavior());

            // 扩展功能自定义
            InputProvider.ExtendProvider[] provider = { new ImageInputProvider(RongContext.getInstance()), // 图片
                    new CameraInputProvider(RongContext.getInstance()), // 相机
            };
            RongIM.resetInputExtensionProvider(Conversation.ConversationType.PRIVATE, provider);
            RongIM.resetInputExtensionProvider(Conversation.ConversationType.GROUP, provider);
        }
    }
}
