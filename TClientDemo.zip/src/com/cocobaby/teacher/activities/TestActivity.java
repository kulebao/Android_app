package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.GetChildrenJob;
import com.cocobaby.teacher.taskmgr.GetClassesJob;
import com.cocobaby.teacher.taskmgr.GetStatusJob;
import com.cocobaby.teacher.taskmgr.LoginJob;
import com.cocobaby.teacher.taskmgr.MultiPostEstimateJob;
import com.cocobaby.teacher.taskmgr.PostTeacherJob;
import com.cocobaby.teacher.threadpool.MyThreadPoolMgr;
import com.cocobaby.teacher.utils.Utils;

public class TestActivity extends Activity {
	private Handler handler;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		initHandler();
		initUI();
		initDirs();
	}

	private void initDirs() {
		Utils.makeDefaultDirInSDCard();
	}

	@Override
	protected void onDestroy() {
		handleAppExit();
		super.onDestroy();
	}

	private void handleAppExit() {
		MyThreadPoolMgr.shutdown();
		DataMgr.getInstance().close();
	}

	private void initHandler() {
		handler = new MyHandler(this, null) {

			@Override
			public void handleMessage(Message msg) {
				if (TestActivity.this.isFinishing()) {
					Log.d("", "MainActivity is finishing , do nothing!");
					return;
				}

				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.LOGIN_SUCCESS:
					Toast.makeText(TestActivity.this, "login success", Toast.LENGTH_SHORT).show();
					break;
				case EventType.PWD_INCORRECT:
					Toast.makeText(TestActivity.this, "pwd invalid!", Toast.LENGTH_SHORT).show();
					break;
				case EventType.POST_ESTIMATE_FAIL:
					Toast.makeText(TestActivity.this, "POST es fail!", Toast.LENGTH_SHORT).show();
					break;
				case EventType.POST_ESTIMATE_SUCCESS:
					Toast.makeText(TestActivity.this, "POST es success!", Toast.LENGTH_SHORT).show();
					break;
				case EventType.POST_TEACHER_SUCCESS:
					Toast.makeText(TestActivity.this, "POST te success!", Toast.LENGTH_SHORT).show();
					break;
				case EventType.POST_TEACHER_FAIL:
					Toast.makeText(TestActivity.this, "POST te fail!", Toast.LENGTH_SHORT).show();
					break;

				default:
					break;
				}
			}

		};
	}

	private void initUI() {
		Button loginBtn = (Button) findViewById(R.id.login);
		loginBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				LoginJob job = new LoginJob(handler, "test3", "13333333333");
				job.execute();
			}
		});

		Button getClassesBtn = (Button) findViewById(R.id.getclass);
		getClassesBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GetClassesJob classesJob = new GetClassesJob(handler);
				classesJob.execute();
			}
		});

		Button getchildrenBtn = (Button) findViewById(R.id.getchildren);
		getchildrenBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GetChildrenJob childrenJob = new GetChildrenJob(handler);
				childrenJob.execute();
			}
		});

		Button getstatus = (Button) findViewById(R.id.getstatus);
		getstatus.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				GetStatusJob getStatusJob = new GetStatusJob(handler);
				getStatusJob.execute();
			}
		});

		Button clear = (Button) findViewById(R.id.clear);
		clear.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				DataMgr.getInstance().clearAll();
			}
		});

		Button postestimate = (Button) findViewById(R.id.postestimate);
		postestimate.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				List<String> childIDs = getChildIds();
				EstimateInfo info = new EstimateInfo("一般般！", 2, 2, 2, 2, 2, 2, 2, 3);
				MultiPostEstimateJob job = new MultiPostEstimateJob(handler, childIDs, info);
				job.execute();
			}

			private List<String> getChildIds() {
				List<String> list = new ArrayList<String>();
				List<ChildInfo> childList = DataMgr.getInstance().getAllChild();
				for (ChildInfo info : childList) {
					if (info.getClass_id() == 15) {
						list.add(info.getServerID());
					}

				}
				return list;
			}
		});

		Button postteacher = (Button) findViewById(R.id.postteacher);
		postteacher.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				TeacherInfo info = getTeacher();
				PostTeacherJob job = new PostTeacherJob(handler, info);
				job.execute();
			}

			private TeacherInfo getTeacher() {
				TeacherInfo info = DataMgr.getInstance().getTeacherInfo();
				info.setName("王老师");
				info.setPhone("13333333331");
				info.setPortrait("http://suoqin-test.u.qiniudn.com/FoUJaV4r5L0bM0414mGWEIuCLEdL");
				return info;
			}
		});
	}

}
