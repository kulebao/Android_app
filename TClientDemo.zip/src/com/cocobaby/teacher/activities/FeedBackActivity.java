package com.cocobaby.teacher.activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.FeedbackJob;
import com.cocobaby.teacher.utils.Utils;

public class FeedBackActivity extends UmengStatisticsActivity {
	private EditText feedbackContent;
	private MyHandler handler;
	private ProgressDialog dialog;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.feed_back);
		initView();
		initHandler();
	}

	private void initView() {
		initDialog();
		initBtn();
		ActivityHelper.setTopbarTitle(this, R.string.feedback);
	}

	public void initBtn() {
		feedbackContent = (EditText) findViewById(R.id.feedbackContent);
		Button sendBtn = (Button) findViewById(R.id.sendbtn);
		sendBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				runFeedBackTask();
			}
		});
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.sending));
	}

	private void initHandler() {

		handler = new MyHandler(this, dialog) {

			@Override
			public void handleMessage(Message msg) {
				if (FeedBackActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.FEEDBACK_SUCESS:
					Toast.makeText(FeedBackActivity.this,
							R.string.send_success, Toast.LENGTH_SHORT).show();
					FeedBackActivity.this.finish();
					break;
				case EventType.FEEDBACK_FAILED:
					Toast.makeText(FeedBackActivity.this, R.string.send_fail,
							Toast.LENGTH_SHORT).show();
					break;
				default:
					break;
				}
			}
		};
	}

	private void runFeedBackTask() {
		String content = feedbackContent.getText().toString();
		if (TextUtils.isEmpty(content)) {
			Utils.makeToast(this, R.string.content_invalid);
			return;
		}
		dialog.show();
		FeedbackJob feedbackJob = new FeedbackJob(handler, content);
		feedbackJob.execute();
	}

}
