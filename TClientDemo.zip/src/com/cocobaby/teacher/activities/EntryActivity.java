package com.cocobaby.teacher.activities;

import io.rong.imkit.RongIM;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.EntryGridViewAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.customview.RoundedImageView;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.IMGroupInfo;
import com.cocobaby.teacher.dbmgr.info.SchoolInfo;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.method.MethodHelper;
import com.cocobaby.teacher.taskmgr.DownloadImgeJob;
import com.cocobaby.teacher.taskmgr.GetChildrenJob;
import com.cocobaby.teacher.taskmgr.GetTeacherListJob;
import com.cocobaby.teacher.taskmgr.JoinGroupJob;
import com.cocobaby.teacher.taskmgr.UpdateSchoolInfoJob;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class EntryActivity extends MyActivity{
    private EntryGridViewAdapter adapter;
    private GridView             gridview;

    public static final int      NOTICE               = 0;
    public static final int      BABY_LIST            = 1;
    public static final int      GROW_EXP             = 2;
    public static final int      CHAT                 = 3;

    private DownloadImgeJob      downloadImgeJob;

    private Handler              myhandler;
    private RoundedImageView     headView;
    private TextView             nameView;
    private ProgressDialog       dialog;
    private boolean              bGetChildInfoSuccess = false;

    // EventType.GET_TEACHER_SUCCESS

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.entry);
        initDialog();
        initHander();
        initDownloadJob();
        initUI();

        runCheckTeacherInfoTask();

        runGetChildInfoJob();
        runUpdateSchoolInfoJob();
    }

    private void runUpdateSchoolInfoJob(){
        SchoolInfo schoolInfo = DataMgr.getInstance().getSchoolInfo();
        if(schoolInfo == null){
            UpdateSchoolInfoJob updateSchoolInfoJob = new UpdateSchoolInfoJob(myhandler);
            updateSchoolInfoJob.execute();
        }
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.load_babys_data));
    }

    private void runGetChildInfoJob(){
        dialog.show();
        GetChildrenJob childrenJob = new GetChildrenJob(myhandler);
        childrenJob.execute();
    }

    private void initDownloadJob(){
        downloadImgeJob = new DownloadImgeJob();
        downloadImgeJob.setHanlder(myhandler);
    }

    private void initHander(){
        myhandler = new MyHandler(this, dialog){
            @Override
            public void handleMessage(Message msg){
                if(EntryActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }
                TeacherInfo teacherInfo = null;
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.DOWNLOAD_FILE_SUCCESS:
                        teacherInfo = DataMgr.getInstance().getTeacherInfo();
                        if(teacherInfo.getPortrait().equals((String)msg.obj)){
                            Log.d("EEE", "initHead ag!!!");
                            setHeadIcon(teacherInfo);
                        }
                        break;
                    case EventType.GET_CHILDREN_SUCCESS:
                        bGetChildInfoSuccess = true;
                        break;
                    case EventType.GET_CHILDREN_FAIL:
                        bGetChildInfoSuccess = false;
                        Utils.makeToast(EntryActivity.this, R.string.load_babys_data_fail);
                        // 成功失败都得处理，只不过成功的话，数据库已经更新，失败则用的老数据
                        break;
                    case EventType.JOIN_IM_GROUP_SUCCESS:
                        startToConversationListActivity();
                        break;
                    case EventType.JOIN_IM_GROUP_FAIL:
                        Utils.makeToast(EntryActivity.this, R.string.join_group_failed);
                        break;
                    case EventType.GET_CHILDREN_END:
                        updateTeacher();
                        break;
                    default:
                        break;
                }
            }
        };
    }

    private void startToConversationListActivity(){
        try{
            RongIM.getInstance().startConversationList(EntryActivity.this);
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void runCheckTeacherInfoTask(){
        try{
            List<TeacherInfo> allTeachers = DataMgr.getInstance().getAllTeachers();

            // new GetTeacherJob(TeacherInfo.getPhones(allTeachers),
            // myhandler).execute();

            for(TeacherInfo teacher : allTeachers){
                // 如果教师的头像属性不为空，本地又没有保存，那么此时重新下载一次头像
                if(!TextUtils.isEmpty(teacher.getPortrait()) && !new File(teacher.getLocalHeadIconPath()).exists()){
                    Log.d("EEE", "download teacher icon name=" + teacher.getName() + " url=" + teacher.getPortrait());
                    downloadTeacherHeadIcon(teacher);
                }
            }
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    private void downloadTeacherHeadIcon(TeacherInfo teacher){
        downloadImgeJob.addTask(teacher.getPortrait(), teacher.getLocalHeadIconPath(),
                                ConstantValue.HEAD_ICON_BIG_HEIGHT, ConstantValue.HEAD_ICON_BIG_WIDTH);
    }

    private void initUI(){
        headView = (RoundedImageView)findViewById(R.id.head_photo);
        ActivityHelper.setTopbarTitle(this, R.string.app_name);
        initGridView();
    }

    private void initMyInfo(){
        TeacherInfo teacherInfo = DataMgr.getInstance().getTeacherInfo();

        setHeadIcon(teacherInfo);
        initName(teacherInfo);

        if(MyApplication.getInstance().isNeedUpdateSelfInfo()){
            downloadTeacherHeadIcon(teacherInfo);
            MyApplication.getInstance().setNeedUpdateSelfInfo(false);
        }
    }

    private void initName(TeacherInfo teacherInfo){
        nameView = (TextView)findViewById(R.id.teacher_name);
        nameView.setText(teacherInfo.getName());
    }

    private void setHeadIcon(TeacherInfo teacherInfo){
        Bitmap loacalBitmap = Utils.getLoacalBitmap(teacherInfo.getLocalHeadIconPath(), ImageDownloader
                .getMaxPixWithDensity(ConstantValue.HEAD_ICON_BIG_WIDTH, ConstantValue.HEAD_ICON_BIG_HEIGHT));
        if(loacalBitmap != null){
            Utils.setImg(headView, loacalBitmap);
        } else{
            headView.setImageResource(R.drawable.chat_head_icon);
        }
    }

    @Override
    public void onResume(){
        super.onResume();
        initMyInfo();
    }

    public void initGridView(){
        gridview = (GridView)findViewById(R.id.gridview);
        ArrayList<HashMap<String, Object>> lstImageItem = initData();
        adapter = new EntryGridViewAdapter(this, lstImageItem);
        gridview.setAdapter(adapter);
        gridview.setOnItemClickListener(new ItemClickListener());
    }

    public ArrayList<HashMap<String, Object>> initData(){
        ArrayList<HashMap<String, Object>> lstImageItem = new ArrayList<HashMap<String, Object>>();

        HashMap<String, Object> map = new HashMap<String, Object>();
        map.put("ItemImage", R.drawable.notice);
        map.put("ItemText", "");
        lstImageItem.add(map);

        map = new HashMap<String, Object>();
        map.put("ItemImage", R.drawable.babylist);
        map.put("ItemText", "");
        lstImageItem.add(map);

        map = new HashMap<String, Object>();
        map.put("ItemImage", R.drawable.growexp);
        map.put("ItemText", "");
        lstImageItem.add(map);

        if(MyApplication.getInstance().isForTest()){
            map = new HashMap<String, Object>();
            map.put("ItemImage", R.drawable.chat);
            map.put("ItemText", "");
            lstImageItem.add(map);
        }

        // map = new HashMap<String, Object>();
        // map.put("ItemImage", R.drawable.setting);
        // map.put("ItemText", "");
        // lstImageItem.add(map);

        return lstImageItem;
    }

    // 当AdapterView被单击(触摸屏或者键盘)，则返回的Item单击事件
    private class ItemClickListener implements OnItemClickListener{
        public void onItemClick(AdapterView<?> parent, View view, int position, long id){
            handleGridViewClick(position);
        }
    }

    public void handleGridViewClick(int position){

        switch(position){
            case NOTICE:
                startToActivity(NoticePullRefreshActivity.class);
                break;
            case BABY_LIST:
                startToChildListActivity();
                break;
            case GROW_EXP:
                // startToActivity(SendExpActivity.class);
                startToActivity(ExpListActivity.class);
                break;
            case CHAT:
                DataMgr instance = DataMgr.getInstance();
                List<ClassInfo> allClasses = instance.getAllClasses();
                List<String> unJoinedClassGroupIDs = new ArrayList<>();

                for(ClassInfo classInfo : allClasses){
                    IMGroupInfo imGroupInfo = instance.getIMGroupInfo(classInfo.getClassID());
                    if(imGroupInfo == null){
                        unJoinedClassGroupIDs.add(classInfo.getClassID() + "");
                    }
                }

                if(!unJoinedClassGroupIDs.isEmpty()){
                    runJoinGroupTask(unJoinedClassGroupIDs);
                } else{
                    startToConversationListActivity();
                }

                break;

            default:
                Toast.makeText(this, "暂未实现！", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private void runJoinGroupTask(List<String> unJoinedClassGroupIDs){
        dialog.setMessage(getResources().getString(R.string.get_group_info));
        dialog.show();
        JoinGroupJob joinGroupJob = new JoinGroupJob(myhandler, unJoinedClassGroupIDs);
        joinGroupJob.execute();
    }

    private void startToChildListActivity(){
        Intent intent = new Intent();
        intent.putExtra(ConstantValue.GET_CHILD_INFO, bGetChildInfoSuccess);
        intent.setClass(this, ChildListActivity.class);
        startActivity(intent);
    }

    public void setting(View view){
        startToSettingActivity();
    }

    private void startToActivity(Class<?> activityClass){
        if(!MethodHelper.isInit()){
            Utils.makeToast(EntryActivity.this, R.string.init_check_fail);
            return;
        }

        Utils.goNextActivity(EntryActivity.this, activityClass, false);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == ConstantValue.START_SETTING && resultCode == ConstantValue.EXIT_LOGIN_RESULT){
            Intent intent = new Intent();
            intent.setClass(this, LoginActivity.class);
            startActivity(intent);
            finish();
            return;
        }
    }

    private void startToSettingActivity(){
        Intent intent = new Intent();
        intent.setClass(EntryActivity.this, SelfInfoActivity.class);
        this.startActivityForResult(intent, ConstantValue.START_SETTING);
    }

    private void updateTeacher(){
        List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
        for(ClassInfo classInfo : allClasses){
            GetTeacherListJob getTeacherListJob = new GetTeacherListJob(myhandler,
                    classInfo.getClassID() + "");
            getTeacherListJob.execute();
        }
    }
}
