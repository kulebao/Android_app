package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;
import android.widget.ExpandableListView.OnGroupCollapseListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.ExpandAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ChildStatus;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.listdata.ChildComparator;
import com.cocobaby.teacher.listdata.ChildSummary;
import com.cocobaby.teacher.listdata.ClassSummary;
import com.cocobaby.teacher.media.MediaMgr;
import com.cocobaby.teacher.taskmgr.DownloadImgeJob;
import com.cocobaby.teacher.taskmgr.GetAllChildLastChatJob;
import com.cocobaby.teacher.taskmgr.GetChildrenJob;
import com.cocobaby.teacher.taskmgr.GetStatusJob;
import com.cocobaby.teacher.threadpool.MyThreadPoolMgr;
import com.cocobaby.teacher.utils.Utils;

public class ChildListActivity extends UmengStatisticsActivity{

    private List<ClassSummary>     list                     = new ArrayList<ClassSummary>();
    private ProgressDialog         dialog;
    private Handler                handler;
    // private ChildSummaryAdapter adapter;
    private ExpandAdapter          adapter;
    private GetStatusJob           getStatusJob;
    private GetAllChildLastChatJob getLastChatJob;
    private DownloadImgeJob        downloadImgeJob;
    private Map<String, ChatInfo>  lastChatMap              = null;
    private String                 current_selected_childid = "";

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.childlist);
        initDialog();
        initHandler();
        initUI();

        boolean success = getIntent().getBooleanExtra(ConstantValue.GET_CHILD_INFO, false);
        // 如果在启动此界面前已经成功获取了小孩信息，这里就不用再次获取了
        if(success){
            handleGetChildResult(true);
        } else{
            runGetChildInfoJob();
        }
    }

    private void runGetChildInfoJob(){
        dialog.show();
        dialog.setMessage(getResources().getString(R.string.load_babys_data));
        GetChildrenJob childrenJob = new GetChildrenJob(handler);
        childrenJob.execute();
    }

    private void runGetChildStatusJob(){
        dialog.show();
        dialog.setMessage(getResources().getString(R.string.refresh_babys_status));
        getStatusJob = new GetStatusJob(handler);
        getStatusJob.execute();
    }

    private void runGetLastChatJob(){
        dialog.show();
        dialog.setMessage(getResources().getString(R.string.refresh_chat));
        getLastChatJob = new GetAllChildLastChatJob(handler);
        getLastChatJob.execute();
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
    }

    private void initHandler(){

        handler = new MyHandler(this, dialog){

            @SuppressWarnings("unchecked")
            @Override
            public void handleMessage(Message msg){
                if(ChildListActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }

                Log.w("dasd", "LoginActivity msg.what=" + msg.what);
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.GET_CHILDREN_SUCCESS:
                        handleGetChildResult(true);
                        break;
                    case EventType.GET_CHILDREN_FAIL:
                        Utils.makeToast(ChildListActivity.this, R.string.load_babys_data_fail);
                        // 成功失败都得处理，只不过成功的话，数据库已经更新，失败则用的老数据
                        handleGetChildResult(false);
                        break;
                    case EventType.GET_CHILD_STATUS_SUCCESS:
                        addChildStatus();
//                        runGetLastChatJob();
                        break;
                    case EventType.GET_CHILD_STATUS_FAIL:
                        Utils.makeToast(ChildListActivity.this, R.string.refresh_babys_status_fail);
//                        runGetLastChatJob();
                        break;
                    case EventType.GET_CHAT_SUCCESS:
                        refreshLastChat((Map<String, ChatInfo>)msg.obj);
                        break;
                    case EventType.GET_CHAT_FAIL:
                        Utils.makeToast(ChildListActivity.this, R.string.refresh_chat_fail);
                        break;
                    default:
                        break;
                }
            }

        };
    }

    private void refreshLastChat(Map<String, ChatInfo> map){
        // 之前已经刷新过，到这里是用户手动点击了刷新按钮
        replaceNewChat(map, false);
        adapter.notifyDataSetChanged();
    }

    private void replaceNewChat(Map<String, ChatInfo> map, boolean firstInit){
        for(ClassSummary summary : list){
            List<ChildSummary> childList = summary.getChildList();
            for(ChildSummary childSummary : childList){
                ChatInfo newChat = map.get(childSummary.getInfo().getServerID());
                if(newChat != null && newChat.getTimestamp() > childSummary.getLastChatInfo().getTimestamp()){
                    if(!firstInit){
                        // 第一次是从数据库直接读，不计入新chat提醒
                        childSummary.setHasNewChat(true);
                    }
                    childSummary.setLastChatInfo(newChat);
                }
            }
        }
    }

    protected void addChildStatus(){
        Map<String, ChildStatus> childStatusMap = MyApplication.getInstance().getChildStatusMap();
        for(ClassSummary summary : list){
            List<ChildSummary> childList = summary.getChildList();
            for(ChildSummary childSummary : childList){
                ChildStatus childStatus = childStatusMap.get(childSummary.getInfo().getServerID());
                if(childStatus != null){
                    childSummary.setStatus(childStatus);
                }
            }
            Collections.sort(childList, new ChildComparator());
        }

        adapter.notifyDataSetChanged();
    }

    private void handleGetChildResult(boolean success){
        // initData不能放在oncreate里面，因为初次登录成功，还没有获取到班级信息
        // 获取班级信息是和获取小孩信息耦合在一起的，后续优化
        initData();
        setChildDataToList();
        lastChatMap = DataMgr.getInstance().getAllChildLastChatMap();
        replaceNewChat(lastChatMap, true);
        adapter.notifyDataSetChanged();
        runGetChildStatusJob();
    }

    private void setChildDataToList(){
        for(ClassSummary summary : list){
            List<ChildInfo> childInfos = DataMgr.getInstance().getChildByClass(summary.getInfo().getClassID());
            List<ChildSummary> childSummaries = new ArrayList<ChildSummary>();
            for(ChildInfo childInfo : childInfos){
                ChildSummary childSummary = new ChildSummary();
                childSummary.setInfo(childInfo);
                childSummaries.add(childSummary);
            }
            summary.setChildList(childSummaries);
        }
    }

    private void initUI(){
        initList();
        initHeader();
    }

    private void initHeader(){
        TextView refresh = (TextView)findViewById(R.id.rightBtn);
        // refresh.setText(R.string.refresh);
        refresh.setVisibility(View.VISIBLE);
        refresh.setBackgroundResource(R.drawable.refresh);
        refresh.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                runGetChildStatusJob();
            }
        });

        TextView leftBtn = (TextView)findViewById(R.id.leftBtn);
        leftBtn.setVisibility(View.VISIBLE);
        leftBtn.setText(R.string.children);
        leftBtn.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });

    }

    private void initList(){
        ExpandableListView exList = (ExpandableListView)findViewById(R.id.expandList);
        exList.setDescendantFocusability(ExpandableListView.FOCUS_AFTER_DESCENDANTS);
        downloadImgeJob = new DownloadImgeJob();
        adapter = new ExpandAdapter(this, list, downloadImgeJob);

        // 分组展开
        exList.setOnGroupExpandListener(new OnGroupExpandListener(){
            public void onGroupExpand(int groupPosition){}
        });
        // 分组关闭
        exList.setOnGroupCollapseListener(new OnGroupCollapseListener(){
            public void onGroupCollapse(int groupPosition){}
        });
        // 子项单击
        exList.setOnChildClickListener(new OnChildClickListener(){

            public boolean onChildClick(ExpandableListView arg0, View arg1, int groupPosition, int childPosition,
                    long arg4){

                current_selected_childid = list.get(groupPosition).getChildList().get(childPosition).getInfo()
                        .getServerID();
                startToChildDetailActivity(current_selected_childid);
                // Toast.makeText(
                // ChildListActivity.this,
                // list.get(groupPosition).getInfo().getClassName() + " : "
                // +
                // list.get(groupPosition).getChildList().get(childPosition).getInfo().getName(),
                // Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        exList.setAdapter(adapter);
    }

    private void startToChildDetailActivity(String childid){
        Intent intent = new Intent();
        intent.putExtra(JSONConstant.CHILD_ID, childid);
        intent.setClass(this, ChildDetailActivity.class);
        startActivity(intent);
    }

    private void initData(){
        List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();

        for(ClassInfo info : allClasses){
            ClassSummary summary = new ClassSummary();
            summary.setInfo(info);
            list.add(summary);
        }
    }

    @Override
    protected void onDestroy(){
        Log.w("djc", "ChildListActivity destroy!!!!");

        if(downloadImgeJob != null){
            downloadImgeJob.stopTask();
        }

        if(adapter != null){
            adapter.releaseCache();
        }

        MyApplication.getInstance().clearCache();
        MyThreadPoolMgr.shutdown();
        DataMgr.getInstance().close();
        MediaMgr.close();
        super.onDestroy();
    }

    @Override
    protected void onRestart(){
        super.onRestart();
		// if(!TextUtils.isEmpty(current_selected_childid)
		// &&
		// "true".equals(MyApplication.getInstance().getLastChatChanged(current_selected_childid))){
		// List<ChatInfo> lastChatList =
		// DataMgr.getInstance().getChatInfoWithLimite(1,
		// current_selected_childid);
		// if(!lastChatList.isEmpty()){
		// changeLastChat(lastChatList.get(0));
		// }
		// }
    }

    private void changeLastChat(ChatInfo chatInfo){
        for(ClassSummary summary : list){
            List<ChildSummary> childList = summary.getChildList();
            for(ChildSummary childSummary : childList){
                if(childSummary.getInfo().getServerID().equals(chatInfo.getChild_id())){
                    childSummary.setHasNewChat(false);
                    childSummary.setLastChatInfo(chatInfo);
                    adapter.notifyDataSetChanged();
                }
            }
        }
    }

}
