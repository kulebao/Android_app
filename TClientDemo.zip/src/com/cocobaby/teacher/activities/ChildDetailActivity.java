package com.cocobaby.teacher.activities;

import io.rong.imkit.RongIM;

import java.util.ArrayList;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.ParentListAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.GetRelationshipJob;
import com.cocobaby.teacher.utils.Utils;

public class ChildDetailActivity extends UmengStatisticsActivity{
    private String            childid;
    private Handler           handler;
    private ParentListAdapter adapter;
    private ProgressDialog    dialog;
    private List<ParentInfo>  parentList;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.child_detail);
        childid = getIntent().getStringExtra(JSONConstant.CHILD_ID);
        initDialog();
        initHandler();
        initBtn();
        runGetRelationshipJob();
    }

    private void runGetRelationshipJob(){
        dialog.show();
        GetRelationshipJob job = new GetRelationshipJob(handler, childid);
        job.execute();
    }

    private void initHeader(){
        TextView cancel = (TextView)findViewById(R.id.leftBtn);
        cancel.setText(R.string.back);
        cancel.setVisibility(View.VISIBLE);
        cancel.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });

        ActivityHelper.setTopbarTitle(this, R.string.child_detail);
    }

    private void initUI(){
        initHeader();
        initChildInfo();
        initParentList();
    }

    private void initBtn(){
        ImageView chat = (ImageView)findViewById(R.id.chat);
        chat.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                startToChatActivity();
            }
        });

        ImageView estimate = (ImageView)findViewById(R.id.estimate);
        estimate.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                startToEstimateActivity();
            }
        });
    }

    private void initParentList(){
        ListView parentListView = (ListView)findViewById(R.id.parent_list);
        parentList = new ArrayList<ParentInfo>();
        List<String> parentIDs = DataMgr.getInstance().getParentIDsByChildId(childid);
        for(String id : parentIDs){
            ParentInfo parentInfo = DataMgr.getInstance().getParentByID(id);
            parentList.add(parentInfo);
        }
        adapter = new ParentListAdapter(this, parentList);
        parentListView.setAdapter(adapter);

        parentListView.setOnItemClickListener(new OnItemClickListener(){

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                ParentInfo item = adapter.getItem(position);
                RongIM.getInstance().startPrivateChat(ChildDetailActivity.this, item.getIMUserid(), item.getName());
            }
        });
    }

    private void initChildInfo(){
        ChildInfo childinfo = DataMgr.getInstance().getChildByID(childid);
        ImageView view = (ImageView)findViewById(R.id.headicon);
        Bitmap loacalBitmap = Utils.getLoacalBitmap(childinfo.getChildrenLocalIconPath(),
                                                    ConstantValue.HEAD_ICON_BIG_HEIGHT
                                                            * ConstantValue.HEAD_ICON_BIG_WIDTH);

        if(loacalBitmap != null){
            view.setImageBitmap(loacalBitmap);
        } else{
            view.setImageResource(R.drawable.default_icon);
        }

        TextView textView = (TextView)findViewById(R.id.name);
        textView.setText(childinfo.getName());
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.get_child_parent));
    }

    private void initHandler(){

        handler = new MyHandler(this, dialog){

            @Override
            public void handleMessage(Message msg){
                if(ChildDetailActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when ChildDetailActivity finishing!");
                    return;
                }

                Log.w("dasd", "LoginActivity msg.what=" + msg.what);
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.GET_RELATIONSHIP_SUCCESS:
                        initUI();
                        break;
                    case EventType.GET_RELATIONSHIP_FAIL:
                        initUI();
                        Utils.makeToast(ChildDetailActivity.this, R.string.get_child_parent_fail);
                        break;
                    default:
                        break;
                }
            }
        };
    }

    private void startToEstimateActivity(){
        Intent intent = new Intent();
        intent.putExtra(JSONConstant.CHILD_ID, childid);
        intent.setClass(this, EstimateActivity.class);
        startActivity(intent);
    }

    private void startToChatActivity(){
        Intent intent = new Intent();
        intent.putExtra(JSONConstant.CHILD_ID, childid);
        intent.setClass(this, ChatActivity.class);
        startActivity(intent);
    }
}
