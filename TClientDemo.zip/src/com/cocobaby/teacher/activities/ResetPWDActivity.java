package com.cocobaby.teacher.activities;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.ResetPWDJob;
import com.cocobaby.teacher.utils.Utils;

public class ResetPWDActivity extends UmengStatisticsActivity {
	private Handler handler;
	private ProgressDialog dialog;
	private EditText inputAuthCodeView;
	private EditText inuputPWDView;
	private EditText reInuputPWDView;
	private Button resetPWDBtn;
	private EditText username;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.resetpwd);
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		initHandler();
		initView();
	}

	private void initHandler() {
		handler = new MyHandler(this, dialog) {

			@Override
			public void handleMessage(Message msg) {
				if (ResetPWDActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				Log.w("DDDDDD", "ResetPWDActivity event =" + msg.what);
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.RESET_PWD_SUCCESS:
					handleResetPwdSuccess();
					break;

				case EventType.RESET_PWD_FAILED:
					DlgMgr.showSingleBtnResDlg(R.string.reset_pwd_failed,
							ResetPWDActivity.this);
					break;

				case EventType.AUTH_CODE_IS_INVALID:
					DlgMgr.showSingleBtnResDlg(R.string.auth_code_invalid,
							ResetPWDActivity.this);
					break;

				default:
					break;
				}
			}

		};
	}

	private void initView() {
		resetPWDBtn = (Button) findViewById(R.id.resetPWDBtn);
		resetPWDBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (checkInput()) {
					// 发起密码重置
					Log.w("djc", "runResetPWDTask!");
					runResetPWDTask();
				}
			}
		});

		inputAuthCodeView = (EditText) findViewById(R.id.inputAuthCodeView);
		username = (EditText) findViewById(R.id.inputusername);

		inuputPWDView = (EditText) findViewById(R.id.inuputPWDView);
		reInuputPWDView = (EditText) findViewById(R.id.reInuputPWDView);
	}

	private void runResetPWDTask() {
		try {
			new ResetPWDJob(handler, username.getText().toString(),
					getAuthCode(), getPwd()).execute();
			dialog.setMessage(getResources().getString(R.string.pwdreseting));
			dialog.show();
		} catch (Exception e) {
			dialog.cancel();
			e.printStackTrace();
		}
	}

	private boolean checkInput() {
		if (!Utils.checkAuthCode(getAuthCode())) {
			DlgMgr.showSingleBtnResDlg(R.string.auth_code_input_error,
					ResetPWDActivity.this);
			return false;
		}

		if (!Utils.checkPWD(getPwd())) {
			DlgMgr.showSingleBtnResDlg(R.string.pwd_format_error,
					ResetPWDActivity.this);
			clearInputView();
			return false;
		}

		if (!isTwoPwdSame()) {
			DlgMgr.showSingleBtnResDlg(R.string.pwd_confirm_error,
					ResetPWDActivity.this);
			clearInputView();
			return false;
		}

		return true;
	}

	private void clearInputView() {
		inuputPWDView.setText("");
		reInuputPWDView.setText("");
	}

	// 判断2次密码输入是否一致
	private boolean isTwoPwdSame() {
		return inuputPWDView.getText().toString()
				.equals(reInuputPWDView.getText().toString());
	}

	private String getPwd() {
		return inuputPWDView.getText().toString();
	}

	private String getAuthCode() {
		return inputAuthCodeView.getText().toString();
	}

	private void handleResetPwdSuccess() {
		Utils.makeToast(this, R.string.reset_pwd_success);
		ResetPWDActivity.this.setResult(Activity.RESULT_OK);
		ResetPWDActivity.this.finish();
		// DlgMgr.showSingleBtnResDlg(R.string.reset_pwd_success, this,
		// new android.content.DialogInterface.OnClickListener() {
		// @Override
		// public void onClick(DialogInterface dialog, int which) {
		// }
		// });
	}

}
