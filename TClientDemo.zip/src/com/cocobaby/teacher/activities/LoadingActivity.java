package com.cocobaby.teacher.activities;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.LoadingJob;
import com.cocobaby.teacher.utils.Utils;

public class LoadingActivity extends UmengStatisticsActivity {
	private Handler handler;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.loading);
		initHandler();
		runLoadingJob();
		Log.d("", "current db version = " + DataMgr.DB_VERSION);
	}

	private void runLoadingJob() {
		LoadingJob job = new LoadingJob(handler);
		job.execute();
	}

	private void initHandler() {
		handler = new MyHandler(this, null) {
			@Override
			public void handleMessage(Message msg) {
				if (LoadingActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);

				switch (msg.what) {
				case EventType.LOADING_TO_LOGIN:
					Utils.goNextActivity(LoadingActivity.this, LoginActivity.class, true);
					break;
				case EventType.LOADING_TO_MAIN:
					Utils.goNextActivity(LoadingActivity.this, MainActivity.class, true);
					break;
				case EventType.LOADING_TO_MAIN_AND_UPDATE:
					MyApplication.getInstance().setNeedUpdateSelfInfo(true);
					Utils.goNextActivity(LoadingActivity.this, MainActivity.class, true);
					break;
				default:
					break;
				}
			}
		};
	}

	@Override
	public void onBackPressed() {
		return;
	}

}
