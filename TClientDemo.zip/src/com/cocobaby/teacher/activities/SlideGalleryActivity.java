package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.SlideGalleryAdapter;
import com.cocobaby.teacher.constant.Action;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.customview.SlideGallery;
import com.cocobaby.teacher.utils.ImageUtils;
import com.cocobaby.teacher.utils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;

public class SlideGalleryActivity extends Activity{
    /** Called when the activity is first created. */
    private SlideGallery        gallery;
    private ImageLoader         imageLoader;
    private SlideGalleryAdapter adapter;
    private TextView            content;
    protected int               current = 0;
    private boolean             isSend;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.slide_gallery);
        isSend = getIntent().getBooleanExtra(ConstantValue.GALLERY_SEND, false);

        initImageLoader();
        initUI();
    }

    private void initUI(){
        initGallery();
        ImageView delete = (ImageView)findViewById(R.id.delete);
        delete.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                if(current >= 0){
                    int postion = current;

                    adapter.remove(current);
                    current--;

                    if(current < 0){
                        current = 0;
                    }

                    if(adapter.getCount() == 0){
                        Intent data = new Intent().putExtra(Action.PATH_AFTER_CHANGE, new String[0]);
                        setResult(RESULT_OK, data);
                        SlideGalleryActivity.this.finish();
                        return;
                    }

                    setIconCount(postion);
                }
            }
        });

        Button confirm = (Button)findViewById(R.id.confirm);
        confirm.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                List<String> list = adapter.getList();
                String[] array = list.toArray(new String[list.size()]);
                Intent data = new Intent().putExtra(Action.PATH_AFTER_CHANGE, array);
                setResult(RESULT_OK, data);
                SlideGalleryActivity.this.finish();
            }
        });

        content = (TextView)findViewById(R.id.content);

        if(!isSend){
            delete.setVisibility(View.GONE);
            confirm.setVisibility(View.GONE);
        }
    }

    private void initGallery(){
        gallery = (SlideGallery)findViewById(R.id.mygallery);
        gallery.setVerticalFadingEdgeEnabled(false);
        gallery.setHorizontalFadingEdgeEnabled(false);
        List<String> list = getList();
        adapter = new SlideGalleryAdapter(this, imageLoader, list, isSend);
        gallery.setAdapter(adapter);

        gallery.setOnFocusChangeListener(new OnFocusChangeListener(){
            @Override
            public void onFocusChange(View v, boolean hasFocus){}
        });

        gallery.setOnItemSelectedListener(new OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id){
                Log.d("DDD", "onItemSelected position=" + position + " id=" + id);
                current = position;
                setIconCount(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent){}
        });

        gallery.setSelection(getIntent().getIntExtra(ConstantValue.GALLERY_POSITION, 0));
    }

    private void setIconCount(int postion){
        if(postion > adapter.getCount()){
            postion = adapter.getCount();
        } else if(postion < 0){
            postion = 0;
        }
        String counts = String.format(Utils.getResString(R.string.icon_count), postion + 1, adapter.getCount());
        content.setText(counts);
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
    }

    private void initImageLoader(){
        imageLoader = ImageUtils.getImageLoader();
    }

    private List<String> getList(){
        final String[] selected_path = getIntent().getStringArrayExtra(Action.SELECTED_PATH);
        List<String> list = new ArrayList<String>();
        if(selected_path != null){
            Collections.addAll(list, selected_path);
        }

        return list;
    }

}