package com.cocobaby.teacher.activities;

import android.app.TabActivity;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabWidget;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.CheckNewJob;
import com.cocobaby.teacher.utils.Utils;

public class MainActivity extends TabActivity {
	private TabHost tabHost;
	private static String TAB_TAG_SETTING = "selfinfo";
	private static final String TAB_TAG_GROWTH = "growth";
	private static final String TAB_TAG_CHILDLIST = "childlist";
	private static final String TAB_TAG_NEWS = "news";
	private static final String[] TAB_TAGS = { TAB_TAG_CHILDLIST,
			TAB_TAG_GROWTH, TAB_TAG_NEWS, TAB_TAG_SETTING };
	private TabWidget tabWidget;
	private static final int TAB_WIDGET_HEIGHT = 100;
	private int[] labelIds = { R.string.children, R.string.growth,
			R.string.news, R.string.homework, R.string.selfinfo };

	private Handler handler;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.client_tab);
		initUI();
		initHandler();
		checkNew();
		initDirs();
	}

	private void initDirs() {
		Utils.makeDefaultDirInSDCard();
	}

	private void checkNew() {
		if (!Utils.isWiFiActive(this)) {
			Log.d("DDD", "wifi closed do nothing!");
			return;
		}
		long checkNewTime = Utils.getCheckNewTime();
		long currentTime = System.currentTimeMillis();
		if ((currentTime - checkNewTime) >= ConstantValue.CHECK_NEW_TIME_SPAN) {
			runCheckUpdateTask();
		}
	}

	private void initHandler() {
		handler = new MyHandler(this, null) {
			@Override
			public void handleMessage(Message msg) {
				if (MainActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.HAS_NEW_VERSION:
					DlgMgr.showTwoBtnResDlg(R.string.update_now,
							MainActivity.this, new OnClickListener() {
								@Override
								public void onClick(DialogInterface dialog,
										int which) {
									Utils.goNextActivity(MainActivity.this,
											UpdateActivity.class, false);
								}
							});
					break;
				default:
					break;
				}
			}

		};
	}

	private void runCheckUpdateTask() {
		Utils.saveCheckNewTime(System.currentTimeMillis());
		CheckNewJob checkNewJob = new CheckNewJob(handler,
				Utils.getVersionCode());
		checkNewJob.execute();
	}

	private void initUI() {
		tabHost = getTabHost();

		int[] iconIds = { R.drawable.growth, R.drawable.growth,
				R.drawable.growth, R.drawable.growth };
		Class<?>[] classes = { EntryActivity.class, SendExpActivity.class,
				NoticePullRefreshActivity.class, SelfInfoActivity.class };
		Resources res = this.getResources();
		for (int i = 0; i < TAB_TAGS.length; ++i) {
			View view = LayoutInflater.from(this).inflate(R.layout.tab_widget,
					null);
			TextView titleView = (TextView) view.findViewById(R.id.title);
			ImageView iconView = (ImageView) view.findViewById(R.id.icon);
			if (i == 0) {
				titleView.setTextColor(Color.BLACK);
			} else {
				titleView.setTextColor(Color.WHITE);
			}
			titleView.setText(res.getString(labelIds[i]));
			iconView.setBackgroundDrawable(res.getDrawable(iconIds[i]));
			appendIntentToTab(classes[i], TAB_TAGS[i], view);
		}

		// setTabWidgetParams();
		setTabChangedListener();
	}

	private void appendIntentToTab(Class<?> toActivity, String tabTag, View view) {
		tabHost.addTab(tabHost.newTabSpec(tabTag).setIndicator(view)
				.setContent(new Intent(MainActivity.this, toActivity)));
	}

	private void setTabWidgetParams() {
		tabWidget = getTabWidget();
		for (int i = 0; i < tabWidget.getChildCount(); i++) {
			// 设置高度、宽度，不过宽度由于设置为fill_parent，在此对它没效果
			tabWidget.getChildAt(i).getLayoutParams().height = TAB_WIDGET_HEIGHT;
		}
	}

	private void setTabChangedListener() {
		tabHost.setOnTabChangedListener(new OnTabChangeListener() {
			@Override
			public void onTabChanged(String tabId) {
				int id = tabHost.getCurrentTab();
				for (int i = 0; i < TAB_TAGS.length; ++i) {
					View view = tabHost.getTabWidget().getChildAt(i);
					TextView textview = (TextView) view
							.findViewById(R.id.title);
					if (i != id) {
						textview.setTextColor(Color.WHITE);
					} else {
						// setTabTitle(id);
						textview.setTextColor(Color.BLACK);
					}
				}
			}
		});
	}

}
