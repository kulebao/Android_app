package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.ExpListAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.DownloadImgeJob;
import com.cocobaby.teacher.taskmgr.GetExpJob;
import com.cocobaby.teacher.utils.Utils;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

public class ExpListActivity extends UmengStatisticsActivity {
	private static final int SEND_EXP = 10;
	private ProgressDialog dialog;
	private ExpListAdapter adapter;
	private Handler myhandler;

	private DownloadImgeJob downloadImgeJob;
	private PullToRefreshListView msgListView;
	private GetExpJob expJob;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.exp_list);
		initUI();
		initDialog();
		initHander();
		initCustomListView();
		loadNewData();
	}

	public void sendExp(View view) {
		Intent intent = new Intent();
		intent.setClass(this, SendExpActivity.class);
		startActivityForResult(intent, SEND_EXP);
	}

	private void initUI() {
		initDialog();
		// from topbar
		TextView topbarTitle = (TextView) findViewById(R.id.topbarTitle);
		topbarTitle.setVisibility(View.VISIBLE);
		topbarTitle.setText(R.string.history_record);
	}

	public void loadNewData() {
		dialog.show();
		refreshHead();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		// 这里自动更新一下记录
		loadNewData();
	}

	@Override
	protected void onRestart() {
		super.onRestart();
		Log.d("DJC", "onRestart ");
		adapter.notifyDataSetChanged();
	}

	@Override
	protected void onDestroy() {
		if (downloadImgeJob != null) {
			downloadImgeJob.stopTask();
		}

		if (adapter != null) {
			adapter.close();
		}
		super.onDestroy();
	}

	private void initHander() {
		myhandler = new MyHandler(this, dialog) {
			@Override
			public void handleMessage(Message msg) {
				if (ExpListActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				msgListView.onRefreshComplete();
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.GET_EXP_INFO_SUCCESS:
					handleGetExpInfoSuccess(msg);
					break;
				case EventType.GET_EXP_INFO_FAIL:
					Utils.makeToast(ExpListActivity.this, "获取成长经历失败！");
					break;
				default:
					break;
				}
			}
		};
	}

	protected void handleGetExpInfoSuccess(Message msg) {
		@SuppressWarnings("unchecked")
		List<ExpInfo> list = (List<ExpInfo>) msg.obj;

		if (!list.isEmpty()) {
			List<ExpInfo> explist = adapter.getData();
			if (msg.arg1 == ConstantValue.Type_INSERT_HEAD) {
				explist.addAll(0, list);
				List<ExpInfo> filterList = filter(explist, true);
				adapter.addAll(filterList);
			} else if (msg.arg1 == ConstantValue.Type_INSERT_TAIl) {
				explist.addAll(list);
				List<ExpInfo> filterList = filter(explist, false);
				adapter.addAll(filterList);
			} else {
				Log.e("DDD", "handleSuccess bad param arg1=" + msg.arg1);
			}
			adapter.notifyDataSetChanged();
		} else {
			Toast.makeText(this, R.string.no_more_exp, Toast.LENGTH_SHORT).show();
		}
	}

	// 传入的list是默认按照timestamp降序
	// 如果是插入头部，则不用改变，如果是插入尾部，则需先倒序，然后对获取到的列表再倒序，这样保证最后一条数据的id是最小的，再次获取
	// 时，不会获取到前面的重复数据
	private List<ExpInfo> filter(List<ExpInfo> list, boolean bHead) {
		List<ExpInfo> infos = new ArrayList<ExpInfo>();

		if (!bHead) {
			Collections.reverse(list);
		}

		outer: for (ExpInfo expInfo : list) {
			for (ExpInfo info : infos) {
				if (info.isSame(expInfo)) {
					continue outer;
				}
			}
			infos.add(expInfo);
		}

		if (!bHead) {
			Collections.reverse(infos);
		}

		return infos;
	}

	private void initCustomListView() {
		adapter = new ExpListAdapter(this);
		msgListView = (PullToRefreshListView) findViewById(R.id.explist);// 继承ListActivity，id要写成android.R.id.list，否则报异常
		msgListView.setMode(Mode.BOTH);
		setRefreshListener();
		msgListView.setAdapter(adapter);
		setItemClickListener();
	}

	private void setItemClickListener() {
		msgListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// 自定义listview headview占了一个，所以真实数据从1开始
				int currentIndex = position - 1;
				if (currentIndex >= adapter.getCount()) {
					// 当底部条出现时，index会大于count造成数组越界异常，这里处理一下
					return;
				}
			}
		});
	}

	private void setRefreshListener() {
		// Set a listener to be invoked when the list should be refreshed.
		msgListView.setOnRefreshListener(new OnRefreshListener2<ListView>() {
			/**
			 * onPullDownToRefresh will be called only when the user has Pulled
			 * from the start, and released.
			 */
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				// Do work to refresh the list here.
				refreshHead();
			}

			/**
			 * onPullUpToRefresh will be called only when the user has Pulled
			 * from the end, and released.
			 */
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				refreshTail();
			}
		});

	}

	private void refreshHead() {
		long from = 0;
		List<ExpInfo> explist = adapter.getData();
		if (!explist.isEmpty()) {
			try {
				from = explist.get(0).getTimestamp();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}

		Log.d("DDD", "refreshHead from=" + from);
		boolean runtask = runGetExpTask(from, 0, ConstantValue.Type_INSERT_HEAD);
		if (!runtask) {
			// 任务没有执行，立即去掉下拉显示
			msgListView.onRefreshComplete();
		} else {
			// Toast.makeText(NoticePullRefreshActivity.this, "Head Head Head!",
			// Toast.LENGTH_SHORT)
			// .show();
		}
	}

	private void refreshTail() {
		List<ExpInfo> explist = adapter.getData();
		long to = 0;
		if (!explist.isEmpty()) {
			try {
				to = explist.get(explist.size() - 1).getTimestamp();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}

		Log.d("djc", "refreshTail to=" + to);
		runGetExpTask(0, to, ConstantValue.Type_INSERT_TAIl);
	}

	private boolean runGetExpTask(long from, long to, int type) {
		boolean bret = true;
		if (expJob == null || expJob.isDone()) {
			// 获取成长经历可以多一点，因为肯定会有重复
			expJob = new GetExpJob(myhandler, ConstantValue.GET_EXP_MAX_COUNT, from, to, type);
			expJob.execute();
		} else {
			bret = false;
			Log.d("djc", "should not getNewsImpl task already running!");
		}
		return bret;
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.loading_data));
	}

}
