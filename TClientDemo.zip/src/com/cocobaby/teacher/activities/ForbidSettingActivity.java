package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ListView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.ForbidListAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.im.ForbidUser;
import com.cocobaby.teacher.pojo.ForbidInfo;
import com.cocobaby.teacher.taskmgr.ForbidUserJob;
import com.cocobaby.teacher.taskmgr.GetForbidUsersJob;
import com.cocobaby.teacher.taskmgr.UnForbidUserJob;
import com.cocobaby.teacher.utils.Utils;

public class ForbidSettingActivity extends UmengStatisticsActivity implements ForbidUser{

    private ForbidListAdapter adapter;
    private ListView          listView;
    private ProgressDialog    dialog;
    private Handler           myhandler;
    private String            classid;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.forbid_list);
        ActivityHelper.setTopbarTitle(this, R.string.forbidsetting);

        classid = getIntent().getStringExtra(ConstantValue.CLASS_ID);

        initDialog();
        initHander();
        initListAdapter();
        runGetForbidUsersTask();
    }

    private void initHander(){
        myhandler = new MyHandler(this, dialog){
            @Override
            public void handleMessage(Message msg){
                if(ForbidSettingActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }

                String userid = "";
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.GET_GROUP_FORBID_USERS_FAIL:
                        Utils.makeToast(ForbidSettingActivity.this, R.string.getForbidUsersFailed);
                        break;
                    case EventType.GET_GROUP_FORBID_USERS_SUCCESS:
                        @SuppressWarnings("unchecked")
                        List<ForbidInfo> list = (List<ForbidInfo>)msg.obj;
                        refreshList(list);
                        break;

                    case EventType.GROUP_UNFORBID_FAIL:
                        refreshList();
                        Utils.makeToast(ForbidSettingActivity.this, R.string.unforbiduserFailed);
                        break;
                    case EventType.GROUP_UNFORBID_SUCCESS:
                        userid = (String)msg.obj;
                        refreshList(userid, false);
                        Utils.makeToast(ForbidSettingActivity.this, R.string.unforbiduserSuccess);
                        break;

                    case EventType.GROUP_FORBID_FAIL:
                        refreshList();
                        Utils.makeToast(ForbidSettingActivity.this, R.string.forbiduserFailed);
                        break;
                    case EventType.GROUP_FORBID_SUCCESS:
                        userid = (String)msg.obj;
                        refreshList(userid, true);
                        Utils.makeToast(ForbidSettingActivity.this, R.string.forbiduserSuccess);
                        break;
                    default:
                        refreshList();
                        break;
                }
            }

        };
    }

    protected void refreshList(String userid, boolean bforbid){
        adapter.refresh(userid,bforbid);
    }

    protected void refreshList(){
        adapter.notifyDataSetChanged();
    }

    protected void refreshList(List<ForbidInfo> list){
        List<ForbidInfo> forbidInfos = DataMgr.getInstance().getForbidInfo(classid);

        for(ForbidInfo forbidInfo : list){

            for(ForbidInfo info : forbidInfos){
                if(info.equals(forbidInfo)){
                    info.setForbidden(true);
                }
            }
        }

        adapter.refresh(forbidInfos);
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
    }

    private void runGetForbidUsersTask(){
        dialog.setMessage(getResources().getString(R.string.getForbidUsers));
        dialog.show();
        GetForbidUsersJob job = new GetForbidUsersJob(myhandler, classid);
        job.execute();
    }

    private void initListAdapter(){
        List<ForbidInfo> listinfo = new ArrayList<ForbidInfo>();
        adapter = new ForbidListAdapter(this, listinfo, this);
        listView = (ListView)findViewById(R.id.forbid_list);
        listView.setAdapter(adapter);
    }

    @Override
    public void forbidUser(String userid, boolean forbid){
        dialog.show();

        if(forbid){
            dialog.setMessage(getResources().getString(R.string.forbiduser));
            ForbidUserJob forbidUserJob = new ForbidUserJob(myhandler, classid, userid);
            forbidUserJob.execute();
        } else{
            dialog.setMessage(getResources().getString(R.string.unforbiduser));
            UnForbidUserJob unForbidUserJob = new UnForbidUserJob(myhandler, classid, userid);
            unForbidUserJob.execute();
        }
    }

}
