package com.cocobaby.teacher.activities;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.customview.PointerPopupWindow;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.GetAllIneligibleClassesJob;
import com.cocobaby.teacher.taskmgr.SendNewsJob;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class SendNewsActivity extends UmengStatisticsActivity{
    private Handler              handler;
    private EditText             exp_content;
    private static final int     IMAGE_REQUEST_CODE  = 0;
    private static final int     CAMERA_REQUEST_CODE = 1;
    private Uri                  uri;
    private static final String  TMP_BMP             = "tmp_bmp.jpg";
    private Bitmap               resizedBmp          = null;
    private ImageView            news_pic;
    private Map<String, Integer> itemsMap            = new HashMap<String, Integer>();
    private String               ALL_SCHOOL          = "全校";
    private AlertDialog          choiceNoticeScopeDialog;
    private int                  choice              = 0;
    private EditText             exp_title;
    private ProgressDialog       dialog;
    private ImageView            feedbackView;
    private TextView             noticeTypeView;
    private String[]             typeItems           = new String[] { Utils.getResString(R.string.news),
            Utils.getResString(R.string.homework)   };

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_news);
        initUI();
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
    }

    private void initHandler(){
        handler = new MyHandler(this, dialog){
            @SuppressWarnings("unchecked")
            @Override
            public void handleMessage(Message msg){
                if(SendNewsActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }
                super.handleMessage(msg);
                switch(msg.what){
                    case EventType.SEND_NEWS_SUCCESS:
                        News news = (News)msg.obj;
                        HandleSendNewsSuccess(news);
                        break;
                    case EventType.SEND_NEWS_FAIL:
                        Utils.makeToast(SendNewsActivity.this, R.string.send_news_fail);
                        break;
                    // case EventType.GET_CLASSES_FAIL:
                    // showScopeDlg(new ArrayList<Integer>());
                    // break;
                    // case EventType.GET_CLASSES_SUCCESS:
                    // showScopeDlg((List<Integer>)msg.obj);
                    // break;
                    case EventType.WITHOUT_SCHOOL_NOTICE_PRIVILEGE:
                        showScopeDlg(false);
                        break;
                    case EventType.WITH_SCHOOL_NOTICE_PRIVILEGE:
                        showScopeDlg(true);
                        break;
                    default:
                        break;
                }
            }

        };
    }

    private void HandleSendNewsSuccess(News news){
        try{
            closeKeyBoard();
            if(resizedBmp != null){
                Utils.saveBitmapToSDCard(resizedBmp, news.getNewsLocalIconPath());
            }
            Utils.makeToast(SendNewsActivity.this, R.string.send_news_success);
            dialog.cancel();
            SendNewsActivity.this.setResult(Activity.RESULT_OK);
            SendNewsActivity.this.finish();
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    protected boolean checkContentValid(){
        if(TextUtils.isEmpty(exp_content.getText().toString().trim())){
            return false;
        }
        return true;
    }

    private void initUI(){
        initDialog();
        initHandler();
        initBtn();
        initChooseNoticeTypeBtn();

        exp_content = (EditText)findViewById(R.id.exp_content);
        exp_title = (EditText)findViewById(R.id.exp_title);
        news_pic = (ImageView)findViewById(R.id.news_pic);

        // initScopeDlg();

        ActivityHelper.setTopbarTitle(this, R.string.send_news);
    }

    private void initFeedbackBtn(){
        feedbackView = (ImageView)findViewById(R.id.feedback);
        feedbackView.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                feedbackView.setSelected(!feedbackView.isSelected());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != Activity.RESULT_OK){
            return;
        }

        switch(requestCode){
            case IMAGE_REQUEST_CODE:
                showPic(data);
                break;
            case CAMERA_REQUEST_CODE:
                resizedBmp = ImageDownloader.getResizedBmp(uri.getPath());
                news_pic.setImageBitmap(resizedBmp);
                break;

            default:
                break;
        }
    }

    private void showPic(Intent data){
        String path = data.getData().getPath();
        resizedBmp = parseBmp(data);
        news_pic.setImageBitmap(resizedBmp);
    }

    private AlertDialog createTypeDlg(int selectedID){

        return new AlertDialog.Builder(this).setTitle(R.string.choose_notice_type)
                .setSingleChoiceItems(typeItems, selectedID, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){
                        choice = whichButton;
                    }
                }).setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){
                        noticeTypeView.setText(typeItems[choice]);
                    }
                }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){}
                }).create();
    }

    private void showScopeDlg(boolean canSendSchoolNotice){
        final String[] items = getScopeItems(canSendSchoolNotice);
        choiceNoticeScopeDialog = new AlertDialog.Builder(this).setTitle(R.string.send_news_dest)
        // .setIconAttribute(android.R.attr.alertDialogIcon)
                .setSingleChoiceItems(items, 0, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){
                        choice = whichButton;
                    }
                }).setPositiveButton(R.string.confirm, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){
                        handSendNewsBtn(itemsMap.get(items[choice]));
                    }
                }).setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int whichButton){}
                }).create();

        choiceNoticeScopeDialog.show();
    }

    private String getTags(){
        if(!isNormalNotice()){
            return ConstantValue.TAGS_HOMEWORK;
        }

        return "";
    }

    protected void handSendNewsBtn(Integer classid){
        dialog.setMessage(getResources().getString(R.string.sending_news));
        dialog.show();

        News info = new News();
        info.setClass_id(classid);
        info.setContent(exp_content.getText().toString());
        info.setTitle(exp_title.getText().toString());
        info.setNeed_receipt(feedbackView.isSelected() ? 1 : 0);

        info.setTags(getTags());

        new SendNewsJob(handler, info, resizedBmp).execute();
    }

    protected boolean checkValid(){
        if(TextUtils.isEmpty(exp_title.getText())){
            Utils.makeToast(SendNewsActivity.this, R.string.news_title_invalid);
            return false;
        }

        if(TextUtils.isEmpty(exp_content.getText())){
            Utils.makeToast(SendNewsActivity.this, R.string.news_content_invalid);
            return false;
        }

        return true;
    }

    private String[] getScopeItems(boolean canSendSchoolNotice){
        itemsMap.clear();

        List<String> names = new ArrayList<String>();
        List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
        if(canSendSchoolNotice){
            itemsMap.put(ALL_SCHOOL, 0);
            names.add(ALL_SCHOOL);
        }

        for(ClassInfo classInfo : allClasses){
            itemsMap.put(classInfo.getClassName(), classInfo.getClassID());
            names.add(classInfo.getClassName());
        }
        return names.toArray(new String[names.size()]);
    }

    private boolean canSendSchoolNotice(List<Integer> list, List<ClassInfo> allClasses){
        if(allClasses.size() < list.size()){
            return false;
        }

        outer:
        for(Integer classid : list){

            for(ClassInfo classInfo : allClasses){
                if(classInfo.getClassID() == classid){
                    continue outer;
                }
            }

            return false;
        }

        return true;
    }

    private void chooseIconFromGallery(){
        Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
        galleryIntent.addCategory(Intent.CATEGORY_OPENABLE);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent, IMAGE_REQUEST_CODE);
    }

    private void chooseIconFromCamera(){
        uri = Uri.fromFile(new File(Utils.getSDCardFileDir(Utils.APP_DIR_TMP), TMP_BMP));
        Intent cameraIntent = new Intent("android.media.action.IMAGE_CAPTURE");
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        cameraIntent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        startActivityForResult(cameraIntent, CAMERA_REQUEST_CODE);
    }

    private void initBtn(){
        Button camera = (Button)findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(!Utils.isSdcardExisting()){
                    Toast.makeText(SendNewsActivity.this, "未找到存储卡，无法保存图片！", Toast.LENGTH_LONG).show();
                    return;
                }

                chooseIconFromCamera();
            }
        });

        Button gallery = (Button)findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                chooseIconFromGallery();
            }
        });

        Button sendto = (Button)findViewById(R.id.sendto);
        sendto.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                if(!checkValid()){
                    return;
                }

                dialog.setMessage(getResources().getString(R.string.get_all_class));
                dialog.show();

                GetAllIneligibleClassesJob getAllClassesJob = new GetAllIneligibleClassesJob(handler);
                getAllClassesJob.execute();
                // choiceNoticeScopeDialog.show();
            }
        });

        initFeedbackBtn();
    }

    private void initChooseNoticeTypeBtn(){
        noticeTypeView = (TextView)findViewById(R.id.noticeTypeView);
        noticeTypeView.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                // showChooseTypeDlg();
                showPopWindow();
            }
        });
    }

    private void showPopWindow(){
        // warning: you must specify the window width explicitly(do not use
        // WRAP_CONTENT or MATCH_PARENT)
        final PointerPopupWindow p = new PointerPopupWindow(this, getResources()
                .getDimensionPixelSize(R.dimen.popup_width_narrow));
        View convertView = LayoutInflater.from(this).inflate(R.layout.type_option, null);
        View notice = convertView.findViewById(R.id.notice);
        View homework = convertView.findViewById(R.id.homework);

        notice.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                p.dismiss();
                noticeTypeView.setText(typeItems[0]);
            }
        });

        homework.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                p.dismiss();
                noticeTypeView.setText(typeItems[1]);
            }
        });

        p.setContentView(convertView);
        p.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.blue)));
        p.setAlignMode(PointerPopupWindow.AlignMode.CENTER_FIX);
        p.showAsPointer(noticeTypeView);
    }

    protected void showChooseTypeDlg(){
        if(isNormalNotice()){
            createTypeDlg(0).show();
        } else{
            createTypeDlg(1).show();
        }
    }

    private boolean isNormalNotice(){
        return noticeTypeView.getText().toString().equals(Utils.getResString(R.string.news));
    }

    private Bitmap parseBmp(Intent data){
        Uri currentUri = data.getData();

        Bitmap bitmap = null;
        ContentResolver cr = this.getContentResolver();
        try{
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inJustDecodeBounds = true;
            BitmapFactory.decodeStream(cr.openInputStream(currentUri), null, options);
            options.inSampleSize = ImageDownloader.computeSampleSize(options, -1, ImageDownloader.getMaxPix());
            options.inJustDecodeBounds = false;

            bitmap = BitmapFactory.decodeStream(cr.openInputStream(currentUri), null, options);
        } catch(Exception e){
            e.printStackTrace();
        }

        return bitmap;
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if(resizedBmp != null){
            resizedBmp.recycle();
            resizedBmp = null;
        }
    }

    public void closeKeyBoard(){
        View view = getWindow().peekDecorView();
        if(view != null){
            InputMethodManager inputmanger = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            inputmanger.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }
}
