package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnChildClickListener;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.SimpleExpandAdapter;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.listdata.ChildFeedbackComparator;
import com.cocobaby.teacher.listdata.SimpleClassSummary;
import com.cocobaby.teacher.taskmgr.CheckFeedbackJob;
import com.cocobaby.teacher.utils.Utils;

public class UnFeedbackChildListActivity extends UmengStatisticsActivity {
	private ProgressDialog dialog;
	private News news;
	private Handler handler;
	private SimpleExpandAdapter adapter;
	// private ListView list;
	private List<SimpleClassSummary> list = new ArrayList<SimpleClassSummary>();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.unfeedback_child_list);

		ActivityHelper.setTopbarTitle(this, "回执列表");

		int noticeId = getIntent()
				.getIntExtra(JSONConstant.NOTIFICATION_ID, -1);
		news = DataMgr.getInstance().getNewsByID(noticeId);

		if (news == null) {
			return;
		}

		initUI();
		initHandler();
		runChceckTask();
	}

	private void initListAdapter() {
		adapter = new SimpleExpandAdapter(this, list);
		ExpandableListView ExpandableListView = (ExpandableListView) findViewById(R.id.expandList);
		ExpandableListView.setAdapter(adapter);
		ExpandableListView.setOnChildClickListener(new OnChildClickListener() {

			@Override
			public boolean onChildClick(ExpandableListView parent, View v,
					int groupPosition, int childPosition, long id) {
				String current_selected_childid = list.get(groupPosition)
						.getChildList().get(childPosition).getServerID();
				startToChildDetailActivity(current_selected_childid);
				return false;
			}
		});
	}

	private void startToChildDetailActivity(String childid) {
		Intent intent = new Intent();
		intent.putExtra(JSONConstant.CHILD_ID, childid);
		intent.setClass(this, ChildDetailActivity.class);
		startActivity(intent);
	}

	private void initHandler() {
		handler = new MyHandler(this, dialog) {
			@Override
			public void handleMessage(Message msg) {
				if (UnFeedbackChildListActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.CHECK_FEEDBACK_FAILED:
					Utils.makeToast(UnFeedbackChildListActivity.this,
							R.string.check_feedback_failed);
					break;
				case EventType.CHECK_FEEDBACK_SUCESS:
					@SuppressWarnings("unchecked")
					List<ParentInfo> parentInfos = (List<ParentInfo>) msg.obj;
					showChildList(parentInfos);
					break;
				default:
					break;
				}
			}

		};
	}

	protected void showChildList(List<ParentInfo> parentInfos) {
		int class_id = news.getClass_id();
		// class_id==0 表示是全校公告
		if (class_id == 0) {
			List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();

			for (ClassInfo info : allClasses) {
				SimpleClassSummary summary = new SimpleClassSummary();
				summary.setInfo(info);
				list.add(summary);
			}

			for (SimpleClassSummary summary : list) {
				List<ChildInfo> childInfos = DataMgr.getInstance()
						.getChildByClass(summary.getInfo().getClassID());
				updateFeedbackStatus(parentInfos, childInfos);
				Collections.sort(childInfos, new ChildFeedbackComparator());
				summary.setChildList(childInfos);
			}

		} else {
			List<ChildInfo> childByClass = DataMgr.getInstance()
					.getChildByClass(class_id);
			updateFeedbackStatus(parentInfos, childByClass);

			SimpleClassSummary summary = new SimpleClassSummary();
			ClassInfo info = DataMgr.getInstance().getClassByID(class_id);
			summary.setInfo(info);
			summary.setChildList(childByClass);
			Collections.sort(childByClass, new ChildFeedbackComparator());
			list.add(summary);
		}

		// adapter.setList(unFeedBackChildList);
		adapter.notifyDataSetChanged();
	}

	private void updateFeedbackStatus(List<ParentInfo> parentInfos,
			List<ChildInfo> allChild) {
		if (parentInfos.isEmpty()) {
			return;
		}

		outer: for (ChildInfo childInfo : allChild) {
			List<String> parentIDsByChildId = DataMgr.getInstance()
					.getParentIDsByChildId(childInfo.getServerID());

			for (String pID : parentIDsByChildId) {
				for (ParentInfo parentInfo : parentInfos) {
					if (parentInfo.getParent_id().equals(pID)) {
						childInfo.setFeedback(true);
						// 小孩所属家长可能不止一个，任何一个与回执家长的id相同，认为小孩家长已经回执
						continue outer;
					}
				}
			}
		}

	}

	private List<ChildInfo> getUnFeedBackChildList(
			List<ParentInfo> parentInfos, List<ChildInfo> allChild) {
		if (parentInfos.isEmpty()) {
			return allChild;
		}

		List<ChildInfo> unFeedBackChildList = new ArrayList<ChildInfo>();

		outer: for (ChildInfo childInfo : allChild) {
			List<String> parentIDsByChildId = DataMgr.getInstance()
					.getParentIDsByChildId(childInfo.getServerID());

			for (String pID : parentIDsByChildId) {
				for (ParentInfo parentInfo : parentInfos) {
					if (parentInfo.getParent_id().equals(pID)) {
						// 小孩所属家长可能不止一个，任何一个与回执家长的id相同，认为小孩家长已经回执
						continue outer;
					}
				}
			}
			// 小孩所属家长id不在已回执的列表里，加入未回执小孩列表
			unFeedBackChildList.add(childInfo);
		}

		return unFeedBackChildList;
	}

	private void initUI() {
		initDialog();
		initListAdapter();
	}

	private void runChceckTask() {
		dialog.show();
		CheckFeedbackJob checkFeedbackJob = new CheckFeedbackJob(handler,
				news.getNews_server_id());
		checkFeedbackJob.execute();
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.checking_feedback));
	}
}
