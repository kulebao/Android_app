/*
 * Copyright (C) 2007 The Android Open Source Project Licensed under the Apache
 * License, Version 2.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.apache.org/licenses/LICENSE-2.0 Unless required by applicable law
 * or agreed to in writing, software distributed under the License is
 * distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

package com.cocobaby.teacher.activities;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.EstimateInfo;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.GetEstimateJob;
import com.cocobaby.teacher.taskmgr.MultiPostEstimateJob;
import com.cocobaby.teacher.taskmgr.PostEstimateJob;
import com.cocobaby.teacher.utils.Utils;

/**
 * Demonstrates how to use a rating bar
 */
public class EstimateActivity extends Activity implements RatingBar.OnRatingBarChangeListener{
    RatingBar              mSmallRatingBar;
    RatingBar              mIndicatorRatingBar = null;
    TextView               mRatingText;
    private RatingBar      manner;
    private RatingBar      activity;
    private RatingBar      exercise;
    private RatingBar      game;
    private RatingBar      self_care;
    private RatingBar      dining;
    private RatingBar      emotion;
    private RatingBar      rest;
    private Handler        handler;
    private String         childid;
    private TextView       lastEstimate;
    private EditText       currentEstimate;
    private ProgressDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.estimate);
        childid = getIntent().getStringExtra(JSONConstant.CHILD_ID);
        initDialog();
        initHandler();
        initUI();
        runGetEstimateJob();
    }

    private void initDialog(){
        dialog = new ProgressDialog(this);
        dialog.setCancelable(false);
        dialog.setMessage(getResources().getString(R.string.estimating));
    }

    private void runGetEstimateJob(){
        GetEstimateJob job = new GetEstimateJob(handler, 0, 0, 1, childid);
        job.execute();
    }

    // 一次性向多个小孩发评价
    private void runMultiPostEstimateJob(){
        dialog.show();
        List<String> childIDs = new ArrayList<String>();
        childIDs.add(childid);

        EstimateInfo info = new EstimateInfo();
        info.setComments(currentEstimate.getEditableText().toString());
        info.setManner((int)manner.getRating());
        info.setActivity((int)activity.getRating());
        info.setExercise((int)exercise.getRating());
        info.setGame((int)game.getRating());
        info.setRest((int)rest.getRating());
        info.setSelf_care((int)self_care.getRating());
        info.setEmotion((int)emotion.getRating());

        MultiPostEstimateJob job = new MultiPostEstimateJob(handler, childIDs, info);
        job.execute();
    }

    private void runPostEstimateJob(){
        dialog.show();

        EstimateInfo info = new EstimateInfo();
        info.setComments(currentEstimate.getEditableText().toString());
        info.setManner((int)manner.getRating());
        info.setActivity((int)activity.getRating());
        info.setExercise((int)exercise.getRating());
        info.setGame((int)game.getRating());
        info.setRest((int)rest.getRating());
        info.setSelf_care((int)self_care.getRating());
        info.setEmotion((int)emotion.getRating());
        info.setDining((int)dining.getRating());
        info.setChild_id(childid);

        PostEstimateJob job = new PostEstimateJob(handler, info);
        job.execute();
    }

    private void initHandler(){
        handler = new MyHandler(this, dialog){
            @Override
            public void handleMessage(Message msg){
                if(EstimateActivity.this.isFinishing()){
                    Log.w("djc", "do nothing when activity finishing!");
                    return;
                }
                super.handleMessage(msg);

                switch(msg.what){
                    case EventType.GET_ESTIMATE_SUCCESS:
                        handleGetEstimateSuccess();
                        break;
                    case EventType.GET_ESTIMATE_FAIL:
                        Utils.makeToast(EstimateActivity.this, R.string.get_estimate_fail);
                        break;
                    case EventType.POST_ESTIMATE_SUCCESS:
                        handlePostEstimateSuccess();
                        break;
                    case EventType.POST_ESTIMATE_FAIL:
                        handlePostEstimateFail();
                        break;
                    default:
                        break;
                }
            }
        };
    }

    protected void handlePostEstimateFail(){
        Utils.makeToast(EstimateActivity.this, R.string.post_estimate_fail);
    }

    private void handlePostEstimateSuccess(){
        Utils.makeToast(EstimateActivity.this, R.string.post_estimate_success);
        lastEstimate.setText(DataMgr.getInstance().getLastEstimate(childid).toString());
        currentEstimate.setText("");
    }

    private void handleGetEstimateSuccess(){
        EstimateInfo estimateInfo = DataMgr.getInstance().getLastEstimate(childid);
        if(estimateInfo == null){
            Utils.makeToast(this, R.string.no_estimate);
        } else{
            lastEstimate.setText(estimateInfo.toString());
        }
    }

    private void initHeader(){
        TextView cancel = (TextView)findViewById(R.id.leftBtn);
        cancel.setText(R.string.back);
        cancel.setVisibility(View.VISIBLE);
        cancel.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });
        ActivityHelper.setTopbarTitle(this, R.string.estimate);

        TextView refresh = (TextView)findViewById(R.id.rightBtn);
        refresh.setVisibility(View.VISIBLE);
        refresh.setText(R.string.send);
        refresh.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v){
                handleSendBtn();
            }
        });
    }

    private void initUI(){
        initHeader();
        initLastEstimate();

        currentEstimate = (EditText)findViewById(R.id.currentEstimate);

        Button send = (Button)findViewById(R.id.send);
        send.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                handleSendBtn();
            }
        });

        initRatingbar();
    }

    private void initLastEstimate(){
        lastEstimate = (TextView)findViewById(R.id.lastEstimate);
        EstimateInfo info = DataMgr.getInstance().getLastEstimate(childid);
        if(info != null){
            lastEstimate.setText(info.toString());
        }
    }

    private void handleSendBtn(){
        if(TextUtils.isEmpty(currentEstimate.getEditableText().toString())){
            Utils.makeToast(this, R.string.estimate_invalid);
            return;
        }
        runPostEstimateJob();
    }

    private void initRatingbar(){
        manner = (RatingBar)findViewById(R.id.manner);
        manner.setOnRatingBarChangeListener(this);

        activity = (RatingBar)findViewById(R.id.activity);
        activity.setOnRatingBarChangeListener(this);

        game = (RatingBar)findViewById(R.id.game);
        game.setOnRatingBarChangeListener(this);

        exercise = (RatingBar)findViewById(R.id.exercise);
        exercise.setOnRatingBarChangeListener(this);

        self_care = (RatingBar)findViewById(R.id.self_care);
        self_care.setOnRatingBarChangeListener(this);

        dining = (RatingBar)findViewById(R.id.dining);
        dining.setOnRatingBarChangeListener(this);

        emotion = (RatingBar)findViewById(R.id.emotion);
        emotion.setOnRatingBarChangeListener(this);

        rest = (RatingBar)findViewById(R.id.rest);
        rest.setOnRatingBarChangeListener(this);
    }

    public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromTouch){
        if(rating < 1){
            ratingBar.setRating(1);
        }
    }

}
