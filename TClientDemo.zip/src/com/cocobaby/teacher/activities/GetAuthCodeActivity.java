package com.cocobaby.teacher.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.AuthCodeCountDownJob;
import com.cocobaby.teacher.taskmgr.GetAuthCodeJob;
import com.cocobaby.teacher.utils.Utils;

public class GetAuthCodeActivity extends UmengStatisticsActivity {
	private static final int RESET_PWD = 1;
	private Handler handler;
	private Button getAuthCodeBtn;
	private ProgressDialog dialog;
	private AuthCodeCountDownJob authCodeCountDownJob;
	private EditText inputphone;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.get_auth_code);
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		initHandler();
		initView();
	}

	private void handleCountDownGo(int second) {
		getAuthCodeBtn.setText(String.format(
				getResources().getString(R.string.getAuthCodeCountDown),
				String.valueOf(second)));
	}

	private void initHandler() {
		handler = new MyHandler(this, dialog) {

			@Override
			public void handleMessage(Message msg) {
				if (GetAuthCodeActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				Log.w("DDDDDD", "ResetPWDActivity event =" + msg.what);
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.GET_AUTH_CODE_SUCCESS:
					Utils.makeToast(GetAuthCodeActivity.this,
							R.string.getAuthCodeSuccess);
					runAuthCodeCountDownTask();
					break;
				case EventType.GET_AUTH_CODE_FAIL:
					DlgMgr.showSingleBtnResDlg(R.string.get_auth_code_fail,
							GetAuthCodeActivity.this);
					enableGetAuthBtn();
					break;
				case EventType.GET_AUTH_CODE_TOO_OFTEN:
					DlgMgr.showSingleBtnResDlg(
							R.string.get_auth_code_too_often,
							GetAuthCodeActivity.this);
					enableGetAuthBtn();
					break;

				case EventType.AUTHCODE_COUNTDOWN_GO:
					handleCountDownGo(msg.arg1);
					break;

				case EventType.AUTHCODE_COUNTDOWN_OVER:
					handleCountDownOver();
					break;
				default:
					break;
				}
			}

		};
	}

	private void initView() {
		inputphone = (EditText) findViewById(R.id.inuputphoneView);

		getAuthCodeBtn = (Button) findViewById(R.id.getAuthCodeBtn);
		getAuthCodeBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (!Utils.checkPhoneNum(inputphone.getText().toString())) {
					DlgMgr.showSingleBtnResDlg(R.string.phone_format_error,
							GetAuthCodeActivity.this);
					return;
				}
				disableGetAuthBtn();
				runGetAuthCodeTask();
			}

		});

		Button nextStepBtn = (Button) findViewById(R.id.next_step);
		nextStepBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startToResetPwdActivity();
			}

		});

	}

	protected void startToResetPwdActivity() {
		Intent intent = new Intent(this, ResetPWDActivity.class);
		startActivityForResult(intent, RESET_PWD);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (resultCode != RESULT_OK) {
			return;
		}
		switch (requestCode) {
		case RESET_PWD:
			// 重置成功，关闭自己
			finish();
			break;

		default:
			break;
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	private void disableGetAuthBtn() {
		// getAuthCodeBtn.setTextColor(getResources().getColor(R.color.dark_gray));
		getAuthCodeBtn.setBackgroundResource(R.drawable.btn_gray);
		getAuthCodeBtn.setEnabled(false);
	}

	private void enableGetAuthBtn() {
		getAuthCodeBtn.setEnabled(true);
		getAuthCodeBtn.setBackgroundResource(R.drawable.btn_sel);
		// getAuthCodeBtn.setTextColor(getResources().getColor(R.color.white));
	}

	private void runGetAuthCodeTask() {
		dialog.setMessage(getResources().getString(R.string.getting_auth_code));
		dialog.show();
		new GetAuthCodeJob(handler, inputphone.getText().toString()).execute();
	}

	private void runAuthCodeCountDownTask() {
		authCodeCountDownJob = new AuthCodeCountDownJob(handler,
				ConstantValue.TIME_LIMIT_TO_GET_AUTHCODE_AGAIN);
		authCodeCountDownJob.execute();
	}

	private void handleCountDownOver() {
		getAuthCodeBtn.setText(getResources().getString(R.string.getAuthCode));
		enableGetAuthBtn();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		if (authCodeCountDownJob != null) {
			authCodeCountDownJob.cancel(true);
		}
	}

}
