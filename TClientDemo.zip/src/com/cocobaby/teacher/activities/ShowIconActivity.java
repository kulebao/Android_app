package com.cocobaby.teacher.activities;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.widget.ImageView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.utils.ImageUtils;

public class ShowIconActivity extends UmengStatisticsActivity {

	private Bitmap bitmap;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.show_icon);
		showIcon();
	}

	private void showIcon() {
		ImageView image = (ImageView) findViewById(R.id.imageview);
		String path = getIntent().getStringExtra(ConstantValue.LOCAL_URL);

		ImageUtils.getImageLoader().displayImage("file://" + path, image);

		// int maxPixel = ImageDownloader.getMaxPix();
		//
		// bitmap = ImageDownloader.getResizedBmp(maxPixel, path);
		// image.setImageBitmap(bitmap);
	}

	@Override
	protected void onDestroy() {
		if (bitmap != null) {
			bitmap.recycle();
		}
		super.onDestroy();
	}

}
