package com.cocobaby.teacher.activities;

import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.media.MediaScannerConnection.MediaScannerConnectionClient;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.GalleryAdapter;
import com.cocobaby.teacher.constant.Action;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.customview.CustomGallery;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.utils.DataUtils;
import com.cocobaby.teacher.utils.ImageUtils;
import com.cocobaby.teacher.utils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;

public class SendExpActivity extends UmengStatisticsActivity{
    private static final int       VIDEO_RECORD = 0;
    private static final int       VIDEO_FILE   = 1;

    private GridView               gridGallery;
    private GalleryAdapter         adapter;
    private ViewSwitcher           viewSwitcher;
    private ImageLoader            imageLoader;
    private Uri                    uri;
    private EditText               exp_content;
    private MediaScannerConnection msc;

    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.send_exp);
        msc = new MediaScannerConnection(this, new MyPicMediaScannerConnectionClient());
        initImageLoader();
        initUI();
    }

    private void initImageLoader(){
        imageLoader = ImageUtils.getImageLoader();
    }

    private void initHeader(){
        TextView cancel = (TextView)findViewById(R.id.leftBtn);
        cancel.setText(R.string.back);
        cancel.setVisibility(View.VISIBLE);
        cancel.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                finish();
            }
        });
    }

    protected boolean checkContentValid(){
        if(TextUtils.isEmpty(exp_content.getText().toString().trim()) && adapter.getCount() == 0){
            return false;
        }
        return true;
    }

    protected void startToChooseExpReceiverActivity(){
        Intent intent = new Intent();
        List<CustomGallery> list = adapter.getData();
        if(!list.isEmpty()){
            List<String> ids = new ArrayList<String>();
            for(CustomGallery gallery : list){
                ids.add(gallery.getSdcardPath());
            }
            intent.putExtra(Action.ALL_MEDIUM, ids.toArray(new String[ids.size()]));
        }
        intent.putExtra(Action.MEDIUM_TYPE, JSONConstant.IMAGE_TYPE);
        intent.putExtra(Action.EXP_TEXT, exp_content.getText().toString());
        intent.setClass(this, ChooseExpReceiverActivity.class);
        startActivityForResult(intent, Action.SEND_TO);
    }

    private void initUI(){
        initHeader();
        exp_content = (EditText)findViewById(R.id.exp_content);
        gridGallery = (GridView)findViewById(R.id.gridGallery);
        gridGallery.setFastScrollEnabled(true);
        adapter = new GalleryAdapter(getApplicationContext(), imageLoader);
        adapter.setMultiplePick(false);
        gridGallery.setAdapter(adapter);

        gridGallery.setOnItemClickListener(new OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id){
                Log.d("DDD", "gridGallery onItemClick position=" + position);
                startToSlideGalleryActivity(position);
            }
        });

        viewSwitcher = (ViewSwitcher)findViewById(R.id.viewSwitcher);
        viewSwitcher.setDisplayedChild(1);
        initBtn();

        ActivityHelper.setTopbarTitle(this, R.string.growth);
    }

    // 添加视频到系统文件路径，从系统视频中可以选择播放
    private void AddVideoToSys(String path){
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        mediaScanIntent.setData(Uri.fromFile(new File(path)));
        this.sendBroadcast(mediaScanIntent);
    }

    // 将拍照后保存的照片加入到图库,速度快
    private void galleryAddPicExt(){
        msc.connect();
    }

    protected void startToSlideGalleryActivity(int position){
        Intent intent = new Intent(this, SlideGalleryActivity.class);
        List<String> allSelectedPath = adapter.getAllSelectedPath();
        if(!allSelectedPath.isEmpty()){
            intent.putExtra(Action.SELECTED_PATH, allSelectedPath.toArray(new String[allSelectedPath.size()]));
        }
        intent.putExtra(ConstantValue.GALLERY_POSITION, position);
        intent.putExtra(ConstantValue.GALLERY_SEND, true);
        startActivityForResult(intent, Action.SELECT_SLIDE_GALLERY);
    }

    private void initBtn(){
        Button camera = (Button)findViewById(R.id.camera);
        camera.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(!Utils.isSdcardExisting()){
                    Toast.makeText(SendExpActivity.this, "未找到存储卡，无法保存图片！", Toast.LENGTH_LONG).show();
                    return;
                }

                if(adapter.checkMaxIconSelected()){
                    return;
                }

                chooseIconFromCamera();
            }
        });

        Button gallery = (Button)findViewById(R.id.gallery);
        gallery.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                Intent i = new Intent(Action.ACTION_MULTIPLE_PICK);
                List<String> allSelectedPath = adapter.getAllSelectedPath();
                if(!allSelectedPath.isEmpty()){
                    i.putExtra(Action.SELECTED_PATH, allSelectedPath.toArray(new String[allSelectedPath.size()]));
                }
                startActivityForResult(i, Action.SELECT_GALLERY);
            }
        });

        Button sendto = (Button)findViewById(R.id.sendto);
        sendto.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                if(!checkContentValid()){
                    Utils.makeToast(SendExpActivity.this, R.string.invalid_exp_content);
                    return;
                }
                closeKeyBoard();
                startToChooseExpReceiverActivity();
            }
        });

        Button video = (Button)findViewById(R.id.video);
        video.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){
                DlgMgr.getListDialog(SendExpActivity.this, R.array.video_choose, new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialog, int which){
                        Log.d("initTitle ddd", "which =" + which);
                        handleClick(which);
                    }
                }).create().show();
            }
        });
    }

    private void handleClick(int which){
        switch(which){
            case VIDEO_RECORD:
                RecordVideo();
                break;
            case VIDEO_FILE:
                chooseVideoFile();
                break;
            default:
                break;
        }
    }

    private void chooseVideoFile(){
        Intent i = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setType("video/*");
        startActivityForResult(i, Action.SELECT_VIDEO_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);

        if(resultCode != Activity.RESULT_OK){
            return;
        }

        switch(requestCode){
            case Action.SELECT_CAMERA:
                handleTakePicSuccess();
                break;
            case Action.SELECT_GALLERY:
                String[] all_path = data.getStringArrayExtra(Action.ALL_PATH);
                Log.d("DJC", "path aaa =" + all_path[0]);
                changeView(all_path);
                break;
            case Action.SELECT_SLIDE_GALLERY:
                String[] changed_array = data.getStringArrayExtra(Action.PATH_AFTER_CHANGE);
                changeView(changed_array);
                break;
            case Action.SEND_TO:
                clearAllContent();
                break;
            case Action.SELECT_VIDEO_FILE:
                handleVideoFile(data);
                break;
            case Action.VIDEO_CAPTURE_SYS:
                handleVideoFile(data);
                break;
            case Action.VIDEO_CAPTURE_SELF:
                handleRecordVideoBySelf(data);
                break;

            default:
                break;
        }
    }

    private void handleRecordVideoBySelf(Intent data){
        String videoUrl = data.getStringExtra(ConstantValue.RECORD_FILE_NAME);
        AddVideoToSys(videoUrl);

        File file = new File(videoUrl);

        long size = file.length();

        showSize(size);

        startToSendVideo(videoUrl, size);
    }

    // for test
    private void showSize(long size){
        DecimalFormat format = new DecimalFormat("#.00");
        double rSize = size / (1024.0f * 1024.0f);
        Utils.makeToast(this, format.format(rSize) + "m");
    }

    private void handleVideoFile(Intent data){
        String path = DataUtils.getPathByIntent(data);
        File file = new File(path);

        if(!isValidSize(file.length())){
            DlgMgr.showSingleBtnResDlg(R.string.video_invalid, SendExpActivity.this);
            return;
        }

        startToSendVideo(path, file.length());
    }

    private void startToSendVideo(String url, long size){
        Intent intent = new Intent(SendExpActivity.this, ShowVideoActivity.class);
        intent.putExtra(Action.VIDEO_URL, url);
        intent.putExtra(Action.VIDEO_SIZE, size);
        intent.putExtra(Action.EXP_TEXT, exp_content.getText().toString());

        startActivity(intent);
    }

    private boolean isValidSize(long size){
        return (double)size < 5.0 * 1024.0 * 1024.0;
    }

    private void clearAllContent(){
        exp_content.setText("");
        adapter.clearCache();
        adapter.clear();
    }

    private void handleTakePicSuccess(){
        // galleryAddPic();
        galleryAddPicExt();
        CustomGallery gallery = new CustomGallery();
        Log.d("DJC", "path bbb=" + uri.getPath());
        gallery.setSdcardPath(uri.getPath());
        gallery.setSeleted(true);
        viewSwitcher.setDisplayedChild(0);
        adapter.insert(gallery);
    }

    private void RecordVideo(){
        Intent intent = new Intent(this, RecordVideoActivity.class);
        startActivityForResult(intent, Action.VIDEO_CAPTURE_SELF);
    }

    // 调用系统
    private void RecordVideoBySys(){
        Intent intent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        // 设置了下面这个参数后，系统摄像头就无法选择画质了，1表示高清，0表示低分辨率
        intent.putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 0);
        // 设置最大录像时间，单位秒
        intent.putExtra(MediaStore.EXTRA_DURATION_LIMIT, 60);
        intent.putExtra(MediaStore.EXTRA_SIZE_LIMIT, 5 * 1024 * 1024);

        // ur = Environment.getExternalStorageDirectory().getPath() +
        // "/Test_Movie.m4v";
        // File file = new File(ur);
        //
        // Uri uri = Uri.fromFile(file);
        //
        // Log.d("DDD", "path =" + uri.getPath());
        // intent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        // 指定录像文件最大尺寸，单位字节
        startActivityForResult(intent, Action.VIDEO_CAPTURE_SYS);
    }

    private void chooseIconFromCamera(){
        File file = getFile();
        uri = Uri.fromFile(file);
        Log.d("DJC", "path =" + uri.getPath());
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, uri);
        startActivityForResult(cameraIntent, Action.SELECT_CAMERA);
    }

    private File getFile(){
        String path = Utils.getDefaultCameraDir();
        SimpleDateFormat format = new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss", Locale.CHINESE);
        String timestr = format.format(new Date());
        File file = new File(path, timestr + ".jpg");
        try{
            file.createNewFile();
        } catch(IOException e){
            e.printStackTrace();
        }
        return file;
    }

    private void changeView(String[] all_path){
        ArrayList<CustomGallery> dataT = new ArrayList<CustomGallery>();

        for(String string : all_path){
            CustomGallery customGallery = new CustomGallery();
            customGallery.setSdcardPath(string);
            customGallery.setSeleted(true);
            dataT.add(customGallery);
        }

        viewSwitcher.setDisplayedChild(0);
        adapter.addAll(dataT);
    }

    public void closeKeyBoard(){
        View view = getWindow().peekDecorView();
        if(view != null){
            InputMethodManager inputmanger = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            inputmanger.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    @Override
    protected void onDestroy(){
        adapter.clearCache();
        super.onDestroy();
    }

    private class MyPicMediaScannerConnectionClient implements MediaScannerConnectionClient{

        @Override
        public void onMediaScannerConnected(){
            Log.d("DDD", "onMediaScannerConnected");
            msc.scanFile(uri.getPath(), "image/jpeg");
        }

        @Override
        public void onScanCompleted(String path, Uri uri){
            Log.d("DDD", "onScanCompleted");
            msc.disconnect();
        }

    }

}
