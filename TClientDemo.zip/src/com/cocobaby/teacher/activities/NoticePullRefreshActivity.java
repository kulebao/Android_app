package com.cocobaby.teacher.activities;

import java.util.Iterator;
import java.util.List;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.adapter.NewsListAdapter;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.GetNewsJob;
import com.cocobaby.teacher.utils.Utils;
import com.handmark.pulltorefresh.library.PullToRefreshBase;
import com.handmark.pulltorefresh.library.PullToRefreshBase.Mode;
import com.handmark.pulltorefresh.library.PullToRefreshBase.OnRefreshListener2;
import com.handmark.pulltorefresh.library.PullToRefreshListView;

public class NoticePullRefreshActivity extends UmengStatisticsActivity {
	private static final int START_SEND_NEWS = 0;
	private static final int START_NOTICE_DETAIL = 10;
	private NewsListAdapter adapter;
	private PullToRefreshListView msgListView;
	private Handler myhandler;
	private GetNewsJob getNewsJob;
	private List<News> newsList;
	private ProgressDialog dialog;
	private int currentNewID;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notice_pull_refresh_list);
		initHeader();
		initDialog();
		initHander();
		initCustomListView();
		loadNewData();
	}

	private void initHeader() {
		TextView refresh = (TextView) findViewById(R.id.rightBtn);
		refresh.setText(R.string.send_news);
		refresh.setVisibility(View.VISIBLE);
		refresh.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(NoticePullRefreshActivity.this, SendNewsActivity.class);
				startActivityForResult(intent, START_SEND_NEWS);
			}
		});

		TextView back = (TextView) findViewById(R.id.leftBtn);
		back.setText(R.string.back);
		back.setVisibility(View.VISIBLE);
		back.setOnClickListener(new android.view.View.OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
	}

	public void loadNewData() {
		dialog.show();
		refreshHead();
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.loading_data));
	}

	private boolean runGetNoticeTask(long from, long to, int type) {
		boolean bret = true;
		if (getNewsJob == null || getNewsJob.isDone()) {
			getNewsJob = new GetNewsJob(myhandler, ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT, from, to, type);
			getNewsJob.execute();
		} else {
			bret = false;
			Log.d("djc", "should not getNewsImpl task already running!");
		}
		return bret;
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
		// 最多保存最新的25条通知
		adapter.close();
	}

	@Override
	public void onResume() {
		super.onResume();
		if (adapter != null) {
			adapter.notifyDataSetChanged();
		}
	}

	private void initHander() {
		myhandler = new MyHandler(this, dialog) {
			@Override
			public void handleMessage(Message msg) {
				msgListView.onRefreshComplete();
				if (NoticePullRefreshActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.GET_NEWS_SUCCESS:
					// Toast.makeText(NoticePullRefreshActivity.this,
					// "get suceess!", Toast.LENGTH_SHORT).show();
					handleSuccess(msg);
					break;
				case EventType.GET_NEWS_FAIL:
					Utils.makeToast(NoticePullRefreshActivity.this, "获取公告消息失败");
					break;
				default:
					break;
				}
			}
		};
	}

	protected void handleSuccess(Message msg) {
		@SuppressWarnings("unchecked")
		List<News> list = (List<News>) msg.obj;
		if (!list.isEmpty()) {
			// 刷出新公告了，去掉有新公告的标志
			Utils.saveProp(ConstantValue.HAVE_NEWS_NOTICE, "false");
			if (msg.arg1 == ConstantValue.Type_INSERT_HEAD) {
				addToHead(list);
			} else if (msg.arg1 == ConstantValue.Type_INSERT_TAIl) {
				// 旧数据不保存数据库
				newsList.addAll(list);
			} else {
				Log.e("DDD", "handleSuccess bad param arg1=" + msg.arg1);
			}
			adapter.notifyDataSetChanged();
		} else {
			Toast.makeText(this, R.string.no_more_news, Toast.LENGTH_SHORT).show();
		}
	}

	private void addToHead(List<News> list) {
		// 如果大于等于25条，就说明很可能还有公告没有一次性获取完，为了获取
		// 到连续的公告数据，避免排序和获取复杂化，在界面上删除旧的全部公告，只保留最新的25条
		if (list.size() >= ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT) {
			newsList.clear();
		}

		newsList.addAll(0, list);
	}

	private void initCustomListView() {
		newsList = DataMgr.getInstance().getNewsByType(JSONConstant.NOTICE_TYPE_NORMAL,
				ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT);
		adapter = new NewsListAdapter(this, newsList);
		msgListView = (PullToRefreshListView) findViewById(R.id.noticelist);// 继承ListActivity，id要写成android.R.id.list，否则报异常
		msgListView.setMode(Mode.BOTH);
		setRefreshListener();
		msgListView.setAdapter(adapter);
		setItemClickListener();
	}

	private void setRefreshListener() {
		// Set a listener to be invoked when the list should be refreshed.
		msgListView.setOnRefreshListener(new OnRefreshListener2<ListView>() {
			/**
			 * onPullDownToRefresh will be called only when the user has Pulled
			 * from the start, and released.
			 */
			@Override
			public void onPullDownToRefresh(PullToRefreshBase<ListView> refreshView) {
				// Do work to refresh the list here.
				refreshHead();
			}

			/**
			 * onPullUpToRefresh will be called only when the user has Pulled
			 * from the end, and released.
			 */
			@Override
			public void onPullUpToRefresh(PullToRefreshBase<ListView> refreshView) {
				refreshTail();
			}
		});

	}

	private void refreshHead() {
		long from = 0;
		if (!newsList.isEmpty()) {
			try {
				from = newsList.get(0).getTimestamp();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}

		Log.d("DDD", "refreshHead from=" + from);
		boolean runtask = runGetNoticeTask(from, 0, ConstantValue.Type_INSERT_HEAD);
		if (!runtask) {
			// 任务没有执行，立即去掉下拉显示
			msgListView.onRefreshComplete();
		} else {
			// Toast.makeText(NoticePullRefreshActivity.this, "Head Head Head!",
			// Toast.LENGTH_SHORT)
			// .show();
		}
	}

	private void setItemClickListener() {
		msgListView.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				// 自定义listview headview占了一个，所以真实数据从1开始
				int currentIndex = position - 1;
				if (currentIndex >= adapter.getCount()) {
					// 当底部条出现时，index会大于count造成数组越界异常，这里处理一下
					return;
				}
				News info = (News) adapter.getItem(currentIndex);
				startTo(info);
			}
		});
	}

	private void refreshTail() {

		long to = 0;
		if (!newsList.isEmpty()) {
			try {
				to = newsList.get(newsList.size() - 1).getTimestamp();
			} catch (NumberFormatException e) {
				e.printStackTrace();
			}
		}

		Log.d("djc", "refreshTail to=" + to);
		List<News> list = getNewsFromLocalDB(to);
		if (!list.isEmpty()) {
			Message msg = Message.obtain();
			msg.what = EventType.GET_NEWS_SUCCESS;
			msg.obj = list;
			msg.arg1 = ConstantValue.Type_INSERT_TAIl;
			myhandler.sendMessageDelayed(msg, 2000);
		} else {
			runGetNoticeTask(0, to, ConstantValue.Type_INSERT_TAIl);
		}
	}

	private List<News> getNewsFromLocalDB(long to) {
		return DataMgr.getInstance().getNews(ConstantValue.GET_NORMAL_NOTICE_MAX_COUNT, to);
	}

	private void startTo(News info) {
		Intent intent = new Intent(this, NoticeActivity.class);
		// intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
		// intent.putExtra(JSONConstant.NOTIFICATION_TITLE, info.getTitle());
		// intent.putExtra(JSONConstant.NOTIFICATION_BODY, info.getContent());
		// intent.putExtra(JSONConstant.TIME_STAMP,
		// Utils.formatChineseTime(info.getTimestamp()));
		// intent.putExtra(JSONConstant.PUBLISHER, info.getFrom());
		// intent.putExtra(JSONConstant.NET_URL, info.getIcon_url());
		// intent.putExtra(JSONConstant.LOCAL_URL, info.getNewsLocalIconPath());
		// intent.putExtra(JSONConstant.TOPBAR_TITLE, info.getCatagry());

		currentNewID = info.getNews_server_id();
		intent.putExtra(JSONConstant.NOTIFICATION_ID, currentNewID);
		startActivityForResult(intent, START_NOTICE_DETAIL);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		Log.d("DDD", "onActivityResult resultCode =" + resultCode);
		if (resultCode != Activity.RESULT_OK) {
			return;
		}

		Log.d("DDD", "requestCode =" + requestCode);
		// 发布公告成功，此时需要刷新公告
		if (requestCode == START_SEND_NEWS) {
			loadNewData();
		} else if (START_NOTICE_DETAIL == requestCode) {
			Iterator<News> iterator = newsList.iterator();

			while (iterator.hasNext()) {
				News next = iterator.next();
				if (next.getNews_server_id() == currentNewID) {
					Log.d("", "delete success id=" + currentNewID + " title =" + next.getTitle());
					iterator.remove();
					DataMgr.getInstance().deleteNews(currentNewID);
					adapter.notifyDataSetChanged();
					break;
				}
			}
		}
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		if (MyApplication.getInstance().isForTest()) {
			menu.add(1, // 组号
					Menu.FIRST, // 唯一的ID号
					Menu.FIRST, // 排序号
					"清空"); // 标题
		}

		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		if (item.getItemId() == Menu.FIRST) {
			DlgMgr.showTwoBtnResDlg(R.string.clearall, this, new OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
					DataMgr.getInstance().removeAllNewsByType(JSONConstant.NOTICE_TYPE_NORMAL);
					adapter.clear();
				}
			});
		}
		return true;
	}

}
