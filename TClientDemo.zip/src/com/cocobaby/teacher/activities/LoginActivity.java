package com.cocobaby.teacher.activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.LoginJob;
import com.cocobaby.teacher.utils.Utils;

public class LoginActivity extends MyActivity {
	private Handler handler;
	private ProgressDialog dialog;
	private EditText pwdView;
	private EditText usernameView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
		initDialog();
		initHandler();
		initView();
	}

	private void initDialog() {
		dialog = new ProgressDialog(this);
		dialog.setCancelable(false);
		dialog.setMessage(getResources().getString(R.string.loginning));
	}

	private void initHandler() {

		handler = new MyHandler(this, dialog) {

			@Override
			public void handleMessage(Message msg) {
				if (LoginActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}

				Log.w("dasd", "LoginActivity msg.what=" + msg.what);
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.LOGIN_SUCCESS:
					handleLoginSuccess();
					break;
				case EventType.PWD_INCORRECT:
					DlgMgr.showSingleBtnResDlg(R.string.pwd_user_invalid,
							LoginActivity.this);
					pwdView.setText("");
					break;
				default:
					break;
				}
			}
		};
	}

	protected void handleLoginSuccess() {
		Utils.goNextActivity(LoginActivity.this, MainActivity.class, true);
	}

	private void initView() {
		pwdView = (EditText) findViewById(R.id.inuputpwdView);
		usernameView = (EditText) findViewById(R.id.inuputusernameView);
		initBtn();
	}

	private void initBtn() {
		Button loginBtn = (Button) findViewById(R.id.loginBtn);
		loginBtn.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				if (TextUtils.isEmpty(usernameView.getText().toString())
						|| TextUtils.isEmpty(pwdView.getText().toString())) {
					DlgMgr.showSingleBtnResDlg(R.string.pwd_user_format_error,
							LoginActivity.this);
					return;
				}

				Utils.closeKeyBoard(LoginActivity.this);
				runLoginJob();
			}

		});

		TextView forgetPwdView = (TextView) findViewById(R.id.forgetPwdView);
		forgetPwdView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				startToResetPwdActivity();
			}
		});
	}

	protected void startToResetPwdActivity() {
		Utils.goNextActivity(LoginActivity.this, GetAuthCodeActivity.class,
				false);
	}

	private void runLoginJob() {
		dialog.show();
		LoginJob job = new LoginJob(handler, usernameView.getText().toString(),
				pwdView.getText().toString());
		job.execute();
	}

}
