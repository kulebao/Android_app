package com.cocobaby.teacher.activities;

import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ClassInfo;
import com.cocobaby.teacher.dbmgr.info.News;
import com.cocobaby.teacher.dialogmgr.DlgMgr;
import com.cocobaby.teacher.handler.MyHandler;
import com.cocobaby.teacher.taskmgr.DeleteNewsJob;
import com.cocobaby.teacher.taskmgr.GetAllIneligibleClassesJob;
import com.cocobaby.teacher.taskmgr.SimpleDownloadImgJob;
import com.cocobaby.teacher.utils.ImageUtils;
import com.cocobaby.teacher.utils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;

public class NoticeActivity extends UmengStatisticsActivity {
	private TextView contentView;
	private ImageView noticeiconView;
	private TextView signView;
	private TextView timeView;
	private SimpleDownloadImgJob downloadImgJob;
	// 图片在服务器上路径
	private String net_url;
	// 图片本地保存路径
	private String local_url;
	private Handler handler;
	private TextView titleView;
	private News news;
	private ProgressDialog progressDialog;
	private ImageView checkFeedBackView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.notice);
		// ActivityHelper.setBackKeyLitsenerOnTopbar(this,
		// R.string.notice_title);
		Log.d("DDD JJJ", "NoticeActivity onCreate");
		initView();
		initDialog();
		initHandler();
		setData(getIntent());
	}

	private void initDialog() {
		progressDialog = new ProgressDialog(this);
		progressDialog.setMessage(getResources().getString(R.string.deleting_data));
		progressDialog.setCancelable(false);

	}

	private void setData(Intent intent) {
		int noticeId = intent.getIntExtra(JSONConstant.NOTIFICATION_ID, -1);

		news = DataMgr.getInstance().getNewsByID(noticeId);

		if (news != null) {
			String title = news.getTitle();
			String content = news.getContent();
			String time = Utils.formatChineseTime(news.getTimestamp());
			String publisher = news.getFrom();

			net_url = news.getIcon_url();
			local_url = news.getNewsLocalIconPath();

			String topbarTitle = news.getCatagry();
			if (topbarTitle != null) {
				ActivityHelper.setTopbarTitle(this, topbarTitle);
			}

			setIcon();

			signView.setText(publisher);
			timeView.setText(time);

			titleView.setText(title);
			contentView.setText(content);

			if (news.getNeed_receipt() != 0) {
				checkFeedBackView.setVisibility(View.VISIBLE);
			}

		}

	}

	private void initHandler() {
		handler = new MyHandler(this, progressDialog) {
			@Override
			public void handleMessage(Message msg) {
				if (NoticeActivity.this.isFinishing()) {
					Log.w("djc", "do nothing when activity finishing!");
					return;
				}
				super.handleMessage(msg);
				switch (msg.what) {
				case EventType.DOWNLOAD_FILE_SUCCESS:
					setIcon();
					break;
				case EventType.DELETE_NEWS_NO_POWER:
					DlgMgr.showSingleBtnResDlg(R.string.delete_news_fail_no_power, NoticeActivity.this);
					break;
				case EventType.WITHOUT_SCHOOL_NOTICE_PRIVILEGE:
					DlgMgr.showSingleBtnResDlg(R.string.delete_news_fail_with_school_notice, NoticeActivity.this);
					break;
				case EventType.WITH_SCHOOL_NOTICE_PRIVILEGE:
					runDeleteJob();
					break;
				case EventType.DELETE_NEWS_SUCCESS:
					setResult(Activity.RESULT_OK);
					Utils.makeToast(NoticeActivity.this, R.string.delete_news_success);
					finish();
					break;
				case EventType.DELETE_NEWS_FAIL:
					Utils.makeToast(NoticeActivity.this, R.string.delete_news_fail);
					break;
				default:
					break;
				}
			}

		};
	}

	private void setIcon() {
		try {
			if (!TextUtils.isEmpty(local_url)) {
				Bitmap bmp = Utils.getLoacalBitmap(local_url);
				if (bmp != null) {
					ImageLoader imageLoader = ImageUtils.getImageLoader();
					noticeiconView.setVisibility(View.VISIBLE);
					String path = "file://" + local_url;
					imageLoader.displayImage(path, noticeiconView);
					noticeiconView.setOnClickListener(new OnClickListener() {
						@Override
						public void onClick(View v) {
							startToShowIcon();
						}

					});
					Utils.setImg(noticeiconView, bmp);
				} else {
					// 如果本地图片有路径却没有文件，那么从服务器重新下载并保存到本地
					if (!TextUtils.isEmpty(net_url)) {
						runDownloadIconTask();
						noticeiconView.setVisibility(View.VISIBLE);
						noticeiconView.setImageResource(R.drawable.default_icon);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void startToShowIcon() {
		Intent intent = new Intent(this, ShowIconActivity.class);
		intent.putExtra(ConstantValue.LOCAL_URL, local_url);
		startActivity(intent);
	}

	private void runDownloadIconTask() {
		if (downloadImgJob != null && !downloadImgJob.isDone()) {
			// 有任务执行，则返回
			Log.d("DDD", "NoticeActivity DownloadIconTask already running!");
			return;
		}

		downloadImgJob = new SimpleDownloadImgJob(handler, net_url, local_url, Utils.LIMIT_WIDTH, Utils.LIMIT_HEIGHT);
		downloadImgJob.execute();
	}

	private void initView() {
		signView = (TextView) findViewById(R.id.sign);
		timeView = (TextView) findViewById(R.id.time);
		contentView = (TextView) findViewById(R.id.noticecontent);
		noticeiconView = (ImageView) findViewById(R.id.noticeicon);
		titleView = (TextView) findViewById(R.id.title);
		initCheckFeedBackBtn();
	}

	private void initCheckFeedBackBtn() {
		checkFeedBackView = (ImageView) findViewById(R.id.rightImage);
		checkFeedBackView.setImageResource(R.drawable.check_feedback);
		checkFeedBackView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				checkFeedBack();
			}
		});
	}

	private void checkFeedBack() {
		Intent intent = new Intent();
		intent.putExtra(JSONConstant.NOTIFICATION_ID, news.getNews_server_id());
		intent.setClass(this, UnFeedbackChildListActivity.class);
		startActivity(intent);
	}

	public void deleteNotice(View view) {
		if (news == null) {
			return;
		}

		AlertDialog dialog = new AlertDialog.Builder(this).setTitle(R.string.delete_news_notice)
				.setPositiveButton(R.string.delete, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						progressDialog.show();
						int class_id = news.getClass_id();

						if (class_id == 0) {
							GetAllIneligibleClassesJob getAllClassesJob = new GetAllIneligibleClassesJob(handler);
							getAllClassesJob.execute();
						} else {
							List<ClassInfo> allClasses = DataMgr.getInstance().getAllClasses();
							for (ClassInfo classInfo : allClasses) {
								if (classInfo.getClassID() == class_id) {
									runDeleteJob();
									return;
								}
							}

							handler.sendEmptyMessage(EventType.DELETE_NEWS_NO_POWER);
						}
					}
				}).setNegativeButton(R.string.cancel, null).create();
		dialog.show();
	}

	protected void runDeleteJob() {
		DeleteNewsJob deleteNewsJob = new DeleteNewsJob(handler, news.getNews_server_id());
		deleteNewsJob.execute();
	}

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		Log.d("DDD JJJ", "NoticeActivity onNewIntent");
		setIntent(intent);
		setData(intent);
	}

}
