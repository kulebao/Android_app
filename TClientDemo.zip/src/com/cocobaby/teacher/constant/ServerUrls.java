package com.cocobaby.teacher.constant;

import com.cocobaby.teacher.activities.MyApplication;

public class ServerUrls{
    public static final String  ROOT_RES_PATH        = "kindergarten";
    public static final String  PARENT_RES_PATH      = "parent";
    public static final String  EMPLOYEE_RES_PATH    = "employee";
    public static final String  CHILD_RES_PATH       = "child";
    public static final String  CLASS_RES_PATH       = "class";
    public static final String  SCHEDULE_RES_PATH    = "schedule";
    public static final String  COOKBOOK_RES_PATH    = "cookbook";
    public static final String  NEWS_RES_PATH        = "news";
    public static final String  EDU_RES_PATH         = "assessments";
    public static final String  ASSIGNMENT_RES_PATH  = "assignment";
    public static final String  CHAT_SESSION         = "session";
    public static final String  RELATIONSHIP         = "relationship";
    public static final String  CHILD_STATUS         = "dailylog";
    public static final String  PASSWORD             = "password";
    public static final String  RESET_PWD            = "employee_resetpwd.do";
    public static final String  SENDER               = "sender";

    public static final String  EXP_RES_PATH         = "history";
    public static final String  ESTIMATE_RES_PATH    = "assess";
    public static final String  RECORD_RES_PATH      = "record";
    public static final String  CHECK_NEW_PATH       = "teacher_upgrade";
    public static final String  VERSION              = "version";
    public static final String  FEEDBACK             = "feedback";
    public static final String  ADMIN                = "admin";

    public static final String  GET_TYPE_PREVIEW     = "preview";
    public static final String  GET_TYPE_DETAIL      = "detail";
    public static final String  HTTPS_HOST_ADDR      = "https://www.cocobabys.com/";
    public static final String  POST_NEWS_PATH       = "admin/%s/news";

    public static final String  INELIGIBLE_PATH      = "ineligible_class";

    public static final String  FIX_PATH             = "api/v2/";

    public static final String  FIX_V3_PATH          = "api/v3/";
    public static final String  IM_TOKEN             = "im_token";
    public static final String  CHECK_READER         = "news/%d/reader";

    public static final String  CLASS_IM_GROUP       = "class_im_group";

    public static final String  MANAGER              = "manager";

    private static final String BAN                  = "ban";

    public static final String  TEST_HTTPS_HOST_ADDR = "https://stage2.cocobabys.com/";

    private static String getHost(){
        String host = HTTPS_HOST_ADDR;
        if(MyApplication.getInstance().isForTest()){
            host = TEST_HTTPS_HOST_ADDR;
        }
        return host;
    }

    public static final String LOGIN_URL                   = getHost() + "employee_login.do";

    public static final String RESET_PWD_URL               = getHost() + RESET_PWD;

    public static final String GET_AUTH_CODE_URL           = getHost() + "ws/verify/phone/%s";

    public static final String GET_HOMEWORK                = getHost() + ROOT_RES_PATH + "/%s/" + ASSIGNMENT_RES_PATH
                                                                   + "?";

    // https://www.cocobabys.com/kindergarten/93740362/news?most=25&from=1389718964408&to=1389801005344
    public static final String GET_NORMAL_NOTICE           = getHost() + ROOT_RES_PATH + "/%s/" + NEWS_RES_PATH + "?";

    // https://www.cocobabys.com/kindergarten/93740362/news?most=25&from=1389718964408&to=1389801005344
    public static final String GET_NOTICE_WITH_TAGS        = getHost() + FIX_PATH + ROOT_RES_PATH + "/%s/"
                                                                   + NEWS_RES_PATH + "?";                                ;

    // https://stage2.cocobabys.com/kindergarten/2088/admin/reserved/news
    public static final String SEND_NEWS_URL               = getHost() + ROOT_RES_PATH + "/%s/" + POST_NEWS_PATH;

    // https://stage2.cocobabys.com/api/v2/kindergarten/2088/admin/3_0_2/news
    public static final String SEND_NEWS_URL_WITH_FEEDBACK = getHost() + FIX_PATH + ROOT_RES_PATH + "/%s/"
                                                                   + POST_NEWS_PATH;

    // DELETE /kindergarten/:kg/news/:newsId
    public static final String DELETE_NEWS_URL             = getHost() + ROOT_RES_PATH + "/%s/" + NEWS_RES_PATH + "/%d";

    // DELETE /api/v2/kindergarten/:kg/admin/:adminId/news/:newsId
    public static final String DELETE_NEWS_URL_EX          = getHost() + FIX_PATH + ROOT_RES_PATH + "/%s/" + ADMIN
                                                                   + "/%s/" + NEWS_RES_PATH + "/%d";

    // https://stage2.cocobabys.com/kindergarten/2088/assignment
    public static final String SEND_HOMEWORK_URL           = getHost() + ROOT_RES_PATH + "/%s/" + ASSIGNMENT_RES_PATH;

    // https://stage2.cocobabys.com/kindergarten/1003/employee/13408654680/password
    public static final String CHANGE_PWD_URL              = getHost() + ROOT_RES_PATH + "/%s/" + EMPLOYEE_RES_PATH
                                                                   + "/%s/" + PASSWORD;

    // https://stage2.cocobabys.com/kindergarten/1003/employee/13333333333
    public static final String TEATHER_URL                 = getHost() + ROOT_RES_PATH + "/%s/" + EMPLOYEE_RES_PATH
                                                                   + "/%s";

    // https://cocobabys.com/kindergarten/1003/employee/13333333333/class
    public static final String GET_CLASSES                 = getHost() + ROOT_RES_PATH + "/%s/" + EMPLOYEE_RES_PATH
                                                                   + "/%s/" + CLASS_RES_PATH;

    // https://cocobabys.com/kindergarten/2041/class
    public static final String GET_INELIGIBLE_CLASSES      = getHost() + FIX_V3_PATH + ROOT_RES_PATH + "/%s/"
                                                                   + EMPLOYEE_RES_PATH + "/%s/" + INELIGIBLE_PATH;

    // https://cocobabys.com/kindergarten/1003/child?class_id=1,2&connected=true
    public static final String GET_CHILDREN                = getHost() + ROOT_RES_PATH + "/%s/" + CHILD_RES_PATH + "?";

    // https://cocobabys.com/kindergarten/1003/dailylog?class_id=15,16
    public static final String GET_CHILD_STATUS            = getHost() + ROOT_RES_PATH + "/%s/" + CHILD_STATUS + "?";

    // https://stage2.cocobabys.com/kindergarten/1003/session/1_1396844597394
    public static final String SEND_CHAT                   = getHost() + ROOT_RES_PATH + "/%s/" + CHAT_SESSION + "/%s/"
                                                                   + RECORD_RES_PATH;

    public static final String DELETE_CHAT                 = getHost() + ROOT_RES_PATH + "/%s/" + CHAT_SESSION + "/%s/"
                                                                   + RECORD_RES_PATH + "/%d";

    // https://stage2.cocobabys.com/kindergarten/1003/session/1_1396844597394/record
    public static final String GET_CHAT                    = getHost() + ROOT_RES_PATH + "/%s/" + CHAT_SESSION + "/%s/"
                                                                   + RECORD_RES_PATH + "?";

    // https://stage2.cocobabys.com/kindergarten/1003/session?class_id=1,2,15
    public static final String GET_LAST_CHAT               = getHost() + ROOT_RES_PATH + "/%s/" + CHAT_SESSION + "?";
    // https://stage2.cocobabys.com/kindergarten/1003/relationship?child=1
    public static final String GET_RELATIONSHIP            = getHost() + ROOT_RES_PATH + "/%s/" + RELATIONSHIP + "?";

    // https://cocobabys.com/ws/fileToken?bucket=cocobabys&key=ddd/djc/2.jpg
    // 是否有问题？没有测试地址？
    public static final String GET_UPLOAD_TOKEN            = "https://cocobabys.com/ws/fileToken?bucket=" + "%s";

    // https://www.cocobabys.com/kindergarten/93740362/child/1_93740362_456/assess?from=1&to=10&most=5
    // https://www.cocobabys.com/kindergarten/93740362/child/1_93740362_456/assess?most=1
    // get the lastest one
    public static final String GET_ESTIMATE                = getHost() + ROOT_RES_PATH + "/%s/" + CHILD_RES_PATH
                                                                   + "/%s/" + ESTIMATE_RES_PATH + "?";

    // https://stage2.cocobabys.com/kindergarten/1003/child/1_1396844597394/assess
    public static final String POST_ESTIMATE               = getHost() + ROOT_RES_PATH + "/%s/" + CHILD_RES_PATH
                                                                   + "/%s/" + ESTIMATE_RES_PATH;

    public static final String MULTI_POST_ESTIMATE         = getHost() + ROOT_RES_PATH + "/%s/" + EDU_RES_PATH;

    // https://stage2.cocobabys.com/kindergarten/1003/employee/13408654680
    public static final String POST_TEACHER                = getHost() + ROOT_RES_PATH + "/%s/" + EMPLOYEE_RES_PATH
                                                                   + "/%s";

    public static final String POST_EXP                    = getHost() + ROOT_RES_PATH + "/%s/" + EXP_RES_PATH + "?";

    // /api/v3/kindergarten/:kg/employee/:employeeId/history
    public static final String GET_EXP                     = getHost() + FIX_V3_PATH + ROOT_RES_PATH + "/%s/"
                                                                   + EMPLOYEE_RES_PATH + "/%s/" + EXP_RES_PATH + "?";

    // teacher_upgrade?version=xxxx
    public static final String CHECK_NEW_VERSION           = getHost() + CHECK_NEW_PATH + "?version=%d";

    public static final String FEED_BACK                   = getHost() + FEEDBACK;

    public static final String CHECK_FEEDBACK              = getHost() + FIX_PATH + ROOT_RES_PATH + "/%s/"
                                                                   + CHECK_READER;

    // https://stage2.cocobabys.com/kindergarten/1003/sender/3_1003_1399268817590?type=t
    public static final String GET_SENDER_INFO             = getHost() + ROOT_RES_PATH + "/%s/" + SENDER + "/%s?";

    // 类似kindergarten/93740362/parent/13408654680/child
    public static final String GET_TEACHER_INFO            = getHost() + ROOT_RES_PATH + "/%s/" + EMPLOYEE_RES_PATH
                                                                   + "?phone=%s";

    // https://stage2.cocobabys.com/api/v7/kindergarten/8901/im_token/p_8901_Some(9029)_12323232323
    public static final String REFRESH_IM_TOKEN_URL        = getHost() + "api/v7/" + ROOT_RES_PATH + "/%s/" + IM_TOKEN
                                                                   + "/%s";

    // https://cocobabys.com/api/v7/kindergarten/:kg/class_im_group/:class_id
    // CLASS_IM_GROUP
    public static final String GET_GROUP_INFO_URL          = getHost() + "api/v7/" + ROOT_RES_PATH + "/%s/"
                                                                   + CLASS_IM_GROUP + "/%s";

    // 类似/kindergarten/:kg/class/:classId/manager
    public static final String GET_TEACHER_LIST            = getHost() + ROOT_RES_PATH + "/%s/" + CLASS_RES_PATH
                                                                   + "/%s/" + MANAGER;

    // https://stage2.cocobabys.com/kindergarten/8901/relationship?class_id=20001
    public static final String GET_CLASS_RELATIONSHIP      = getHost() + ROOT_RES_PATH + "/%s/" + RELATIONSHIP + "?";

    // /api/v7/kindergarten/:kg/class_im_group/:class_id/ban
    public static final String GROUP_FORBID                = getHost() + "api/v7/" + ROOT_RES_PATH + "/%s/"
                                                                   + CLASS_IM_GROUP + "/%s/" + BAN;

    // /api/v7/kindergarten/:kg/class_im_group/:class_id/ban/userid
    public static final String GROUP_UNFORBID              = getHost() + "api/v7/" + ROOT_RES_PATH + "/%s/"
                                                                   + CLASS_IM_GROUP + "/%s/" + BAN + "/%s";

    public static final String GET_SCHOOL_CONFIG           = getHost() + "api/v2/school_config/%s";

    public static final String GET_SCHOOL_PRIVIEW          = getHost() + ROOT_RES_PATH + "/%s/" + GET_TYPE_PREVIEW;

    public static final String GET_SCHOOL_DETAIL           = getHost() + ROOT_RES_PATH + "/%s/";

}
