package com.cocobaby.teacher.constant;

public class EventType{

    public static final int AUTO_LOGIN_FAIL                 = 1101;

    public static final int LOADING_TO_LOGIN                = 1111;
    public static final int LOADING_TO_MAIN                 = 1112;
    public static final int LOADING_TO_MAIN_AND_UPDATE      = 1113;

    public static final int AUTH_CODE_IS_VALID              = 1130;
    public static final int AUTH_CODE_IS_INVALID            = 1131;

    public static final int NET_WORK_INVALID                = 1201;
    public static final int SERVER_INNER_ERROR              = 1221;
    public static final int SERVER_BUSY                     = 1225;

    public static final int RESET_PWD_SUCCESS               = 1410;
    public static final int RESET_PWD_FAILED                = 1411;

    public static final int GET_AUTH_CODE_SUCCESS           = 1440;
    public static final int GET_AUTH_CODE_FAIL              = 1441;
    public static final int GET_AUTH_CODE_TOO_OFTEN         = 1442;

    public static final int AUTHCODE_COUNTDOWN_GO           = 1450;
    public static final int AUTHCODE_COUNTDOWN_OVER         = 1451;

    public static final int LOGIN_SUCCESS                   = 1600;
    public static final int PWD_INCORRECT                   = 1601;

    public static final int GET_CLASSES_SUCCESS             = 1610;
    public static final int GET_CLASSES_FAIL                = 1611;

    public static final int WITH_SCHOOL_NOTICE_PRIVILEGE    = 1614;
    public static final int WITHOUT_SCHOOL_NOTICE_PRIVILEGE = 1615;

    public static final int GET_CHILDREN_SUCCESS            = 1620;
    public static final int GET_CHILDREN_FAIL               = 1621;
    public static final int GET_CHILDREN_END               = 1622;

    public static final int GET_CHILD_STATUS_SUCCESS        = 1630;
    public static final int GET_CHILD_STATUS_FAIL           = 1631;

    public static final int POST_TEACHER_SUCCESS            = 1650;
    public static final int POST_TEACHER_FAIL               = 1651;

    public static final int DOWNLOAD_FILE_SUCCESS           = 1660;
    public static final int DOWNLOAD_FILE_FAILED            = 1661;

    public static final int GET_CHAT_SUCCESS                = 1670;
    public static final int GET_CHAT_FAIL                   = 1671;

    public static final int DELETE_CHAT_SUCCESS             = 1674;
    public static final int DELETE_CHAT_FAIL                = 1675;

    public static final int GET_RELATIONSHIP_SUCCESS        = 1680;
    public static final int GET_RELATIONSHIP_FAIL           = 1681;

    public static final int SEND_CHAT_SUCCESS               = 1690;
    public static final int SEND_CHAT_FAIL                  = 1691;

    public static final int GET_ESTIMATE_SUCCESS            = 1700;
    public static final int GET_ESTIMATE_FAIL               = 1701;

    public static final int POST_ESTIMATE_SUCCESS           = 1640;
    public static final int POST_ESTIMATE_FAIL              = 1641;

    public static final int GET_EXP_SUCCESS                 = 1650;
    public static final int GET_EXP_FAIL                    = 1651;

    public static final int POST_EXP_SUCCESS                = 1660;
    public static final int POST_EXP_FAIL                   = 1661;

    public static final int UPLOAD_ICON_SUCCESS             = 1665;

    public static final int CHANGE_PWD_SUCCESS              = 1670;
    public static final int CHANGE_PWD_FAIL                 = 1671;
    public static final int OLD_PWD_NOT_EQUAL               = 1672;

    public static final int HAS_NEW_VERSION                 = 1681;
    public static final int HAS_NO_NEW_VERSION              = 1682;

    public static final int FEEDBACK_SUCESS                 = 1691;
    public static final int FEEDBACK_FAILED                 = 1692;

    public static final int CHECK_FEEDBACK_SUCESS           = 1694;
    public static final int CHECK_FEEDBACK_FAILED           = 1695;

    public static final int GET_SENDER_SUCCESS              = 1730;
    public static final int GET_SENDER_FAIL                 = 1731;

    public static final int GET_TEACHER_SUCCESS             = 1740;
    public static final int GET_TEACHER_FAIL                = 1741;
    public static final int GET_TEACHER_UPDATE              = 1742;

    public static final int GET_NEWS_SUCCESS                = 1760;
    public static final int GET_NEWS_FAIL                   = 1761;

    public static final int SEND_NEWS_SUCCESS               = 1770;
    public static final int SEND_NEWS_FAIL                  = 1771;

    public static final int DELETE_NEWS_SUCCESS             = 1773;
    public static final int DELETE_NEWS_FAIL                = 1774;
    public static final int DELETE_NEWS_NO_POWER            = 1775;

    public static final int GET_HOMEWORK_SUCCESS            = 1780;
    public static final int GET_HOMEWORK_FAIL               = 1781;

    public static final int SEND_HOMEWORK_SUCCESS           = 1790;
    public static final int SEND_HOMEWORK_FAIL              = 1791;

    public static final int GET_EXP_INFO_SUCCESS            = 1810;
    public static final int GET_EXP_INFO_FAIL               = 1811;

    public static final int GET_CLASS_RELATIONSHIP_SUCCESS  = 1914;
    public static final int GET_CLASS_RELATIONSHIP_FAIL     = 1915;

    public static final int GET_IM_GROUP_SUCCESS            = 1930;
    public static final int GET_IM_GROUP_FAIL               = 1931;

    public static final int JOIN_IM_GROUP_SUCCESS           = 1935;
    public static final int JOIN_IM_GROUP_FAIL              = 1936;

    public static final int GROUP_FORBID_SUCCESS            = 1940;
    public static final int GROUP_FORBID_FAIL               = 1941;

    public static final int GROUP_UNFORBID_SUCCESS          = 1944;
    public static final int GROUP_UNFORBID_FAIL             = 1945;

    public static final int GET_GROUP_FORBID_USERS_SUCCESS  = 1947;
    public static final int GET_GROUP_FORBID_USERS_FAIL     = 1948;

    public static final int UPDATE_SCHOOL_INFO              = 1960;
    public static final int SCHOOL_INFO_IS_LATEST           = 1961;
    public static final int GET_SCHOOL_INFO_FAILED          = 1962;
    // public static final int DOWNLOAD_FILE_SUCCESS = 1750;
    // public static final int DOWNLOAD_FILE_FAILED = 1751;
}
