package com.cocobaby.teacher.adapter;

import java.util.List;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.customview.CheckSwitchButton;
import com.cocobaby.teacher.im.ForbidUser;
import com.cocobaby.teacher.pojo.ForbidInfo;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import android.widget.ToggleButton;

public class ForbidListAdapter extends BaseAdapter {
	private final Context context;
	private List<ForbidInfo> mList;
	private ForbidUser forbidUser;

	public ForbidListAdapter(Context activityContext, List<ForbidInfo> list, ForbidUser forbidUser) {
		this.context = activityContext;
		this.forbidUser = forbidUser;
		mList = list;
	}

	public void clear() {
		mList.clear();
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public ForbidInfo getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			FlagHolder flagholder = this.new FlagHolder();
			convertView = LayoutInflater.from(this.context).inflate(R.layout.forbid_item, null);

			flagholder.nameView = (TextView) convertView.findViewById(R.id.parentName);
			flagholder.disturbButton = (CheckSwitchButton) convertView.findViewById(R.id.checkSwithcButton);
			flagholder.toggleButton = (ToggleButton) convertView.findViewById(R.id.toggleButton);

			setDataToViews(position, flagholder);
			convertView.setTag(flagholder);
		} else {
			FlagHolder flagholder = (FlagHolder) convertView.getTag();
			if (flagholder != null) {
				setDataToViews(position, flagholder);
			}
		}

		return convertView;
	}

	private void setDataToViews(final int position, FlagHolder flagholder) {
		final ForbidInfo forbidInfo = mList.get(position);
		flagholder.nameView.setText(forbidInfo.getName());

		// 注意，checkbox，只要点击就会执行onCheckedChanged，总是相反
		flagholder.disturbButton.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView, final boolean isChecked) {
				Log.d("", "CCCC forbidUser onCheckedChanged isChecked = " + isChecked + " forbidInfo= "
						+ forbidInfo.toString());

				if (isChecked != forbidInfo.isForbidden()) {
					Log.d("", "CCCC forbidUser do");
					forbidUser.forbidUser(forbidInfo.getId(), isChecked);
				}
			}
		});

		// setChecked 调用必须在setOnCheckedChangeListener之后，否则状态混乱。。。
		flagholder.disturbButton.setChecked(forbidInfo.isForbidden());

		// flagholder.toggleButton.setChecked(forbidInfo.isForbidden());
		// flagholder.toggleButton.setOnCheckedChangeListener(new
		// OnCheckedChangeListener() {
		// @Override
		// public void onCheckedChanged(CompoundButton buttonView, final boolean
		// isChecked) {
		// Log.d("", "forbidUser onCheckedChanged isChecked = " + isChecked);
		// forbidUser.forbidUser(forbidInfo.getId(), isChecked);
		// }
		// });

	}

	public void refresh(List<ForbidInfo> list) {
		mList.clear();
		mList.addAll(list);
		notifyDataSetChanged();
	}

	public void refresh(String userid, boolean bforbid) {
		for (ForbidInfo forbidInfo : mList) {
			if (forbidInfo.getId().equals(userid)) {
				forbidInfo.setForbidden(bforbid);
				break;
			}
		}
		notifyDataSetChanged();
	}

	private class FlagHolder {
		public TextView nameView;
		public CheckSwitchButton disturbButton;
		public ToggleButton toggleButton;
	}
}