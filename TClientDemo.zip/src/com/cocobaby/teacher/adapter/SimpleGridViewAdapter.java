package com.cocobaby.teacher.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.utils.DataUtils;
import com.cocobaby.teacher.utils.ImageUtils;
import com.cocobaby.teacher.utils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.assist.FailReason;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public class SimpleGridViewAdapter extends BaseAdapter {
	private Context context;
	private List<String> localUrlList = new ArrayList<String>();
	private ImageLoader imageLoader;

	public SimpleGridViewAdapter(Context context, List<String> list) {
		this.context = context;
		this.localUrlList = list;
		this.imageLoader = ImageUtils.getImageLoader();
		// options = new
		// DisplayImageOptions.Builder().showImageOnLoading(R.drawable.default_small_icon)
		// .showImageForEmptyUri(R.drawable.default_small_icon).showImageOnFail(R.drawable.default_small_icon)
		// .cacheInMemory(true).imageScaleType(ImageScaleType.EXACTLY)
		// .cacheOnDisk(true)
		// .considerExifParams(true).bitmapConfig(Bitmap.Config.RGB_565).build();
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;

		if (convertView == null) {
			convertView = LayoutInflater.from(this.context).inflate(R.layout.simple_grid_item, null);
			holder = new ViewHolder();
			holder.imageView = (ImageView) convertView.findViewById(R.id.ItemImage);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		String path = getItem(position);
		String local = "";

		NativeMediumInfo nativeMediumInfo = DataMgr.getInstance().getNativeMediumInfo(path);
		if (nativeMediumInfo != null) {
			local = nativeMediumInfo.getLocal_url();
		}

		if (DataUtils.isValidFile(local)) {
			path = "file://" + local;
		} else {
			path = Utils.getFixedUrl(path, 70, 70);
		}

		// String path = "file://" + getItem(position);
		Log.d("III", "SimpleGridViewAdapter fixedUrl =" + path);

		imageLoader.displayImage(path, holder.imageView, new SimpleImageLoadingListener() {
			@Override
			public void onLoadingStarted(String imageUri, View view) {
				holder.imageView.setImageResource(R.drawable.default_small_icon);
				super.onLoadingStarted(imageUri, view);
			}

			@Override
			public void onLoadingFailed(String imageUri, View view, FailReason failReason) {
				super.onLoadingFailed(imageUri, view, failReason);
				holder.imageView.setImageResource(R.drawable.default_small_icon);
			}

		});

		return convertView;
	}

	public final int getCount() {
		return localUrlList.size();
	}

	public final String getItem(int position) {
		return localUrlList.get(position);
	}

	public final long getItemId(int position) {
		return position;
	}

	public class ViewHolder {
		ImageView imageView;
	}
}
