package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.pojo.GroupExpInfo;

public class MyGridViewAdapter extends BaseAdapter {
	private Context context = null;
	private List<GroupExpInfo> data;

	public MyGridViewAdapter(Context context, List<GroupExpInfo> data) {
		this.context = context;
		this.data = data;
	}

	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public GroupExpInfo getItem(int position) {
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			FlagHolder flagholder = this.new FlagHolder();
			convertView = LayoutInflater.from(this.context).inflate(R.layout.grid_item, null);
			flagholder.newDataSymble = (ImageView) convertView.findViewById(R.id.noticeImg);
			flagholder.nameView = (TextView) convertView.findViewById(R.id.ItemText);
			flagholder.headView = (ImageView) convertView.findViewById(R.id.ItemImage);
			setDataToViews(position, flagholder);
			convertView.setTag(flagholder);
		} else {
			FlagHolder flagholder = (FlagHolder) convertView.getTag();
			if (flagholder != null) {
				setDataToViews(position, flagholder);
			}
		}

		return convertView;
	}

	private void setDataToViews(final int position, FlagHolder flagholder) {
		GroupExpInfo info = getItem(position);
		flagholder.nameView.setText(String.valueOf(info.getCount()));
		flagholder.headView.setImageResource(R.drawable.emotion);
	}

	private class FlagHolder {
		public ImageView newDataSymble;
		public TextView nameView;
		public ImageView headView;
	}

}
