package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.utils.Utils;

public class TeacherListAdapter extends BaseAdapter{
    private final Context     context;
    private List<TeacherInfo> mList;
    private TeacherInfo       self;

    public TeacherListAdapter(Context activityContext, List<TeacherInfo> list){
        this.context = activityContext;
        mList = list;

        self = DataMgr.getInstance().getTeacherInfo();
    }

    public void clear(){
        mList.clear();
        notifyDataSetChanged();
    }

    @Override
    public int getCount(){
        return mList.size();
    }

    @Override
    public TeacherInfo getItem(int position){
        return mList.get(position);
    }

    @Override
    public long getItemId(int position){
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent){
        if(convertView == null){
            FlagHolder flagholder = this.new FlagHolder();
            convertView = LayoutInflater.from(this.context).inflate(R.layout.teacher_item, null);
            flagholder.nameView = (TextView)convertView.findViewById(R.id.nameView);
            flagholder.headView = (ImageView)convertView.findViewById(R.id.headView);
            flagholder.imsmsView = (ImageView)convertView.findViewById(R.id.imsms);
            flagholder.phoneView = (ImageView)convertView.findViewById(R.id.phone);
            setDataToViews(position, flagholder);
            convertView.setTag(flagholder);
        } else{
            FlagHolder flagholder = (FlagHolder)convertView.getTag();
            if(flagholder != null){
                setDataToViews(position, flagholder);
            }
        }

        return convertView;
    }

    private void setDataToViews(final int position, FlagHolder flagholder){
        final TeacherInfo teacher = mList.get(position);
        setHeadIcon(flagholder, teacher);
        setBtnFunc(flagholder, teacher);
    }

    private void setHeadIcon(FlagHolder flagholder, final TeacherInfo teacher){
        flagholder.nameView.setText(teacher.getName());
        Bitmap loacalBitmap = Utils.getLoacalBitmap(teacher.getLocalHeadIconPath());
        if(loacalBitmap != null){
            Utils.setImg(flagholder.headView, loacalBitmap);
        } else{
            flagholder.headView.setImageResource(R.drawable.chat_head_icon);
        }
    }

    private void setBtnFunc(FlagHolder flagholder, final TeacherInfo teacher){
        if(self.equals(teacher)){
            flagholder.imsmsView.setVisibility(View.GONE);
            flagholder.phoneView.setVisibility(View.GONE);
        } else{
            // flagholder.imsmsView.setVisibility(View.VISIBLE);
            flagholder.phoneView.setVisibility(View.VISIBLE);
        }

        // flagholder.imsmsView.setOnClickListener(new OnClickListener(){
        // @Override
        // public void onClick(View v){
        // Log.d("", "start im id=" + teacher.getIMUserid() + " name =" +
        // teacher.getName());
        // RongIM.getInstance().startPrivateChat(context, teacher.getIMUserid(),
        // teacher.getName());
        // }
        // });

        flagholder.phoneView.setOnClickListener(new OnClickListener(){
            @Override
            public void onClick(View v){
                if(!TextUtils.isEmpty(teacher.getPhone())){
                    Utils.startToCall(context, teacher.getPhone());
                }
            }
        });
    }

    private class FlagHolder{
        public TextView  nameView;
        public ImageView headView;
        public ImageView imsmsView;
        public ImageView phoneView;
    }

    public void refresh(List<TeacherInfo> list){
        mList.clear();
        mList.addAll(list);
        notifyDataSetChanged();
    }
}