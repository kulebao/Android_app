package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Handler;
import android.os.Message;
import android.support.v4.util.LruCache;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.EventType;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.dbmgr.info.ChatInfo;
import com.cocobaby.teacher.dbmgr.info.ChildStatus;
import com.cocobaby.teacher.listdata.ChildSummary;
import com.cocobaby.teacher.listdata.ClassSummary;
import com.cocobaby.teacher.taskmgr.DownloadImgeJob;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class ExpandAdapter extends BaseExpandableListAdapter {

	private Context mContext;
	private LayoutInflater inflater = null;
	private List<ClassSummary> dataList = null;
	private Handler handler;
	private DownloadImgeJob job;
	private LruCache<String, Bitmap> lruCache;

	public ExpandAdapter(Context ctx, List<ClassSummary> list,
			DownloadImgeJob job) {
		mContext = ctx;
		inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		dataList = list;
		this.job = job;

		initCache();
		initHandler();
	}

	private void initHandler() {
		handler = new Handler() {
			@Override
			public void handleMessage(Message msg) {
				super.handleMessage(msg);
				if (msg.what == EventType.DOWNLOAD_FILE_SUCCESS) {
					notifyDataSetChanged();
				}
			}

		};
		this.job.setHanlder(handler);
	}

	private void initCache() {
		final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
		lruCache = new LruCache<String, Bitmap>(maxMemory) {
			@Override
			protected int sizeOf(String key, Bitmap value) {
				return value.getRowBytes() * value.getHeight() / 1024;
			}
		};
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		if (!dataList.isEmpty()) {
			return dataList.get(groupPosition).getChildList().size();
		}
		return 0;
	}

	@Override
	public ClassSummary getGroup(int groupPosition) {
		return dataList.get(groupPosition);
	}

	@Override
	public int getGroupCount() {
		return dataList.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public ChildSummary getChild(int groupPosition, int childPosition) {
		return dataList.get(groupPosition).getChildList().get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean arg2, View convertView, ViewGroup arg4) {
		if (convertView == null) {
			ChildViewHolder viewHolder = new ChildViewHolder();
			convertView = inflater.inflate(R.layout.child_item, null);

			viewHolder.nickTextView = (TextView) convertView
					.findViewById(R.id.nick);
			viewHolder.infoView = (TextView) convertView
					.findViewById(R.id.info);
			viewHolder.headView = (ImageView) convertView
					.findViewById(R.id.head);
			viewHolder.hasNewView = (ImageView) convertView
					.findViewById(R.id.hasnew);
			viewHolder.chatView = (TextView) convertView
					.findViewById(R.id.chat);
			setChildData(groupPosition, childPosition, viewHolder);
			convertView.setTag(viewHolder);
		} else {
			ChildViewHolder viewHolder = (ChildViewHolder) convertView.getTag();
			setChildData(groupPosition, childPosition, viewHolder);
		}
		return convertView;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup arg3) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.group_item, null);
			GroupViewHolder holder = new GroupViewHolder();

			holder.mGroupName = (TextView) convertView
					.findViewById(R.id.group_name);
			holder.mGroupCount = (TextView) convertView
					.findViewById(R.id.group_count);

			setGroupData(groupPosition, holder);
			convertView.setTag(holder);
		} else {
			GroupViewHolder holder = (GroupViewHolder) convertView.getTag();
			setGroupData(groupPosition, holder);
		}
		return convertView;
	}

	private void setGroupData(int groupPosition, GroupViewHolder viewHolder) {
		ClassSummary group = getGroup(groupPosition);
		viewHolder.mGroupName.setText(group.getInfo().getClassName());

		viewHolder.mGroupCount.setText(getCount(group));
	}

	private CharSequence getCount(ClassSummary group) {
		List<ChildSummary> childList = group.getChildList();
		int onlineCount = 0;
		for (ChildSummary summary : childList) {
			if (summary.getStatus().getNotice_type() == ChildStatus.SWIPE_IN) {
				onlineCount++;
			}
		}
		return String.format(
				mContext.getResources().getString(R.string.status_count),
				onlineCount, childList.size());
	}

	private void setChildData(int groupPosition, int childPosition,
			ChildViewHolder viewHolder) {
		ChildSummary child = getChild(groupPosition, childPosition);
		viewHolder.nickTextView.setText(child.getInfo().getName());
		viewHolder.infoView.setText(getInfo(child));
		if (!TextUtils.isEmpty(child.getInfo().getPortrait())) {
			setHeadIcon(viewHolder, child);
		} else {
			viewHolder.headView.setImageResource(R.drawable.default_small_icon);
		}

		// String content = getContent(child.getLastChatInfo());
		//
		// if (!TextUtils.isEmpty(content)) {
		// viewHolder.chatView.setVisibility(View.VISIBLE);
		// viewHolder.chatView.setText(content);
		// } else {
		// viewHolder.chatView.setVisibility(View.GONE);
		// }

		// if (child.isHasNewChat()) {
		// viewHolder.hasNewView.setVisibility(View.VISIBLE);
		// } else {
		// viewHolder.hasNewView.setVisibility(View.GONE);
		// }
	}

	private String getContent(ChatInfo info) {
		String content = "";
		if (!TextUtils.isEmpty(info.getContent())) {
			content = info.getContent();
		} else {
			if (JSONConstant.IMAGE_TYPE.equals(info.getMedia_type())) {
				content = Utils.getResString(R.string.pic);
			} else if (JSONConstant.VOICE_TYPE.equals(info.getMedia_type())) {
				content = Utils.getResString(R.string.voi);
			}
		}

		return content;
	}

	public void releaseCache() {
		lruCache.evictAll();
	}

	private void setHeadIcon(ChildViewHolder viewHolder, ChildSummary child) {
		String headUrl = child.getInfo().getChildrenLocalIconPath();
		Bitmap fromLocal = getFromLocal(headUrl);

		if (fromLocal != null) {
			if (child.getStatus().getNotice_type() == ChildStatus.SWIPE_OUT) {
				Bitmap grayBitmap = Utils.getGrayBitmap(fromLocal);
				Utils.setImg(viewHolder.headView, grayBitmap);
			} else {
				Utils.setImg(viewHolder.headView, fromLocal);
			}
		} else {
			downloadIcon(child);
		}
	}

	private void downloadIcon(ChildSummary child) {
		// 本地路径按照学校id+家长手机号码+时间搓.jpg保存
		String savePath = child.getInfo().getChildrenLocalIconPath();
		Log.d("DDD", "savePath =" + savePath);
		// if (!"".equals(info.getSender())) {
		// task.addTask(info.getIcon_url(), savePath);
		// }
		job.addTask(child.getInfo().getPortrait(), savePath,
				ConstantValue.HEAD_ICON_BIG_WIDTH,
				ConstantValue.HEAD_ICON_BIG_HEIGHT);
	}

	private Bitmap getFromLocal(String headUrl) {
		Bitmap bitmap = lruCache.get(headUrl);

		if (bitmap == null) {
			bitmap = Utils.getLoacalBitmap(headUrl, ImageDownloader
					.getMaxPixWithDensity(ConstantValue.HEAD_ICON_WIDTH,
							ConstantValue.HEAD_ICON_HEIGHT));

			if (bitmap != null) {
				lruCache.put(headUrl, bitmap);
			}
		}

		return bitmap;
	}

	private class ChildViewHolder {
		TextView chatView;
		ImageView headView;
		ImageView hasNewView;
		TextView nickTextView;
		TextView infoView;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		/* 很重要：实现ChildView点击事件，必须返回true */
		return true;
	}

	private class GroupViewHolder {
		TextView mGroupName;
		TextView mGroupCount;
	}

	private CharSequence getInfo(ChildSummary child) {
		return child.getStatus().getContent();
	}

}
