package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;
import com.cocobaby.teacher.listdata.SimpleClassSummary;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class SimpleExpandAdapter extends BaseExpandableListAdapter {

	private Context mContext;
	private LayoutInflater inflater = null;
	private List<SimpleClassSummary> dataList = null;
	private LruCache<String, Bitmap> lruCache;

	public SimpleExpandAdapter(Context ctx, List<SimpleClassSummary> list) {
		mContext = ctx;
		inflater = (LayoutInflater) mContext
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		dataList = list;
		initCache();
	}

	private void initCache() {
		final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);
		lruCache = new LruCache<String, Bitmap>(maxMemory) {
			@Override
			protected int sizeOf(String key, Bitmap value) {
				return value.getRowBytes() * value.getHeight() / 1024;
			}
		};
	}

	public void releaseCache() {
		lruCache.evictAll();
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		if (!dataList.isEmpty()) {
			return dataList.get(groupPosition).getChildList().size();
		}
		return 0;
	}

	@Override
	public SimpleClassSummary getGroup(int groupPosition) {
		return dataList.get(groupPosition);
	}

	@Override
	public int getGroupCount() {
		return dataList.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	@Override
	public ChildInfo getChild(int groupPosition, int childPosition) {
		return dataList.get(groupPosition).getChildList().get(childPosition);
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean arg2, View convertView, ViewGroup arg4) {
		if (convertView == null) {
			ChildViewHolder viewHolder = new ChildViewHolder();
			convertView = inflater.inflate(R.layout.feedback_item, null);

			viewHolder.nickTextView = (TextView) convertView
					.findViewById(R.id.nick);
			viewHolder.feedbackstatus = (TextView) convertView
					.findViewById(R.id.feedbackstatus);
			viewHolder.headView = (ImageView) convertView
					.findViewById(R.id.head);
			setChildData(groupPosition, childPosition, viewHolder);
			convertView.setTag(viewHolder);
		} else {
			ChildViewHolder viewHolder = (ChildViewHolder) convertView.getTag();
			setChildData(groupPosition, childPosition, viewHolder);
		}
		return convertView;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup arg3) {
		if (convertView == null) {
			convertView = inflater.inflate(R.layout.group_item, null);
			GroupViewHolder holder = new GroupViewHolder();

			holder.mGroupName = (TextView) convertView
					.findViewById(R.id.group_name);
			holder.mGroupCount = (TextView) convertView
					.findViewById(R.id.group_count);

			setGroupData(groupPosition, holder);
			convertView.setTag(holder);
		} else {
			GroupViewHolder holder = (GroupViewHolder) convertView.getTag();
			setGroupData(groupPosition, holder);
		}
		return convertView;
	}

	private void setGroupData(int groupPosition, GroupViewHolder viewHolder) {
		SimpleClassSummary group = getGroup(groupPosition);
		viewHolder.mGroupName.setText(group.getInfo().getClassName());

		viewHolder.mGroupCount.setText("  " + getCount(group));
		viewHolder.mGroupCount.setTextColor(mContext.getResources().getColor(
				R.color.blue1));
	}

	private CharSequence getCount(SimpleClassSummary group) {
		List<ChildInfo> childList = group.getChildList();
		int feedbackCount = 0;
		for (ChildInfo childInfo : childList) {
			if (childInfo.isFeedback()) {
				feedbackCount++;
			}
		}
		return String.format(
				mContext.getResources().getString(R.string.feedback_count),
				feedbackCount, childList.size());
	}

	private void setChildData(int groupPosition, int childPosition,
			ChildViewHolder viewHolder) {
		ChildInfo child = getChild(groupPosition, childPosition);
		viewHolder.nickTextView.setText(child.getName());
		if (!TextUtils.isEmpty(child.getPortrait())) {
			setHeadIcon(viewHolder, child);
		} else {
			viewHolder.headView.setImageResource(R.drawable.default_small_icon);
		}

		if (child.isFeedback()) {
			viewHolder.feedbackstatus.setText("已回执");
			viewHolder.feedbackstatus.setTextColor(mContext.getResources()
					.getColor(R.color.blue1));
		} else {
			viewHolder.feedbackstatus.setText("未回执");
			viewHolder.feedbackstatus.setTextColor(mContext.getResources()
					.getColor(R.color.timecolor));
		}

	}

	private void setHeadIcon(ChildViewHolder viewHolder, ChildInfo child) {
		String headUrl = child.getChildrenLocalIconPath();
		Bitmap fromLocal = getFromLocal(headUrl);

		if (fromLocal != null) {
			if (!child.isFeedback()) {
				Bitmap grayBitmap = Utils.getGrayBitmap(fromLocal);
				Utils.setImg(viewHolder.headView, grayBitmap);
			} else {
				Utils.setImg(viewHolder.headView, fromLocal);
			}
		} else {
			viewHolder.headView.setImageResource(R.drawable.default_small_icon);
		}
	}

	private Bitmap getFromLocal(String headUrl) {
		Bitmap bitmap = lruCache.get(headUrl);

		if (bitmap == null) {
			bitmap = Utils.getLoacalBitmap(headUrl, ImageDownloader
					.getMaxPixWithDensity(ConstantValue.HEAD_ICON_WIDTH,
							ConstantValue.HEAD_ICON_HEIGHT));

			if (bitmap != null) {
				lruCache.put(headUrl, bitmap);
			}
		}

		return bitmap;
	}

	private class ChildViewHolder {
		ImageView headView;
		TextView nickTextView;
		TextView feedbackstatus;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		// TODO Auto-generated method stub
		/* 很重要：实现ChildView点击事件，必须返回true */
		return true;
	}

	private class GroupViewHolder {
		TextView mGroupName;
		TextView mGroupCount;
	}

}
