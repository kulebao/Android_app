package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.dbmgr.info.ChildInfo;

public class ChildListAdapter extends BaseAdapter {
	private final Context context;
	private List<ChildInfo> mList;

	public void setList(List<ChildInfo> list) {
		this.mList = list;
	}

	public ChildListAdapter(Context activityContext, List<ChildInfo> list) {
		this.context = activityContext;
		mList = list;
	}

	public void clear() {
		mList.clear();
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public Object getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			FlagHolder flagholder = this.new FlagHolder();
			convertView = LayoutInflater.from(this.context).inflate(R.layout.simple_child_item, null);
			flagholder.nameView = (TextView) convertView.findViewById(R.id.name);
			flagholder.contactView = (TextView) convertView.findViewById(R.id.contact);
			flagholder.classnameView = (TextView) convertView.findViewById(R.id.classname);
			setDataToViews(position, flagholder);
			convertView.setTag(flagholder);
		} else {
			FlagHolder flagholder = (FlagHolder) convertView.getTag();
			if (flagholder != null) {
				setDataToViews(position, flagholder);
			}
		}

		return convertView;
	}

	private void setDataToViews(final int position, FlagHolder flagholder) {
		final ChildInfo childInfo = mList.get(position);
		flagholder.nameView.setText(childInfo.getName());
		flagholder.classnameView.setText(childInfo.getClass_name());
		flagholder.contactView.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {

			}
		});
	}

	private class FlagHolder {
		public TextView nameView;
		public TextView contactView;
		public TextView classnameView;
	}
}