package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.dbmgr.info.ParentInfo;
import com.cocobaby.teacher.utils.Utils;

public class ParentListAdapter extends BaseAdapter {
	private final Context context;
	private List<ParentInfo> mList;

	public ParentListAdapter(Context activityContext, List<ParentInfo> list) {
		this.context = activityContext;
		mList = list;
	}

	public void clear() {
		mList.clear();
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return mList.size();
	}

	@Override
	public ParentInfo getItem(int position) {
		return mList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if (convertView == null) {
			FlagHolder flagholder = this.new FlagHolder();
			convertView = LayoutInflater.from(this.context).inflate(R.layout.parent_item, null);

			flagholder.nameView = (TextView) convertView.findViewById(R.id.pname);
			flagholder.relationshipView = (TextView) convertView.findViewById(R.id.relationship);
			flagholder.phoneView = (TextView) convertView.findViewById(R.id.phoneView);
			flagholder.callPhoneView = (ImageView) convertView.findViewById(R.id.callPhone);
			flagholder.sendSmsView = (ImageView) convertView.findViewById(R.id.sendsms);

			setDataToViews(position, flagholder);
			convertView.setTag(flagholder);
		} else {
			FlagHolder flagholder = (FlagHolder) convertView.getTag();
			if (flagholder != null) {
				setDataToViews(position, flagholder);
			}
		}

		return convertView;
	}

	private void setDataToViews(final int position, FlagHolder flagholder) {
		final ParentInfo parentInfo = mList.get(position);
		flagholder.nameView.setText(parentInfo.getName());
		flagholder.relationshipView.setText(parentInfo.getRelationship());
		flagholder.phoneView.setText(parentInfo.getPhone());

		flagholder.callPhoneView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startToCall(parentInfo.getPhone());
			}
		});

		flagholder.sendSmsView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				startToSend(parentInfo.getPhone());
			}
		});

	}

	private void startToCall(String phonenum) {
		try {
			Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phonenum));
			context.startActivity(intent);
		} catch (Exception e) {
			Utils.makeToast(context, String.format(Utils.getResString(R.string.invalid_phone), phonenum));
		}
	}

	private void startToSend(String phonenum) {
		try {
			Intent intent = new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phonenum));
			context.startActivity(intent);
		} catch (Exception e) {
			Utils.makeToast(context, String.format(Utils.getResString(R.string.invalid_phone), phonenum));
		}
	}

	private class FlagHolder {
		public TextView nameView;
		public TextView relationshipView;
		public TextView phoneView;
		public ImageView callPhoneView;
		public ImageView sendSmsView;
	}
}