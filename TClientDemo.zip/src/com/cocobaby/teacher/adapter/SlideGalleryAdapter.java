package com.cocobaby.teacher.adapter;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.activities.MyApplication;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.utils.DataUtils;
import com.cocobaby.teacher.utils.Utils;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.listener.SimpleImageLoadingListener;

public class SlideGalleryAdapter extends BaseAdapter {
	private LayoutInflater infalter;
	private ImageLoader imageLoader;
	private List<String> pathList = new ArrayList<String>();
	private boolean isSend;
	private int maxWidth;
	private int maxHeight;

	public SlideGalleryAdapter(Context c, ImageLoader imageLoader, List<String> pathList, boolean bSend) {
		infalter = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.imageLoader = imageLoader;
		this.pathList = pathList;
		this.isSend = bSend;

		DisplayMetrics dm = MyApplication.getInstance().getResources().getDisplayMetrics();
		maxWidth = (int) (dm.widthPixels);
		maxHeight = (int) (dm.heightPixels);
		Log.d("", "DDD maxWidth =" + maxWidth + " maxHeight=" + maxHeight + " dm.density=" + dm.density);
	}

	@Override
	public int getCount() {
		return pathList.size();
	}

	@Override
	public String getItem(int position) {
		return pathList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	public List<String> getList() {
		return pathList;
	}

	public void remove(int position) {
		try {
			pathList.remove(position);
			notifyDataSetChanged();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		final ViewHolder holder;
		if (convertView == null) {
			convertView = infalter.inflate(R.layout.slide_item, null);
			holder = new ViewHolder();
			holder.imageView = (ImageView) convertView.findViewById(R.id.image);
			convertView.setTag(holder);
		} else {
			holder = (ViewHolder) convertView.getTag();
		}
		holder.imageView.setTag(position);

		try {
			String path = pathList.get(position);

			String local = "";

			NativeMediumInfo nativeMediumInfo = DataMgr.getInstance().getNativeMediumInfo(path);
			if (nativeMediumInfo != null) {
				local = nativeMediumInfo.getLocal_url();
			}

			if (!isSend) {

				if (DataUtils.isValidFile(local)) {
					path = "file://" + local;
				} else {
					// path = Utils.getFixedUrl(path, 800, 1024);
					path = Utils.getFixedUrl(path, maxWidth, maxHeight);
					Log.d("", "DDD path =" + path);
				}

			} else {
				path = "file://" + path;
			}

			imageLoader.displayImage(path, holder.imageView, new SimpleImageLoadingListener() {
				@Override
				public void onLoadingStarted(String imageUri, View view) {
					// holder.imageView
					// .setImageResource(R.drawable.no_media);
					super.onLoadingStarted(imageUri, view);
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}

		return convertView;
	}

	public class ViewHolder {
		ImageView imageView;
	}

	public void clearCache() {
		imageLoader.clearDiscCache();
		imageLoader.clearMemoryCache();
	}
}
