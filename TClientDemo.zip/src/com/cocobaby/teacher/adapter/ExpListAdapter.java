package com.cocobaby.teacher.adapter;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.support.v4.util.LruCache;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import com.alibaba.fastjson.JSON;
import com.cocobaby.teacher.R;
import com.cocobaby.teacher.activities.ShowVideoActivityEx;
import com.cocobaby.teacher.activities.SlideGalleryActivity;
import com.cocobaby.teacher.constant.Action;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.constant.JSONConstant;
import com.cocobaby.teacher.customview.MyGridView;
import com.cocobaby.teacher.dbmgr.DataMgr;
import com.cocobaby.teacher.dbmgr.info.ExpInfo;
import com.cocobaby.teacher.dbmgr.info.NativeMediumInfo;
import com.cocobaby.teacher.dbmgr.info.TeacherInfo;
import com.cocobaby.teacher.utils.DataUtils;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class ExpListAdapter extends BaseAdapter {
	private final Context context;
	private List<ExpInfo> dataList = new ArrayList<ExpInfo>();

	private ProgressDialog dialog;
	private TeacherInfo teacherInfo;
	private Bitmap headBitmap;
	private LruCache<String, Bitmap> lruCache;

	public ExpListAdapter(Context activityContext) {
		this.context = activityContext;

		teacherInfo = DataMgr.getInstance().getTeacherInfo();
		headBitmap = Utils.getLoacalBitmap(teacherInfo.getLocalHeadIconPath(), ImageDownloader
				.getMaxPixWithDensity(ConstantValue.HEAD_ICON_BIG_WIDTH, ConstantValue.HEAD_ICON_BIG_HEIGHT));

		dialog = new ProgressDialog(context);
		dialog.setTitle(R.string.delete);
		initCache();
	}

	public void clear() {
		lruCache.evictAll();
		dataList.clear();
		notifyDataSetChanged();
	}

	@Override
	public int getCount() {
		return dataList.size();
	}

	@Override
	public ExpInfo getItem(int position) {
		return dataList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		FlagHolder flagholder = null;
		if (convertView == null) {
			convertView = LayoutInflater.from(this.context).inflate(R.layout.exp_item, null);
			flagholder = new FlagHolder();
			flagholder.nameView = (TextView) convertView.findViewById(R.id.name);
			flagholder.deleteView = (TextView) convertView.findViewById(R.id.delete);
			flagholder.contentView = (TextView) convertView.findViewById(R.id.content);
			flagholder.timestampView = (TextView) convertView.findViewById(R.id.time);
			flagholder.headiconView = (ImageView) convertView.findViewById(R.id.headicon);
			flagholder.gridview = (MyGridView) convertView.findViewById(R.id.gridview);
			flagholder.videonail = (ImageView) convertView.findViewById(R.id.videonail);

			convertView.setTag(flagholder);
		} else {
			flagholder = (FlagHolder) convertView.getTag();
		}

		if (flagholder != null) {
			setDataToViews(position, flagholder);
		}

		return convertView;
	}

	private void setDataToViews(final int position, FlagHolder flagholder) {
		ExpInfo info = getItem(position);
		flagholder.nameView.setText(teacherInfo.getName());
		flagholder.timestampView.setText(info.getFormattedTime());

		setHeadIcon(flagholder);
		setContent(flagholder, info);

		if (JSONConstant.IMAGE_TYPE.equals(info.getMediumType())) {
			setIcon(flagholder, info);
		} else if (JSONConstant.VIDEO_TYPE.equals(info.getMediumType())) {
			Log.d("DDDE", "DDDE setVideoNail medium=" + info.getMedium() + "  type=" + info.getMediumType());
			setVideoNail(flagholder, info);
		} else {
			flagholder.videonail.setVisibility(View.GONE);
			flagholder.gridview.setVisibility(View.GONE);
		}
	}

	private void setHeadIcon(FlagHolder flagholder) {
		if (headBitmap != null) {
			Utils.setImg(flagholder.headiconView, headBitmap);
		} else {
			flagholder.headiconView.setImageResource(R.drawable.chat_head_icon);
		}
	}

	private void initCache() {
		final int maxMemory = (int) (Runtime.getRuntime().maxMemory() / 1024);

		lruCache = new LruCache<String, Bitmap>(maxMemory) {
			@Override
			protected int sizeOf(String key, Bitmap value) {
				return value.getRowBytes() * value.getHeight() / 1024;
			}
		};
	}

	private void setVideoNail(final FlagHolder flagholder, final ExpInfo info) {
		flagholder.gridview.setVisibility(View.GONE);
		flagholder.videonail.setVisibility(View.VISIBLE);

		String serverUrl = info.getServerUrls().get(0);
		NativeMediumInfo nativeMediumInfo = DataMgr.getInstance().getNativeMediumInfo(serverUrl);

		Log.d("", "AAA setVideoNail  serverUrl=" + serverUrl);
		Log.d("", "AAA setVideoNail  nativeMediumInfo=" + nativeMediumInfo);
		// 本地没有记录，
		if (nativeMediumInfo == null) {
			final String videoUrl = Utils.getExpVideoPathForLocal(info.getUniqueIdentity());
			showVideoNail(flagholder, videoUrl);
		} else {
			final String videoUrl = nativeMediumInfo.getLocal_url();
			showVideoNail(flagholder, videoUrl);
		}

		flagholder.videonail.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(context, ShowVideoActivityEx.class);
				intent.putExtra(ConstantValue.EXP_INFO, JSON.toJSONString(info));
				context.startActivity(intent);
			}
		});
	}

	private void showVideoNail(final FlagHolder flagholder, final String videoUrl) {
		Log.d("DDDE", "DDDE setVideoNail videoUrl=" + videoUrl);
		if (DataUtils.isValidFile(videoUrl)) {
			Bitmap bitmap = lruCache.get(videoUrl);
			if (bitmap != null) {
				flagholder.videonail.setBackgroundDrawable(new BitmapDrawable(context.getResources(), bitmap));
				flagholder.videonail.setImageResource(R.drawable.pvideo);
			} else {
				Bitmap nail = Utils.createVideoThumbnail(videoUrl);

				if (nail != null) {
					lruCache.put(videoUrl, nail);
					flagholder.videonail.setBackgroundDrawable(new BitmapDrawable(context.getResources(), nail));
					flagholder.videonail.setImageResource(R.drawable.pvideo);
				} else {
					setDefaultNail(flagholder);
				}
			}
		} else {
			setDefaultNail(flagholder);
		}
	}

	private void setDefaultNail(final FlagHolder flagholder) {
		flagholder.videonail.setBackgroundColor(context.getResources().getColor(R.color.black));
		flagholder.videonail.setImageResource(R.drawable.pvideo);
	}

	private void setContent(FlagHolder flagholder, final ExpInfo info) {
		if (TextUtils.isEmpty(info.getContent())) {
			// 避免空字符占用UI布局
			flagholder.contentView.setVisibility(View.GONE);
		} else {
			flagholder.contentView.setVisibility(View.VISIBLE);
		}
		flagholder.contentView.setText(info.getContent());
	}

	protected void startToSlideGalleryActivity(ExpInfo info, int position) {
		final List<String> serverUrls = info.getServerUrls();
		Intent intent = new Intent(context, SlideGalleryActivity.class);

		if (!serverUrls.isEmpty()) {
			intent.putExtra(Action.SELECTED_PATH, serverUrls.toArray(new String[serverUrls.size()]));
		}
		intent.putExtra(ConstantValue.GALLERY_POSITION, position);
		intent.putExtra(ConstantValue.GALLERY_SEND, false);
		context.startActivity(intent);
	}

	private void setIcon(FlagHolder flagholder, final ExpInfo info) {
		flagholder.videonail.setVisibility(View.GONE);

		final List<String> serverUrls = info.getServerUrls();
		if (serverUrls.isEmpty()) {
			flagholder.gridview.setVisibility(View.GONE);
		} else {
			// addToDownloadTask(info);

			SimpleGridViewAdapter adapter = new SimpleGridViewAdapter(context, serverUrls);
			flagholder.gridview.setVisibility(View.VISIBLE);
			flagholder.gridview.setOnItemClickListener(new OnItemClickListener() {

				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					startToSlideGalleryActivity(info, position);
				}

			});
			flagholder.gridview.setAdapter(adapter);
		}
	}

	public void close() {
		dialog.dismiss();
		lruCache.evictAll();
		if (headBitmap != null) {
			headBitmap.recycle();
		}
		// imageLoader.clearMemoryCache();
	}

	public void addAll(List<ExpInfo> list) {
		dataList.clear();
		dataList.addAll(list);
		notifyDataSetChanged();
	}

	public List<ExpInfo> getData() {
		return dataList;
	}

	private class FlagHolder {
		public ImageView videonail;
		public TextView nameView;
		public TextView deleteView;
		public TextView contentView;
		public TextView timestampView;
		public ImageView headiconView;
		public GridView gridview;
	}
}