package com.cocobaby.teacher.adapter;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cocobaby.teacher.R;
import com.cocobaby.teacher.constant.ConstantValue;
import com.cocobaby.teacher.listdata.MultiSelectedInfo;
import com.cocobaby.teacher.listdata.SimpleChildInfo;
import com.cocobaby.teacher.utils.ImageDownloader;
import com.cocobaby.teacher.utils.Utils;

public class MultiSelectedAdapter extends BaseExpandableListAdapter{

    private Context                  mContext;
    private LayoutInflater           inflater = null;
    private List<MultiSelectedInfo>  dataList = null;
    private LruCache<String, Bitmap> lruCache;

    public MultiSelectedAdapter(Context ctx, List<MultiSelectedInfo> list){
        mContext = ctx;
        inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        dataList = list;
        initCache();
    }

    private void initCache(){
        final int maxMemory = (int)(Runtime.getRuntime().maxMemory() / 1024);
        lruCache = new LruCache<String, Bitmap>(maxMemory){
            @Override
            protected int sizeOf(String key, Bitmap value){
                return value.getRowBytes() * value.getHeight() / 1024;
            }
        };
    }

    public List<MultiSelectedInfo> getDataList(){
        return dataList;
    }

    @Override
    public int getChildrenCount(int groupPosition){
        if(!dataList.isEmpty()){
            return dataList.get(groupPosition).getChildList().size();
        }
        return 0;
    }

    @Override
    public MultiSelectedInfo getGroup(int groupPosition){
        return dataList.get(groupPosition);
    }

    @Override
    public int getGroupCount(){
        return dataList.size();
    }

    @Override
    public long getGroupId(int groupPosition){
        return groupPosition;
    }

    @Override
    public SimpleChildInfo getChild(int groupPosition, int childPosition){
        return dataList.get(groupPosition).getChildList().get(childPosition);
    }

    @Override
    public long getChildId(int groupPosition, int childPosition){
        return childPosition;
    }

    @Override
    public boolean hasStableIds(){
        // TODO Auto-generated method stub
        return false;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean arg2, View convertView, ViewGroup arg4){
        if(convertView == null){
            ChildViewHolder viewHolder = new ChildViewHolder();
            convertView = inflater.inflate(R.layout.child_selected_item, null);

            viewHolder.nameView = (TextView)convertView.findViewById(R.id.nick);
            viewHolder.headView = (ImageView)convertView.findViewById(R.id.head);
            viewHolder.childSelectedView = (ImageView)convertView.findViewById(R.id.childSelected);
            setChildData(groupPosition, childPosition, viewHolder);
            convertView.setTag(viewHolder);
        } else{
            ChildViewHolder viewHolder = (ChildViewHolder)convertView.getTag();
            setChildData(groupPosition, childPosition, viewHolder);
        }
        return convertView;
    }

    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup arg3){
        if(convertView == null){
            convertView = inflater.inflate(R.layout.parent_selected_item, null);
            GroupViewHolder holder = new GroupViewHolder();

            holder.mGroupName = (TextView)convertView.findViewById(R.id.group_name);
            holder.mGroupCount = (TextView)convertView.findViewById(R.id.group_count);
            holder.mParentSelectedView = (ImageView)convertView.findViewById(R.id.parentSelected);

            setGroupData(groupPosition, holder);
            convertView.setTag(holder);
        } else{
            GroupViewHolder holder = (GroupViewHolder)convertView.getTag();
            setGroupData(groupPosition, holder);
        }
        return convertView;
    }

    private void setGroupData(final int groupPosition, final GroupViewHolder viewHolder){
        MultiSelectedInfo group = getGroup(groupPosition);
        viewHolder.mGroupName.setText(group.getInfo().getClassName());
        viewHolder.mGroupCount.setText(getCount(group));
        viewHolder.mParentSelectedView.setSelected(group.isClassSelected());

        final MultiSelectedInfo multiSelectedInfo = dataList.get(groupPosition);
        viewHolder.mParentSelectedView.setOnClickListener(new OnClickListener(){

            @Override
            public void onClick(View v){
                handleClassSelected(multiSelectedInfo, groupPosition);
                viewHolder.mParentSelectedView.setSelected(multiSelectedInfo.isClassSelected());
            }

        });
    }

    private void handleClassSelected(final MultiSelectedInfo multiSelectedInfo, int groupPosition){
        if(multiSelectedInfo.isClassSelected()){
            multiSelectedInfo.setClassSelected(false);
            setAllChildSelected(groupPosition, false);
        } else{
            multiSelectedInfo.setClassSelected(true);
            setAllChildSelected(groupPosition, true);
        }
        notifyDataSetChanged();
    }

    private void setAllChildSelected(int groupPosition, boolean b){
        List<SimpleChildInfo> childList = dataList.get(groupPosition).getChildList();

        for(SimpleChildInfo simpleChildInfo : childList){
            simpleChildInfo.setbSelected(b);
        }
    }

    private CharSequence getCount(MultiSelectedInfo group){
        List<SimpleChildInfo> childList = group.getChildList();
        int selectedCount = 0;
        for(SimpleChildInfo simpleChildInfo : childList){
            if(simpleChildInfo.isbSelected()){
                selectedCount++;
            }
        }
        return String.format(mContext.getResources().getString(R.string.select_count), selectedCount, childList.size());
    }

    private void setChildData(int groupPosition, int childPosition, ChildViewHolder viewHolder){
        SimpleChildInfo child = getChild(groupPosition, childPosition);
        viewHolder.nameView.setText(child.getName());
        setHeadIcon(viewHolder, child);

        viewHolder.childSelectedView.setSelected(child.isbSelected());
    }

    public void releaseCache(){
        lruCache.evictAll();
    }

    private void setHeadIcon(ChildViewHolder viewHolder, SimpleChildInfo child){
        String headUrl = child.getHeadicon();
        Bitmap fromLocal = getFromLocal(headUrl);

        if(fromLocal != null){
            Utils.setImg(viewHolder.headView, fromLocal);
        } else{
            viewHolder.headView.setImageResource(R.drawable.default_small_icon);
        }
    }

    private Bitmap getFromLocal(String headUrl){
        Bitmap bitmap = lruCache.get(headUrl);

        if(bitmap == null){
            bitmap = Utils.getLoacalBitmap(headUrl, ImageDownloader
                    .getMaxPixWithDensity(ConstantValue.HEAD_ICON_WIDTH, ConstantValue.HEAD_ICON_HEIGHT));

            if(bitmap != null){
                lruCache.put(headUrl, bitmap);
            }
        }

        return bitmap;
    }

    private class ChildViewHolder{
        ImageView headView;
        TextView  nameView;
        ImageView childSelectedView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition){
        // TODO Auto-generated method stub
        /* 很重要：实现ChildView点击事件，必须返回true */
        return true;
    }

    private class GroupViewHolder{
        TextView  mGroupName;
        TextView  mGroupCount;
        ImageView mParentSelectedView;
    }

    public void changeChildSelection(View view, int groupPosition, int childPosition){
        List<SimpleChildInfo> childList = dataList.get(groupPosition).getChildList();
        SimpleChildInfo child = childList.get(childPosition);
        if(child.isbSelected()){
            child.setbSelected(false);
            dataList.get(groupPosition).setClassSelected(false);
        } else{
            child.setbSelected(true);
            if(allChildSelected(childList)){
                dataList.get(groupPosition).setClassSelected(true);
            }
        }

        // ((ChildViewHolder) view.getTag()).childSelectedView.setSelected(child
        // .isbSelected());
        notifyDataSetChanged();
    }

    private boolean allChildSelected(List<SimpleChildInfo> childList){
        boolean bret = true;
        for(SimpleChildInfo childInfo : childList){
            if(!childInfo.isbSelected()){
                bret = false;
                break;
            }
        }

        return bret;
    }

}
