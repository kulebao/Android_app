package com.cocobabys.proxy;

public interface MyProxyImpl {
	public Object handle() throws Exception;  
}
