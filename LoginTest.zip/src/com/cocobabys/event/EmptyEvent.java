package com.cocobabys.event;

public class EmptyEvent {

}
