package com.cocobabys.push.info;

public class PushMsg {

}
