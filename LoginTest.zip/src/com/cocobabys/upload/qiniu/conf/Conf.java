package com.cocobabys.upload.qiniu.conf;


public class Conf {
	public static final String USER_AGENT = "qiniu android-sdk v6.0.0";
	public static final String UP_HOST = "http://up.qiniu.com";
}
