package com.cocobabys.upload.qiniu.utils;

public interface IOnProcess {
	public void onProcess(long current, long total);
}
