package com.cocobabys.upload.qiniu.utils;

public interface ICancel {
	public boolean cancel(boolean isIntercupt);
}
