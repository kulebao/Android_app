package com.cocobabys.constant;

public enum MemberStatus {
	FREE,PAID;
}
