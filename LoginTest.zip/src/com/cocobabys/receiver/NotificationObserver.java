package com.cocobabys.receiver;

public interface NotificationObserver {
	public void update(int noticeType,int param);
}
