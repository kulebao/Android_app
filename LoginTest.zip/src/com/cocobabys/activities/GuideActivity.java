package com.cocobabys.activities;

import java.util.ArrayList;
import java.util.List;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.cocobabys.R;
import com.cocobabys.adapter.ViewPagerAdapter;
import com.cocobabys.constant.ConstantValue;
import com.cocobabys.utils.DataUtils;

/**
 * 
 * @{# GuideActivity.java Create on 2013-5-2 下午10:59:08
 * 
 *     class desc: 引导界面
 * 
 *     <p>
 *     Copyright: Copyright(c) 2013
 *     </p>
 * @Version 1.0
 * @Author <a href="mailto:gaolei_xj@163.com">Leo</a>
 * 
 * 
 */
public class GuideActivity extends UmengStatisticsActivity implements OnPageChangeListener{

    private ViewPager        vp;
    private ViewPagerAdapter vpAdapter;
    private List<View>       views;

    // 底部小点图片
    private ImageView[]      dots;

    // 记录当前选中位置
    private int              currentIndex;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.guide);

        // 初始化页面
        initViews();
        // 初始化底部小点
        initDots();
    }

    private void initViews(){
        boolean upgrade = getIntent().getBooleanExtra(ConstantValue.UPGRADE, false);

        LayoutInflater inflater = LayoutInflater.from(this);

        views = new ArrayList<View>();

        // 这里有2个分支，新安装和升级
        if(!upgrade){
            // 初始化引导图片列表
            // views.add(inflater.inflate(R.layout.what_new_one, null));
            // views.add(inflater.inflate(R.layout.what_new_two, null));
            // views.add(inflater.inflate(R.layout.what_new_three, null));
            // views.add(inflater.inflate(R.layout.what_new_four, null));
            views.add(inflater.inflate(R.layout.guard_upgrade_one, null));
            views.add(inflater.inflate(R.layout.guard_upgrade_two, null));
        } else{
            views.add(inflater.inflate(R.layout.guard_upgrade_one, null));
            views.add(inflater.inflate(R.layout.guard_upgrade_two, null));
        }

        // 初始化Adapter
        vpAdapter = new ViewPagerAdapter(views, new OnClickListener(){

            @Override
            public void onClick(View v){
                goNextActivity();
            }
        });

        vp = (ViewPager)findViewById(R.id.viewpager);
        vp.setAdapter(vpAdapter);
        // 绑定回调
        vp.setOnPageChangeListener(this);
    }

    private void goNextActivity(){
        Class<?> toClass = null;
        if(DataUtils.isLoginout()){
            // 用户未绑定
            toClass = ValidatePhoneNumActivity.class;
        } else{
            toClass = MainActivity.class;
        }

        Intent intent = new Intent();
        intent.setClass(this, toClass);
        startActivity(intent);
        finish();
    }

    private void initDots(){
        LinearLayout ll = (LinearLayout)findViewById(R.id.ll);

        dots = new ImageView[views.size()];

        // 循环取得小点图片
        for(int i = 0; i < views.size(); i++){
            dots[i] = (ImageView)ll.getChildAt(i);
            dots[i].setEnabled(true);// 都设为灰色
            // dots[i].setVisibility(View.VISIBLE);
        }

        currentIndex = 0;
        dots[currentIndex].setEnabled(false);// 设置为白色，即选中状态
    }

    private void setCurrentDot(int position){
        if(position < 0 || position > views.size() - 1 || currentIndex == position){
            return;
        }

        dots[position].setEnabled(false);
        dots[currentIndex].setEnabled(true);

        currentIndex = position;
    }

    // 当滑动状态改变时调用
    @Override
    public void onPageScrollStateChanged(int arg0){}

    // 当当前页面被滑动时调用
    @Override
    public void onPageScrolled(int arg0, float arg1, int arg2){}

    // 当新的页面被选中时调用
    @Override
    public void onPageSelected(int arg0){
        // 设置底部小点选中状态
        setCurrentDot(arg0);
    }

}
