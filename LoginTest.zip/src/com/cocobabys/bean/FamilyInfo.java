package com.cocobabys.bean;

public class FamilyInfo{
    private String name     = "";
    private String relation = "";
    private String phone    = "";

    public String getName(){
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getRelation(){
        return relation;
    }

    public void setRelation(String relation){
        this.relation = relation;
    }

    public String getPhone(){
        return phone;
    }

    public void setPhone(String phone){
        this.phone = phone;
    }

}
