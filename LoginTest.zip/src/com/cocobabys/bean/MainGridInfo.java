package com.cocobabys.bean;

public class MainGridInfo {
	private int resID = 0;
	private int titleID = 0;

	public int getResID() {
		return resID;
	}

	public void setResID(int resID) {
		this.resID = resID;
	}

	public int getTitleID() {
		return titleID;
	}

	public void setTitleID(int titleID) {
		this.titleID = titleID;
	}

}
