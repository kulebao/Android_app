package com.cocobabys.bean;

public class VideoAccount {
	private String accountName;
	private String pwd;

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getAccountName() {
		return accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Override
	public String toString() {
		return "VideoAccount [accountName=" + accountName + ", pwd=" + pwd
				+ "]";
	}

}
