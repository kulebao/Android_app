package com.cocobabys.bean;

public class CookbookItem {
    private String cookDate = "";
    private String cookWeek = "";
    private String firstContent = "";
    private String secContent = "";
    private String thirdContent = "";
    private String fouthContent = "";

    public String getFirstContent() {
        return firstContent;
    }

    public void setFirstContent(String firstContent) {
        this.firstContent = firstContent;
    }

    public String getSecContent() {
        return secContent;
    }

    public void setSecContent(String secContent) {
        this.secContent = secContent;
    }

    public String getThirdContent() {
        return thirdContent;
    }

    public void setThirdContent(String thirdContent) {
        this.thirdContent = thirdContent;
    }

    public String getFouthContent() {
        return fouthContent;
    }

    public void setFouthContent(String fouthContent) {
        this.fouthContent = fouthContent;
    }

    public String getCookDate() {
        return cookDate;
    }

    public void setCookDate(String cookDate) {
        this.cookDate = cookDate;
    }

    public String getCookWeek() {
        return cookWeek;
    }

    public void setCookWeek(String cookWeek) {
        this.cookWeek = cookWeek;
    }
}
