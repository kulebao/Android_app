package com.cocobabys.bean;

public class LocatorPower {
	private int power_level;
	private long timestamp;
	private long deviceId;

	public int getPower_level() {
		return power_level;
	}

	public void setPower_level(int power_level) {
		this.power_level = power_level;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public long getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(long deviceId) {
		this.deviceId = deviceId;
	}

}
