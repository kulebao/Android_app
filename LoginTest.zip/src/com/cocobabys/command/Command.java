package com.cocobabys.command;

public interface Command {
	public void execute();
}
