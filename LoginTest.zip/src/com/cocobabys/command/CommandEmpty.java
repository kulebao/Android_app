package com.cocobabys.command;


public class CommandEmpty implements Command {

	@Override
	public void execute() {
	}

}
