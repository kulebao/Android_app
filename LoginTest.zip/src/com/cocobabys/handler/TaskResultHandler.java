package com.cocobabys.handler;

public interface TaskResultHandler {
    public void handleResult(int result, Object param);
}
